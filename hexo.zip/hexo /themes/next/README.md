## Mala Theme

[black theme](https://github.com/idhyt/hexo-theme-next/tree/magiclamp) is ongoing...

![blog-theme-mala](http://7xi9s3.com1.z0.glb.clouddn.com/blog-theme-magiclamp-black.png)


## Usage

1.cd `/themes`

2.git clone -b magiclamp git@github.com:idhyt/hexo-theme-next.git

3.mv hexo-theme-next magiclamp

4.modify `_config.yml` => `theme: magiclamp`

5.modify `themes/magiclamp/_config.yml` => `scheme: Mala`
