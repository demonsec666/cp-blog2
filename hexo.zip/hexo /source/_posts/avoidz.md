---
title: Metasploit系列课程第七课预览版
date: 2017-05-21 00:02:01
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=26418123&auto=0&height=66"></iframe>
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/avoidz%20Metasploit%20PAYLOAD.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

&nbsp;
## Metasploit系列课程第七课预览版
啥也不多说 先上图了，暂且有些短短期待，过段时间奉献自己的Metasploit系列课程第七课，这段时间有自己的太多事情要处理，时间上太多了不允许，前阵子还有些感冒发烧，实在抱歉。拖了有阵子了
&nbsp;
&nbsp;
&nbsp;
![enter description here][2]
&nbsp;
![enter description here][3]
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]

&nbsp;


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/8371E98F-792C-48AE-BC77-7D09E342409D.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/44615DFD-F66F-4F02-BB15-FE2423840DAF.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0C2A807D-1CF7-4692-BF1D-5291539DAD02.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/BD049896-0D40-42CE-8E5A-0EE4B6EE69DA.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/FCA08714-CA45-4C4B-AE7A-959EB616B4A2.png 