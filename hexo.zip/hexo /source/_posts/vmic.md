---
title: vmic妙用
date: 2018-05-29 23:57:46
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
``` sql
wmic process call create “calc.exe”
wmic process where name=”calc.exe” call terminate
```

![enter description here][2]


![enter description here][3]

https://www.andreafortuna.org/dfir/windows-command-line-cheatsheet-part-2-wmic/


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180529_235529.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0FDF0B66760E3CA08B8AD7E8E1AC0B34.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/D004AFD6EDAA82D40E564022D034B7E0.jpg 