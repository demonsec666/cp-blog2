---
title: Metasploit系列课程第八课预览版
date: 2017-06-04 13:56:58
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=28403966&auto=1&height=66"></iframe>
 上回说书到： 坏人有坏人的气魄，规矩有规矩的眉角，如果说机器人是男人的浪漫，那么007就是男人的憧憬了，又帅有叼，又能干，永远帅气的一击必杀目标，又有大把大把花不完的钞票，但是在这残酷的现实中，还是醒醒吧，这些神奇的事情只会发生在电影中，是不会发生在我们这些鲁肥宅的身上的。
 &nbsp;
 敬请期待最终版
 ![enter description here][2]
 &nbsp;
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://7xjfim.com2.z0.glb.qiniucdn.com/Iva.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/avet.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="//cytroncdn.videojj.com/latest/Iva.js"></script>


## 预知后事如何，请听下回分解！
&nbsp;
最后结语：其实自己想了挺多了 不知道是不是该结束msf这堂课呢，其实那一天想了很久，真的不太确定自己是否该不该退出这个圈子呢？或许没有答案，又或者我又找到了自己人生的另一半了呢，我或将开启自己又是一个新的旅程了呢！
加油吧！各位 或将开启你自己的旅程！为了自己，为了未来，加油奋斗
&nbsp;
![enter description here][3]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/2756ce21b7fbad2e65a838ec512af025.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/5529FAB8-F4CB-4274-AA46-F42083C90143.png 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0926d2c864d2a7fca2ef33cb3682420f.jpeg