---
title: Debinject--Hacking funny for linux
date: 2017-07-11 21:16:45
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Debinject.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

通过将Metasploit的payload 注入正常的deb包
链接：https://github.com/UndeadSec/Debinject/blob/master/debinject.py
https://www.youtube.com/watch?v=wpzrK6K-e14

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/49A4C4B17434FEEBB265623A71B4A34D.png 