---
title: Metasploit系列课程第六课预览版
date: 2017-04-29 21:53:18
tags: Metasploit,kali
categories: Metasploit
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=473940676&auto=1&height=66"></iframe>
<br>
由于我的工作关系的，导致了课程更新缓慢，也是实在抱歉，过段时间我再将更新完整版的内容，首先看段我即将要讲的课程的内容！！！
Secist_script
v1.4
增加几个powershell渗透点
第6课 metasploit&powershell 预览版，请看演示
## 视频演示
可观看个人演示的视频
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist_script.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist_script.png 