---
title: p0wnedShell
date: 2018-03-29 22:21:01
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/p0wnedShell.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>




p0wnedShell是用C＃编写的冒犯性PowerShell主机应用程序，它不依赖powershell.exe，但在PowerShell运行空间环境（.NET）中运行PowerShell命令和函数。它有很多攻击性的PowerShell模块和二进制文件，使后期开发过程更加容易。我们尝试的是构建一个“一体化”后期开发工具，我们可以使用它来绕过所有缓解解决方案（或至少部分关闭），并且包含所有相关工具。您可以使用它在Active Directory环境中执行现代攻击，并在您的蓝色团队中创建知名度，以便构建正确的防御策略。

![enter description here][2]

Link: https://github.com/Cn33liz/p0wnedShell


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/00F4B1D6625DDBA679857E14BDD6EF3E.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/F63AD030D1EB729779EB10C0BDF86B09.jpg