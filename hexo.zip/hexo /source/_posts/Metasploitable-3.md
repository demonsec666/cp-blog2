---
title: Metasploitable_3
date: 2017-01-13 21:39:40
tags: Metasploitable
categories: Metasploit
---

<strong><span style="color: #ff0000;"><span style="font-size: 200%;"> 本人亲自录制原创视频</span><span style="font-size: 200%;"></span></strong>
![enter description here][1]
<!--more-->
Metasploitable 3 可以说是千呼万唤始出来！本教程结合时下最新的 Metasploitable 3 渗透平台，讲授其不一样的玩法和渗透思路。还不踏上老司机的末班车，带你一探Metasploitable 3 的魅力！

![enter description here][2]
![enter description here][3]
## 课程简介：

1.对Metasploit和Metasploitable3的大致背景介绍。
2.使用nmap针对性的对靶机环境的信息方面的收集。
3.从nmap收集到的信息，手工探测，寻找能否能利用到的相关信息。
4.使用davtest，针对nmap收集到的信息的8585端口,进行渗透，上传msf或者php一句话，得到最终权限或者会。
5.使用meterpreter的portwd特性对远程主机3389端口转发。 
6.或者使用ssh高级语法功能 同样也能使用 远程主机端口转发.
7.参考Metasploitable3的百科 ，玩一些有趣的渗透内容。
8.分享学习干货和教程以及学习经验---Metasploitable2 等youtube 总时长9小时

面向人群：所有安全从业者及爱好者，老少皆宜!
链接：http://pan.baidu.com/s/1geDBBQN 密码：aoqc

<strong><span style="color: #ff0000;"><span style="font-size: 200%;"> 坚持原创！谢谢支持！</span><span style="font-size: 200%;"></span></strong>


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-metasploit-for-aspiring-hacker-part-7-autopwn.1280x600.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/141408kywheelxfty3wxsh.png 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/141744u9ddrl54096khdmh.png 