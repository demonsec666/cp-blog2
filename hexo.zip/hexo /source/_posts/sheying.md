---
title: 那些年拍过的照片
date: 2017-02-21 19:41:10
tags:
---
那些年拍过的照片，路过此场景，随手拍摄，还是手机拍摄
   
   手下留情勿喷。
   ![enter description here][1]
<!--more-->

## 如果不介意的话，赏脸听听几首推荐歌曲：

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=1990093&auto=0&height=66"></iframe>
&nbsp;
&nbsp;
&nbsp;
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=31563636&auto=0&height=66"></iframe>
&nbsp;
&nbsp;
&nbsp;
![enter description here][2]
&nbsp;
&nbsp;
&nbsp;


![enter description here][3]
&nbsp;
&nbsp;
&nbsp;
![enter description here][4]
&nbsp;
&nbsp;
&nbsp;
![enter description here][5]
&nbsp;
&nbsp;
&nbsp;
![enter description here][6]
&nbsp;
&nbsp;
&nbsp;

![enter description here][7]
&nbsp;
&nbsp;
&nbsp;
![enter description here][8]
&nbsp;
&nbsp;
&nbsp;
![enter description here][9]
&nbsp;
&nbsp;
&nbsp;
![enter description here][10]
&nbsp;
&nbsp;
&nbsp;
![enter description here][11]
&nbsp;
&nbsp;
&nbsp;
![enter description here][12]
这张一个朋友拍的，十分好看，偷了一张，太赞了，仰慕高端单反...
&nbsp;
&nbsp;
&nbsp;
![enter description here][13]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0041%2820170214-065907%29.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0042%2820161123-224144%29.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0044%2820161123-224144%29.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0045%2820161120-211129%29.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0048%2820161120-211129%29.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/153F330AB858C311A8247A783C64446F.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0C4B5E8B971A2C5B7503353AE917CD18.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3D2716240034EAC409CEACF2BE3123C9.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0530.JPG 
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0531.JPG 
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0532.JPG 
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0533.JPG 
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1E0FC7C63685C3B3EEB0F84F24F6324E.jpg