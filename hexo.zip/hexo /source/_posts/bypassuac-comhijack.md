---
title: Bypassuac_Comhijack ---kali linux
date: 2017-08-11 15:24:43
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
 前天看了一个国外大牛的视频，觉得很有意思。就决定和你们分享一下
 https://www.youtube.com/watch?v=HNRrmfuTRCY
 https://securityonline.info/metasploit-add-com-class-id-hijack-method-bypassing-uac-windows-x86-x64-7810200820122016/
 
 
## UAC
简称  用户帐户控制，  UAC  是Windows Vista中引入了通过防止程序的管理权限，除非批准的用户提供额外的安全功能。以下是用户在尝试运行程序或访问需要许可的Windows的一部分时可能看到的UAC确认对话框的图片。
 
 Metasploit模块
 https://raw.githubusercontent.com/OJ/metasploit-framework/6ee5d83a157e7887c262ffa42b89ab061e7e8d8c/modules/exploits/windows/local/bypassuac_comhijack.rb
 ![enter description here][2]
 
 该模块将通过在HKCU配置单元中创建COM处理程序注册表项来绕过Windows UAC。当加载某些高完整性流程时，将引用这些注册表项，从而导致加载用户控制的DLL的进程。这些DLL包含导致高级会话的有效载荷。有效负载调用后清除注册表项的修改。该模块需要有效负载的架构来匹配操作系统，但目前的低权限Meterpreter会话架构可能不同。如果在单独的进程中启动有效负载后指定EXE :: Custom，您的DLL应该调用ExitProcess（）。该模块通过目标上的cmd.exe调用目标二进制文件。因此，如果cmd.exe访问受到限制，则此模块将无法正常运行。
 
 （以上引用大神文章）
 
 
 ## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/bypassuac_comhijack.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>
 
 
 
 1.下载bypassuac_comhijack.rb
 <pre>
 curl -o bypassuac_comhijack.rb https://raw.githubusercontent.com/OJ/metasploit-framework/6ee5d83a157e7887c262ffa42b89ab061e7e8d8c/modules/exploits/windows/local/bypassuac_comhijack.rb
 </pre>
&nbsp;
![enter description here][3]
&nbsp;
&nbsp;
&nbsp;
2.将下载的bypassuac_comhijack.rb 剪贴到msf 中 
&nbsp;
![enter description here][4]
&nbsp;

3. 需要的到一个Meterprerter的会话

比如我这里使用我个人的脚本,第三个得到Meterprerter的会话。
&nbsp;
![enter description here][5]
&nbsp;

![enter description here][6]
&nbsp;


3.使用bypassuac_comhijack
&nbsp;
![enter description here][7]
&nbsp;
![enter description here][8]
&nbsp;
看到需要设置的是会话序列号，我这里设置 session 为 1，并且执行payload的时候，会报错，让我们看看需要更改的地方？
&nbsp;
![enter description here][9]
&nbsp;
因为目标虚拟机win10镜像本身是x64架构的，所以我们这里需要更改payload
&nbsp;
![enter description here][10]
&nbsp;
![enter description here][11]
&nbsp;
并且更改端口 
![enter description here][12]
&nbsp;
（PS:如果目标机是32位的话，不用更改PAYLOAD 只需更改端口即可）

4.得到session 2  
&nbsp;
![enter description here][13]
&nbsp;
这里可以看到 我getuid的时候 是demon 用户
当我getsystem的时候 ，得到了system权限。
&nbsp;
![enter description here][14]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/2ADD67C458C4CF66997F4D366E247747.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454208280.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502438764029.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502438764029.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454345346.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454478100.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454553056.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454631936.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454757164.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454854556.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454868195.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502454885362.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502455024735.jpg 
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502455140138.jpg 