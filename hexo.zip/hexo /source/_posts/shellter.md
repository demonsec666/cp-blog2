---
title: shellter
date: 2017-07-20 22:32:55
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
Shellter
Shellter是一个动态的shellcode注入工具，是第一个真正动态的PE infector创建的。
它可以用于将shellcode注入本机Windows应用程序（目前仅适用于32位应用程序）。
shellcode可以是您或您通过框架生成的东西，如Metasploit。

Shellter利用PE文件的原始结构，并不适用任何修改，如更改部分内存访问权限（除非用户想要的），添加额外的部分具有RWE访问权限，以及在AV扫描中看起来很诡异的任何内容。

Shellter采用基于目标应用程序的执行流程的独特动态方法，这只是冰山一角。
Shellter不仅仅是一个EPO感染者，试图找到一个位置来插入指令来重定向执行到有效载荷。与任何其他感染者不同，Shellter的高级感染引擎从不将执行流程传输到受感染的PE文件中的代码洞穴或添加的部分。

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/shellter.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


https://www.shellterproject.com/introducing-shellter/
https://www.youtube.com/watch?v=5foouybCEk0


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DDAF8196DB43C0132A64DA22F5CCADB3.png 