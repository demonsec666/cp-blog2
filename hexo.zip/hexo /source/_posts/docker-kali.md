---
title: win/mac/linux--渗透神器(中)
date: 2017-01-31 21:05:36
tags: kali
categories: kali
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=992604&auto=0&height=66"></iframe>
&nbsp;
&nbsp;
 <span style="color: #ff0000;">背景知识科普：</span>
<p class="p1"><span class="s1"><strong><span style="color: #008000;">Docker</span> 是一个开源的应用容器引擎</strong>，让开发者可以打包他们的应用以及依赖包到一个可移植的容器中，然后</span>发布到任何流行的 <a href="http://baike.baidu.com/view/1634.htm">Linux</a> 机器上，也可以实现<a href="http://baike.baidu.com/view/729629.htm">虚拟化</a>。容器是完全使用<a href="http://baike.baidu.com/subview/720343/13998082.htm">沙箱</a>机制，相互之间不会有任何接口。</p>

<div class="para-title level-3">
<div>
<div><strong><span style="color: #008000;">1、虚拟化容器的优势</span></strong></div>
</div>
<div>随着公有云的普及，开发者越来越需要一个快速迁移和高速构建应用的环境。 现在开发者需要能方便地创建运行在云平台上的应用，也就是说应用必须能够脱离底层机器。 而且同时必须是方便获取的。因此，开发者们需要一种创建分布式应用程序的方式，这也是Docker所能够提供的。</div>
<div>举个例子： 我在项目中同一台服务器中同时运行了nginx，forum&amp;wiki（node.js），meteor server（meteor.js）。每个服务又依赖大量的第三方库，如果用传统的方式进行部署。则需要安装大量的依赖模块，费时费力。假如我需要在国外的AWS及国内的阿里云上同时部署多台机器。或者从某个公有云服务商迁移到另外一个服务商。这中间的重复劳动是很让人抵触的。抛开让人生厌的重复劳动，服务之间也有可能因此互相“污染”导致性能下降甚至服务异常。而Docker提供了一种更为聪明的方式，通过容器来打包应用，意味着迁移只需要在新的服务器上启动需要的容器就可以了。这无疑将节约大量的宝贵时间，并降低部署过程出现问题的风险。</div>
<div></div>
<div>

<span style="color: #008000;">2、Docker在开发和运维中的优势</span>

对开发和运维（DevOps）人员来说，可能最梦寐以求的就是一次性地创建或配置，可以在任意环境、任意时间让应用正常地运行。而Docker恰恰是可以实现这一终极目标的瑞士军刀。

具体说来，Docker在开发和运维过程中，具有如下几个方面的优势。

更快速的交付和部署。使用Docker，开发人员可以使用镜像来快速构建一套标准的开发环境；比如在项目开发过程中我会先用Docker将代码部署到本地进行测试验证。使用Docker在本地轻松搭建出的和服务器类似的架构，使开发环境中的测试更贴近于生产环境。开发完成之后，测试和运维人员可以直接使用相同环境来部署代码。Docker可以快速创建和删除容器，实现快速迭代，大量节约开发、测试、部署的时间。并且，各个步骤都有明确的配置和操作，整个过程全程可见，使团队更容易理解应用的创建和工作过程。

更高效的资源利用。Docker容器的运行不需要额外的虚拟化管理程序（Virtual Machine Manager，VMM，以及Hypervisor）支持，它是内核级的虚拟化，可以实现更高的性能，同时对资源的额外需求很低。

更轻松的迁移和扩展。Docker容器几乎可以在任意的平台上运行，包括物理机、虚拟机、公有云、私有云、个人电脑、服务器等。 利用这种兼容性让用户可以在不同平台之间轻松地迁移应用。

更简单的更新管理。使用Dockerfile，只需要小小的配置修改，就可以替代以往大量的更新工作。并且所有修改都以增量的方式进行分发和更新，从而实现自动化并且高效的容器管理。

<strong><span style="color: #008000;">3、Docker与虚拟机比较</span></strong>

作为一种轻量级的虚拟化方式，Docker在运行应用上跟传统的虚拟机方式相比具有显著优势：

Docker容器很快，启动和停止可以在秒级实现，这相比传统的虚拟机方式要快得多。

Docker容器对系统资源需求很少，一台主机上可以同时运行数千个Docker容器。

Docker通过类似Git的操作来方便用户获取、分发和更新应用镜像，指令简明，学习成本较低。

Docker通过Dockerfile配置文件来支持灵活的自动化创建和部署机制，提高工作效率。

Docker容器除了运行其中的应用之外，基本不消耗额外的系统资源，保证应用性能的同时，尽量减小系统开销。传统虚拟机方式运行N个不同的应用就要启动N个虚拟机（每个虚拟机需要单独分配独占的内存、磁盘等资源），而Docker只需要启动N个隔离的容器，并将应用放到容器内即可。

当然，在隔离性方面，传统的虚拟机方式多了一层额外的隔离。但这并不意味着Docker就不安全。Docker利用Linux系统上的多种防护机制实现了严格可靠的隔离。从1.3版本开始，Docker引入了安全选项和镜像签名机制，极大地提高了使用Docker的安全性。

</div>
</div>
![enter description here][2]
<div class="para"><strong><span style="color: #008000;">docker 多开终端：资源消耗的状态。</span></strong></div>
<div class="para">
<pre class="lang:vim decode:true">CONTAINER           CPU %               MEM USAGE / LIMIT       MEM %               NET I/O             BLOCK I/O           PIDS
bb27f8c0cf22        0.03%               262.2 MiB / 1.951 GiB   13.12%              648 B / 648 B       4.096 kB / 0 B      12


</pre>
</div>
![enter description here][3]

<p class="p1">官方链接：https://www.kali.org/news/official-kali-linux-docker-images/</p>
&nbsp;
&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;                         <span style="color: #008000;">    Docker从入门到夺门而逃 </span>

<span style="color: #ff0000;">一.安装docker_kali .....</span>

安装之前需要去docker官方网站下载docker,进行安装，我这边安装的是mac版docke
https://www.docker.com/

![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;
 <span style="color: #008000;">  二.安装完后开始下载拉取kali镜像，比较小巧大概几百M左右</span>
<p class="p1">使用官方一下命令：即可获取相应镜像</p>

<pre class="lang:vim decode:true ">docker pull kalilinux/kali-linux-docker</pre>
<p class="p1">或者</p>

<pre class="lang:vim decode:true ">docker run -t -i kalilinux/kali-linux-docker /bin/bash</pre>
<p class="p1">下载完后即可进入kali_linux 终端下</p>
![enter description here][6]
&nbsp;
&nbsp;
 <span style="color: #008000;">  三. 绑定Docker 随机ID，以及配置kali</span>
![enter description here][7]
<pre class="lang:vim decode:true">root@bb27f8c0cf22:/# exit</pre>
&nbsp;
&nbsp;
 <span style="color: #008000;">  四. 开启docker，使用attach命令连接容器</span>
开启容器 <span style="color: #ff0000;">docker start <strong>&lt;容器名&gt;或者&lt;id&gt;</strong></span>
<pre class="lang:vim decode:true">demonMacbookPro:~ demon$ docker start kali
</pre>
链接docker容器  格式为：<span style="color: #ff0000;"><strong>docker attach &lt;容器名&gt;或者&lt;id&gt;</strong></span>
<pre class="lang:vim decode:true">demonMacbookPro:~ demon$ docker attach kali</pre>
<p class="p1">进入docker</p>

<pre class="lang:vim decode:true ">root@bb27f8c0cf22:/#</pre>
&nbsp;
&nbsp;
 <span style="color: #008000;">  五. 配置docker_kali以及优化
</span>
1.更新源以及安装相应的工具，这里的源使用官方源即可

<strong>更新源</strong>
<pre class="lang:vim decode:true ">root@bb27f8c0cf22:/# apt-get update  
Get:1 http://mirrors.neusoft.edu.cn/kali kali-rolling InRelease [30.5 kB]
Get:2 http://mirrors.neusoft.edu.cn/kali kali-rolling/non-free Sources [126 kB]
Get:3 http://mirrors.neusoft.edu.cn/kali kali-rolling/contrib Sources [67.7 kB]
Get:4 http://mirrors.neusoft.edu.cn/kali kali-rolling/main Sources [11.1 MB]   
Get:5 http://mirrors.neusoft.edu.cn/kali kali-rolling/main amd64 Packages [15.0 MB]
Get:6 http://mirrors.neusoft.edu.cn/kali kali-rolling/contrib amd64 Packages [106 kB]
Get:7 http://mirrors.neusoft.edu.cn/kali kali-rolling/non-free amd64 Packages [164 kB]
Fetched 26.6 MB in 23s (1116 kB/s)                                             
Reading package lists... Done
root@bb27f8c0cf22:/#</pre>
<p class="p1">安装想要的工具 比如<strong><span style="color: #008000;">sqlmap</span></strong></p>

<pre class="lang:vim decode:true ">root@bb27f8c0cf22:/# apt-get install sqlmap</pre>
<p class="p1">再比如 我这人比较懒，想把kali的工具全部搬过来，全部使用上，使用以下命令。<strong><span style="color: #008000;">安装kali所有的工具</span></strong></p>

<pre class="lang:vim decode:true ">root@bb27f8c0cf22:/# apt-get install kali-linux-all</pre>
<p class="p1">下载完，大概10G左右的安装包</p>
<p class="p1">另外值得说的是如果msf 里面没有启动数据 请启动相应的数据库</p>
<p class="p1">查看相应教程链接：http://www.mamicode.com/info-detail-1208947.html</p>
&nbsp;
&nbsp;
 <span style="color: #008000;">  六. docker容器上传下载文件
</span>
docker是个封闭的容器。上传和下载也是一个比较麻烦的事。我自己想了一个办法就是把我的物理机  mac系统作为<span style="color: #008000;">ssh 上传下载的地方</span>

![enter description here][8]

我这边已经建立了<span style="color: #008000;">ssh通道</span>，不会建立ssh ，查询相关操作系统建立ssh文档。
<pre class="lang:vim decode:true ">root@bb27f8c0cf22:/# ssh demon@192.168.1.108
Password:
Last login: Wed Feb  1 06:21:59 2017
demonMacbookPro:~ demon$ exit 
logout
Connection to 192.168.1.108 closed.
root@bb27f8c0cf22:/#</pre>
<p class="p1">从服务器下载文件 ：<span style="color: #008000;">scp  用户名@ssh建立的ip的地址:上传文件的绝对路径  下载的路径</span></p>

<pre class="lang:default decode:true ">scp demon@192.168.1.108:/Users/demon/Desktop/sql.hear /home
</pre>
<p class="p1">上传本地文件到服务器：<span style="color: #008000;">scp /path/local_filename username@servername:/path  </span></p>

<pre class="lang:vim decode:true ">scp /var/www/test.php  codinglog@192.168.0.101:/var/www/  把本机/var/www/目录下的test.php文件</pre>
<p class="p1">可查询ssh相关文档</p>
&nbsp;
&nbsp;
 <span style="color: #008000;">  七.下载kitematic---GUI 管理工具</span>
终端开一个是不够的，我们通常终端使用 是多开的情况，但是你再新建一个窗口同样使用一下命令进入
<pre class="lang:vim decode:true">docker attach kali</pre>
<span style="color: #ff0000;">你会发现窗口是同步的，有没有更加方便的工具设置呢</span>。有的------kitematic就可以实现

https://www.docker.com/products/docker-kitematic
![enter description here][9]
<p class="p1"><strong><span style="color: #ff0000;">点击EXEC，点击多个，开启终端窗口都不会同步现象。</span></strong></p>
![enter description here][10]
Docker 其他相关命令-----删除多余的容器
<pre class="lang:vim decode:true">demonMacbookPro:~ demon$ docker ps -a -q     -------查看docker 容器的id
bb27f8c0cf22
demonMacbookPro:~ demon$ docker ps -a      ------查看docker 容器 完整内容
CONTAINER ID        IMAGE                         COMMAND             CREATED             STATUS              PORTS               NAMES
bb27f8c0cf22        kalilinux/kali-linux-docker   "/bin/bash"         4 days ago          Up 46 minutes                           kali</pre>
<pre class="lang:vim decode:true">demonMacbookPro:~ demon$ docker rm   docker随机id     --------删除docker多余id</pre>
<pre class="lang:vim decode:true">demonMacbookPro:~ demon$ docker stats      -------查看docker相应进程</pre>
<pre class="lang:vim decode:true">demonMacbookPro:~ demon$ docker restart kali（容器名或者id）----重启docker容器</pre>
<p class="p1">其他命令查询docker相关文档</p>
<p class="p1"><span style="color: #008000;">其中docker的作用不仅这么点，还可以自定义，搭建我们的web靶机等等，可以多尝试下docker的作用</span></p>
<p class="p1">参考资料：http://www.open-open.com/lib/view/open1456844987781.html</p>
其他可以参考我的好基友国光：http://www.sqlsec.com/703.html  docker入门简明教程


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0574.JPG 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0575.JPG 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0576.JPG 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0577.JPG 
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0578.JPG 
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0579.JPG 
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/78E445CA-8FD4-41E3-BA6F-99B2A67722BA.png
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0580.JPG 
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0581.JPG 
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0582.JPG 