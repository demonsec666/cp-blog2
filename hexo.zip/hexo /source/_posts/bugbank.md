---
title: bugbank 欢迎技术分享
date: 2017-06-20 19:51:57
tags:
---
![enter description here][1]

<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=27969803&auto=0&height=66"></iframe>
一首歌送给你们
&nbsp;
## 个人话语
<pre>时境过迁，距离上次作为一个小小的小白 距离现在已过去半年多左右的时间了，
那时候也是作为一个小白在漏洞银行分享了自己当时在学习Metasploitable-3   
http://www.ggsec.cn/Metasploitable-3.html
也正是有了那次机会自己慢慢从小白的身份慢慢脱颖而出，虽谈不上多大的进步，
在那边做一些技术分享，并通过自己的努力做了一些课程后，给了我自己好很大的信心。
欢迎各位与我们dalao多多交流学习。其中也不乏一些小姐姐 ，为你谈心，谈人生。</pre>
&nbsp;
![enter description here][2]
&nbsp;
想要和技术dalao来一次深入的切磋？
渴望和表姐来一次亲密的接触？
枚有搓！我们给你这个机会！
漏洞银行技术群强势登场！！！
小姐姐可能不能陪你看雪看星星看月亮,从诗词歌赋谈到人生哲学~
但是dalao可以陪你从SQL聊到二进制逆向，从开发聊到加密算法
总之
<pre>
你来，或者不来
干货就在那里 
别人正在学习 
你在，或者不在
小姐姐在那里等你
<pre>
&nbsp;
![enter description here][3] come baby！

i'll take this ride 
And just drive 


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/psb.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/RZRDV4YWJJ87I~G92%5B%7B@FXC.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/PTKPJX0%7DY8V4G10%60A$FULM8.jpg