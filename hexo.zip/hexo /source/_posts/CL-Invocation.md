---
title: CL_Invocation | Powershell
date: 2018-01-03 19:11:25
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/CL_Invocation.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

``` stylus
Get-AuthenticodeSignature C:\Windows\diagnostics\system\AERO\CL_Invocation.ps1
. C:\Windows\diagnostics\system\AERO\CL_Invocation.ps1
SyncInvoke  calc.exe
```


![enter description here][2]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/87953097C158F451293961F5D7311FB6.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/88B505CC0D3741C9637F5425E946920F.jpg 