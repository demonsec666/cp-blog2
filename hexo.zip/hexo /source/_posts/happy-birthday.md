---
title: 祝自己生日快乐
date: 2017-10-22 07:16:47
tags:
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=486403266&auto=1&height=66"></iframe>


每年的今天似乎都是一个人过的生日，但是没想到的是今年却在病魔中渡过的。

自己依稀记得自己模模糊糊的接到了父亲的三次电话，都是在问我，：“儿子，病好点了吗”  “好点了。。。。”

昨晚也是收到母亲的安慰，那时候感觉真的是亲情的可贵，世界最温暖人心的还是亲情。当在病魔中挣扎的时候，

想起了很多年母亲带我看医生的时候，如今只有一个人看病。小时候有母亲给我买的玩具，却是安心的陪母亲上

医院。如今只有母亲和父亲的短短几句话，感觉真的人生足矣！那晚哭了 。十几年不落泪的我，居然哭了，哭的

很伤心。想问，时间去哪儿了。父母亲虽然老了，但是对我的爱却是永恒不变的。

怕自己老了，忘事。将其这美好的事情记录下来
![enter description here][2]

## 最后祝自己生日快乐！！！！
</b>

![enter description here][3]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508628330668.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/59FD210598B5CA9B830E96E2CC6E927E.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508628364893.jpg