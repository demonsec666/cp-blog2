---
title: DCOM
date: 2018-06-03 19:45:17
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Dcom.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


![enter description here][1]


![enter description here][2]
https://zhuanlan.kanxue.com/article-4866.htm


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/30EC33F1CD287C4DA94E92144CF3B1A0.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/497F7040FE9CB103F523F1B92F3382AE.jpg 