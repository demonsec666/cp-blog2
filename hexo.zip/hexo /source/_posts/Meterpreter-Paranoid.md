---
title: Meterpreter-Paranoid
date: 2017-06-12 21:16:20
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Meterpreter_%20Paranod.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


前段日子看到r00t-3xp10it 大牛出了个新教程，自己也打算尝试下 ，
https://www.youtube.com/watch?v=Z51jBiFnPGE
https://github.com/r00t-3xp10it/Meterpreter_Paranoid_Mode-SSL
&nbsp;
## github的介绍：
meterpreter_paranoid_mode.sh允许用户安全上演/无级连接Meterpreter经检查合格证书的处理程序正在连接到。

我们开始通过PEM格式的证书生成，一旦证书有我们可以创建一个HTTP或HTTPS或EXE有效载荷，并给予
它是用来验证连接的PEM格式证书的路径。

要验证连接，我们需要告诉有效负载什么证书处理程序将通过设置handlersslcert选项然后使该证书的检查
设置stagerverifysslcert真实。

一旦创建了有效负载，我们就需要创建一个处理程序来接收连接，并再次使用PEM证书，以便处理程序可以使用为验证SHA1哈希。就像是有效载荷一样，我们设置参数。

handlersslcert路径的PEM文件和stagerverifysslcert真实。

## 实验&验证
0x00
&nbsp;
![enter description here][2]
&nbsp;
首先下载，然后进入目录给予权限。
<pre>git clone https://github.com/r00t-3xp10it/Meterpreter_Paranoid_Mode-SSL.git</pre>
&nbsp;
0x01
运行Meterpreter_Paranoid_Mode.sh 
&nbsp;
![enter description here][3]
&nbsp;
0x02
回车后我们可以看到，比如选择impersonate domain (模拟域),点击确定后，让我们随便输入一个 网站地
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;
我这边就习惯性的输入了一个百度网址。然后确定。
&nbsp;
![enter description here][6]
&nbsp;
同时这边在output 会生成一个www.baidu.com.pem  RSA私钥文件
&nbsp;
![enter description here][7]
&nbsp;
0x03
&nbsp;
选择我们要输出的payload 的格式 bat/exe,我这边选择的是bat，点击确定，exe没来得及测试。
&nbsp; 

![enter description here][8]
&nbsp; 
以及这边让我们输入攻击者的ip和端口，以及我们的msf的PAYLOAD 反向shell连接方式。
&nbsp; 
![enter description here][9]
&nbsp; 
![enter description here][10]
&nbsp; 
![enter description here][11]
&nbsp; 
开始构建payload，并且开启msf
&nbsp; 
![enter description here][12]
&nbsp; 
![enter description here][13]
&nbsp; 
0x04
最后将bat发给受害者运行即可，返回meterpreter.
&nbsp; 
![enter description here][14]
&nbsp; 
END...................
THANKS........


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Untitled.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497279581594.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497279712213.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280010639.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280150458.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280204379.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280288089.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280322292.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280533182.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280579273.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280600370.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280693129.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280752359.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1497280877395.jpg 