---
title: steghide
date: 2017-07-31 21:19:43
tags: kali
categories: kali
---
![enter description here][1]
<!--more-->
  在过去的几年中，“隐写术”这个术语引起了执法部门的广泛关注。黑客曾使用这项技术来将他们的秘密信息传递给恐怖分子。黑客们在911恐怖袭击事件中也使用了隐写术。所以，如果你对计算机安全很感兴趣，那么你必须得知道隐写术。在这篇文章中，我们将会揭开隐写术的神秘面纱，并向大家介绍一些可供使用的工具。

隐写术是一种隐藏信息的方法，它可以在看似正常的信息中隐藏私密信息。它常用于某些秘密信息的传输，而且中间人没有办法能够知道你所想传达的真实信息到底是什么。这项信息隐藏技术在真实的日常通讯中已经使用了很多年了。由于数字通讯技术的不断发展，这项技术同样在数字通讯中得到了广泛的应用。在计算机中，可以将常规文件中无用的或无价值的数据位替换成你的秘密信息。这些信息可以隐藏于明文，密文，以及图片之中。你可以将信息隐藏于任何文件中。现在，有很多工具可以让你将秘密信息隐藏于图片文件或者音频文件之中。

使用隐写术的一个最主要的原因就是，你需要在一个普通文件中隐藏你的私密消息，而且没人会怀疑这个文件。人们会认为这是一个普通文件，这样一来你的秘密信息就不会被发现了，而且仅仅查看这些文件并不能发现你的秘密。有很多种情况需要保护文件传输的安全。现在到处都是黑客，而且他们总是在尝试拦截通讯信息从而获取机密数据。通过使用隐写术，我们可以降低数据泄漏的概率。即便是黑客得到了你的账户和邮箱的访问权限，他也无法得到你账户中的机密文件。

有很多种方法可以让你在数字通讯中使用隐写术。而且，你不需要通过输入代码来实现这个功能。现在有大量的软件工具可以执行隐写术。这种软件可以将你的秘密信息隐藏于图片文件，HTML网页文件，DOC文件，以及其他种类的文件之中。
(摘自安全客 http://bobao.360.cn/learning/detail/441.html )
&nbsp;
1.steghide 安装
![enter description here][2]
&nbsp;
2.帮助参数
![enter description here][3]
&nbsp;
3.新建一个文本文档比如：demon.txt
&nbsp;
![enter description here][4]
&nbsp;
4.内容如下！
![enter description here][5]
&nbsp;
![enter description here][6]
&nbsp;
将root目录下 demon.txt 数据写入到1.jpg中
1.在帮助参数中的embed (emdeb data)
&nbsp;
![enter description here][7]
&nbsp;
&nbsp;
需要被嵌入的文件
![enter description here][8]
&nbsp;
![enter description here][9]
&nbsp;
需要嵌入的文件
&nbsp;
5.设置密码 ，隐写写入完成
![enter description here][10]
&nbsp;
6.分离数据，当分离数据的时候需要输入嵌入数据的时候设置的密码
&nbsp;
 ![extract][11]
 &nbsp;
 ![enter description here][12]
  &nbsp;
![enter description here][13]
&nbsp;
![enter description here][14]
&nbsp;
链接资料：
https://www.youtube.com/watch?v=gfLGvMdeE-4


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B8483F0FB6504AD4DAA52324194E00A5.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501507632891.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501507699467.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501507841125.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501507970331.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501508634995.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501508610719.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509156634.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509028573.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509278287.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509577684.jpg 
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509735720.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509470991.jpg 
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1501509754056.jpg 