---
title: forfiles2
date: 2018-03-30 21:01:32
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/forfiles_calc.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


![enter description here][2]



link: https://twitter.com/harr0ey/status/979478826093772800


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/798E379E133748F50359069235A4B70D.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/84CB063165CEF600E2BEA1DDAEF04CD5.jpg 