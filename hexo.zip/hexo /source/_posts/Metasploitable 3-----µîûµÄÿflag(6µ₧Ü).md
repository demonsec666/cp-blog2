---
title: Metasploitable 3-----挖掘flag(6枚)
tags: Metasploitable
categories: Metasploit
date: 2016-12-15 21:42:59
---

#                         <span style="color: #ff0000;">**Metasploitable 3-----挖掘flag其中一枚**</span>

在14日youtube 的<span style="color: #ff0000;">webpwnized<span style="color: #000000;">一位小哥，在Metasploiltable3中找到一枚flag</span></span>

![9f513143-8bc2-4874-8077-07669767a343](http://www.secist.com/wp-content/uploads/2016/12/9F513143-8BC2-4874-8077-07669767A343.png)
<!--more-->
以下是这位小哥对找到flag的简单描述：
<pre class="lang:default decode:true ">使用NMAP发现的远程服务，加载到Metasploit表中并记录在Metasploitable 3上，
我们使用在TCP端口22上运行的SSH服务将7个黑桃PDF文件拉到Kali Linux 可以打开PDF。 
但是，该文件仅显示包含文本。 标志是图像，已经以不允许图像程序识别嵌入图像的方式被改变，
因此当打开文档时不显示图像。 
来自Kali Linux命令行的pdf图像程序用于提取隐藏的图像并显示标志。</pre>
**<span style="color: #ff0000;">发掘详细过程：<span style="color: #000000;">1</span>.</span>** 使用<span style="color: #ff0000;">nmap</span>扫描 探测到ssh服务的开启。并且看到多个账户信息。

![a44280d1-e049-49d7-b1fc-b0af38c6e3ba](http://www.secist.com/wp-content/uploads/2016/12/A44280D1-E049-49D7-B1FC-B0AF38C6E3BA.jpg)![19eb3ede-2a36-4e59-8a66-2866cfd8abd9](http://www.secist.com/wp-content/uploads/2016/12/19EB3EDE-2A36-4E59-8A66-2866CFD8ABD9.jpg)

### 2\. <span style="color: #008000;">登录ssh，并进入paf的存放的路径</span>

![0b6a1f8f-0a06-4201-8bcb-62cd40e8697b](http://www.secist.com/wp-content/uploads/2016/12/0B6A1F8F-0A06-4201-8BCB-62CD40E8697B-1.jpg)

### 3.使用<span style="color: #008000;">scp</span>命令 ，进行下载pdf文档到kali linux <span style="color: #008000;">vmp</span>目录下

![0e0c84db-1a19-488f-baec-af03b797a50a](http://www.secist.com/wp-content/uploads/2016/12/0E0C84DB-1A19-488F-BAEC-AF03B797A50A.jpg)

### 

### 4\. 使用**<span style="color: #008000;">less</span>** 命令，查看pdf 文档分页。往下翻可以看到类似图片的信息。

![3fde4985-cfd3-4ade-a2bc-3b3a11746d2b](http://www.secist.com/wp-content/uploads/2016/12/3FDE4985-CFD3-4ADE-A2BC-3B3A11746D2B.jpg)

![8c020ebe-c2f2-4c64-a6b9-b654805ece56](http://www.secist.com/wp-content/uploads/2016/12/8C020EBE-C2F2-4C64-A6B9-B654805ECE56.jpg)

### 5.使用<span style="color: #ff0000;">pdf图像分离工具命令</span>（<span style="color: #008000;">pdfimages</span>），将pdf文档中隐藏着图像分离出来，可看到分离后的图片：~<span style="color: #ff0000;">000.ppm</span>和<span style="color: #ff0000;">001.ppm</span>两张图片。

![88303f32-28fe-48c7-8fe6-962288ef7fdb](http://www.secist.com/wp-content/uploads/2016/12/88303F32-28FE-48C7-8FE6-962288EF7FDB.jpg)

![9f513143-8bc2-4874-8077-07669767a343](http://www.secist.com/wp-content/uploads/2016/12/9F513143-8BC2-4874-8077-07669767A343.png)

# <span style="color: #ff0000;">以下链接是这位小哥找到flag 的过程6个教学视频，需要翻墙观看：</span>

[embed]https://www.youtube.com/watch?v=Z86Ldkii24A[/embed]

https://youtu.be/WeUswbCPtWg?list=PLZOToVAK85MpnjpcVtNMwmCxMZRFaY6mT

https://youtu.be/sPjTdTXMhls?list=PLZOToVAK85MpnjpcVtNMwmCxMZRFaY6mT

https://youtu.be/Gofx_P72Qo0?list=PLZOToVAK85MpnjpcVtNMwmCxMZRFaY6mT

https://youtu.be/djM7mNMZUD8?list=PLZOToVAK85MpnjpcVtNMwmCxMZRFaY6mT

https://youtu.be/Xb4yAw-qdIA?list=PLZOToVAK85MpnjpcVtNMwmCxMZRFaY6mT