---
title: Mavinject | Dll Injected
date: 2017-12-20 21:06:12
tags:
---
![enter description here][1]
<!--more-->
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/mavinject.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


DLL注入
什么是DLL注入？DLL注入是将 DLL 注入进程的内存空间，然后将其作为其一部分执行的过程。这样做意味着DLL代码具有对进程内存的所有访问权限，无论出于何种原因都可以对其进行操作，但更重要的是，它还获得了进程的所有权限。例如，您希望与外界沟通，但您没有通过防火墙的权限。随着注入DLL，你可以注入并执行你的代码到其中的过程确实有权限（如Internet Explorer），这将是能够做什么它需要。

![enter description here][2]
如果有人对如何编写一个基本的DLL注入器感兴趣，请让我知道下面。

用户模式Rootkit
用户模式rootkit是提供与内核模式rootkit类似功能的rootkit（尽管在技术上不是这样），例如屏蔽和禁止访问文件，但在用户级别操作。我们把这个级别称为ring 3，而内核模式rootkit是ring 0。这些戒指是什么？这是一个视觉辅助图。
![enter description here][3]


我们可以看到，绿色是用户模式，中间的红色是内核模式。尽管环1和环2确实存在，但实际上并不使用，所以我们只是指0或3。

从环3调用WinAPI函数调用，因为环3不能直接与CPU通信，所以必须通过一系列特权检查向内环0进行响铃。一旦进入响铃0，操作系统执行指令来执行函数调用所需的操作。通过这样做，API 相信从环3传递到0并返回的参数将保持其完整性而不被修改。


## mavinject

Mavinject是一个合法的Windows组件，可以在任何正在运行的进程中使用和滥用，执行任意代码注入。由于这是Windows上的一个常见组件，因此可以利用它来执行无人区域的攻击。
![enter description here][4]


进一步分析后，我们被解雇的事件为假阳性，但我们仍然受到触发的原因，为什么一个合法的部分将执行这样的操作的原因感到困惑  EXCEL.EXE。
![enter description here][5]
在时间轴方面，mavinject32.exe在excel.exe中执行代码注入 ，然后立即终止。这引起了一些关于引擎操作可能带有恶意并且开始跟踪端点行为的担忧。以下是违规程序的细节：
![enter description here][6]

现在很清楚，mavinject32.exe是一个合法的 Microsoft组件。命令行也很有趣，因为从初步分析来看，论据似乎如下：
```markdown
mavinject32.exe <PID> <PATH DLL>
```


实际上是在端点上运行的excel.exe实例的PID，其路径与在“事件”期间注入的DLL 的路径相对应。“mav-inject”的名字应该已经相当透露了，在这一点上，我们怀疑它可能被用来（和滥用）在任何其他进程中注入任意的恶意DLL。

作为第一步，我们尝试了解Mavinject是否是共同的组件; 我们在以下位置的不同端点上找到它：
```markdown
"C:\Program Files\Common Files\microsoft shared\ClickToRun\MavInject32.exe"
```

此外，可执行文件可以在其他两个目录中找到：System32和SysWOW64。

文件描述显示组件是什么：
```markdown
FileDescription:  Microsoft Application Virtualization Injector
```
该应用程序是Microsoft Application Virtualization（App-V）的一部分。可执行文件的分析使我们得到以下有趣的参数
```markdown
/INJECTRUNNING
```

![enter description here][7]


使用Mavinject ...
在收集到来自不同客户的更多信息之后，我们确定了一个常见的用例：
```markdown
mavinject <PID> /INJECTRUNNING
```
使用此命令行运行的可执行文件查找以下注册表项：
```markdown
Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\AppV\Subsystem
```

其相应的值是：
```markdown
ValueName: Modules - ValueData: C:\Windows\System32\AppVEntSubsystems32.dll
ValueName: Modules64 - ValueData: C:\Windows\System32\AppVEntSubsystems64.dll
```


根据目标进程体系结构（32位或64位），它会注入其中一个DLL。

虐待Mavinject ...
经过进一步分析，很明显的是，同样的确切机制可以被滥用以下方式注入一个DLL在一个任意的运行过程中：
```markdown
MavInject.exe <PID> /INJECTRUNNING <PATH DLL>
```

![enter description here][8]

![enter description here][9]


参考资料 ：dll  https://gist.github.com/anonymous/b25cb82c4b3d40648f0b589fa242577f


![enter description here][10]
https://reaqta.com/2017/12/mavinject-microsoft-injector/  从假阳性到真阳性：微软注射器Mavinject.exe的故事
https://twitter.com/subTee/status/942779279623913473


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/14CCE2557B1CD2558BBFCA878F0EF92E.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513775930135.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513775561212.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513778423174.jpg 
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/events-768x180.png
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/proc-details-768x226.png
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513776172973.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DRGMJzHVQAEZMxn.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DRGMovJWsAAMNDD.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/052530D337AEFC1DDEC731D041FF3608.jpg