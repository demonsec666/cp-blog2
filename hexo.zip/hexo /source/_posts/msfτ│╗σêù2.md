---
title: Metaspolit系列第二课(即刻&低调)
date: 2017-03-14 22:13:03
tags: Metasploit
categories: Metasploit
---
  终于迎来了自己人生中的第一次系列课程，心中还是有些忐忑不安，怕视频效果不如以前的好，给你们带来不好的体验感
  简单的也就做了几课，算是最新的教程吧，目前还在加快录制，视频都是在休息的时候录制，最近上班也比较忙碌，望各位体谅。
  ![enter description here][1]
  <!--more-->
  &nbsp;
  &nbsp;
#   # 这次 做的是metaspolit系列课程2，也就作为即刻安全的回归的一个小彩蛋。
  &nbsp;
  &nbsp;
  ![enter description here][2]

&nbsp;
![enter description here][3]
 &nbsp;
 
#  # metaspolit 课程大纲---课程还在不停变换，希望能增加一些不一样的内容，视频也在不定期的录制
 
第一课：metasploit-vulnerability-emulator 搭建靶机与简单利用  -------已录制
&nbsp;
第二课：st2-045搭建和msf自定义添加st2漏洞rb  已录制 链接: https://pan.baidu.com/s/1c2BtAVm 密码: qgg4
<span style="color: #ff0000;">彩蛋----自己做的小视频，里面视频内容，代码皆可复制，https://asciinema.org/a/07zv6rq8ng2oypkp4ty48m7fj
&nbsp;</span>
![enter description here][4]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/punchabunch-just-made-ssh-local-forwarding-stupid-easy.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/jpg.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/QQ%E5%9B%BE%E7%89%8720170315090251.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/20170315124719.jpg 