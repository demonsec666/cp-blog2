---
title: Metasploit系列课程第六课
date: 2017-05-07 23:25:59
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
由于我的工作关系的，导致了课程更新缓慢，也是实在抱歉，过段时间我再将更新完整版的内容，首先看段我即将要讲的课程的内容！！！
增加几个powershell渗透点
第6课 metasploit&powershell 
链接: https://pan.baidu.com/s/1pLyiRLx 密码: cvsv
课程作业：
![enter description here][2]
<br>
Metasploit 系列课程整合 链接: https://pan.baidu.com/s/1dFzPkJZ 密码: evwg


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/maxresdefault-1.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/56427456-93B0-4712-B1E3-032182084091.png 