---
title: Secist_Script
date: 2017-08-25 19:32:11
tags: Metasploit
categories: Metasploit
---
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Secist_EN.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>




我已经做了这个脚本的视频并且做了中英文版
https://github.com/demonsec666/secist_script
并且我已经上传了Youtube
https://www.youtube.com/watch?v=Wg7HuU9Hypw&t=11s