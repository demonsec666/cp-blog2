---
title: test2
date: 2018-10-13 10:42:39
tags:
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/test2.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>

<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>



  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20181013_103635.jpg
