---
title: InfectPE
date: 2018-04-22 19:45:00
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/InfectPE.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


## 依赖关系
https://www.microsoft.com/en-us/download/details.aspx?id=53840


## 使用说明
.\InfectPE.exe .\input.exe .\out.exe code
X代码被注入代码段，这种方法更隐蔽，但有时代码段中没有足够的空间。

.\InfectPE.exe .\input.exe .\out.exe largest
X代码被注入到零个数最多的部分，使用这种方法可以注入更大的x代码。该方法修改了该部分的特征，并且更加可疑。

.\InfectPE.exe .\input.exe .\out.exe resize
展开代码段的大小并注入x代码。这种技术，就像“代码”一样，不太可疑，也可以注入更大的x代码。

.\InfectPE.exe .\input.exe .\out.exe new
创建一个新的部分并向其中注入x代码，该部分的硬编码名称是“.infect”

在补丁文件中，ASLR和NX被禁用，您可以分析VS项目的更多技术信息。

请不要使用打包或格式不正确的可执行文件。


![enter description here][2]

Github   https://github.com/secrary/InfectPE


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180422_194348_01.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B6255317-B3BE-44A1-A454-00CF11F06358.png 