---
title: Metaspolit系列课程第一课(即刻&低调群)
date: 2017-03-18 23:58:56
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
&nbsp;
## Dear 莱德斯and杰特们：
      感谢支持我们即刻安全推出的metasploit系列教程。
	  即刻安全从成立到现在，转眼已经半年多了。回头想想当初的我们，凭着一个梦想一股热血，跌跌撞撞的走到了现在。庆幸地是我们都未曾放弃！2017，即刻安全全新起航！感谢一路有你！！！
 &nbsp;
&nbsp;
	  <iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=27678674&auto=0&height=66"></iframe>
&nbsp;
&nbsp;
metaspolit 课程大纲---课程还在不停变换，希望能增加一些不一样的内容，视频也在不定期的录制
## 第一课：metasploit-vulnerability-emulator 搭建靶机与简单利用 -------已录制
链接: http://pan.baidu.com/s/1o8z4hho 密码: eskf
<span style="color: #ff0000;">彩蛋----自己做了个小视频 Babusb&metasploit结合 预览版，可后期继续关注-----metasploit(恶作剧之三部曲)</span>
	 
	 
&nbsp; 
&nbsp;
第二课：st2-045搭建和msf自定义添加st2漏洞rb  已录制 链接: https://pan.baidu.com/s/1c2BtAVm 密码: qgg4
<span style="color: #ff0000;">彩蛋----自己做的小视频，里面视频内容，代码皆可复制，https://asciinema.org/a/07zv6rq8ng2oypkp4ty48m7fj
&nbsp;</span>
![enter description here][2]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-ultimate-command-cheat-sheet-for-metasploits-meterpreter.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3B5C1B21-0B91-49F9-B872-0954604E3F68.png 