---
title: wmap和Metasploit 结合
date: 2017-01-13 19:23:19
tags: Metasploit
categories: Metasploit 
---
<h1>                          WMAP：Metasploit上的Web漏洞扫描</h1>
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=3&id=900175640&auto=1&height=66"></iframe>
<h3><strong><span style="color: #ff0000;">背景介绍：</span></strong></h3>

在Metasploit的项目是一个计算机安全项目，提供有关信息安全漏洞并辅助渗透测试和IDS特征的发展。其最知名的子项目是开源 Metasploit的框架，用于开发和执行工具漏洞对远程目标机器代码。其他重要的子项目包括操作码数据库的shellcode档案和相关的研究。使用Metasploit项目是众所周知的反取证和规避的工具，其中一些内置在Metasploit的框架。在这篇文章中，我将谈谈可以在Metasploit中加载的wmap。

Wmap是从SQLMap派生的工具，可以以类似的方式对Web应用程序执行漏洞检查。Metasploit也被支持作为模块类型，并且可以通过将主机和漏洞信息彼此连接来强有力地使用Metasploit。

<strong><span style="color: #ff0000;">在此之前先我看的相关演示！！！！！！！以下视频  ----可直接复制视频中的代码,重要事情重复三遍：复制视频中的代码！！！，复制视频中的代码！！！！！！！！！复制视频中的代码！！！！ ！ ！！！！！ 演示的比较烂，凑合着看吧，我对之前</span></strong>

Metasploitable 3 做的扫描！
  <link rel="stylesheet" type="text/css" href="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.css" />

  <asciinema-player src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciicast-99157.json" cols="80" rows="24"></asciinema-player>
  ...
  <script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.js"></script>


在Metasploit中使用WMAP

## load wmap
 在msfconsole，通过load WMAP 加载命令。
![enter description here][2]


使用  帮助 命令这个插件在浏览完命令
## 指定目标站点
使用wmap_sites的-a选项指定目标站点
![enter description here][3]


## 选项检查
 指定列表后，将使用-l选项检查在检查列表时创建的目标站点列表。
![enter description here][4]

## 扫描远程系统
 使用-d选项扫描远程系统，这允许在实际执行之前进行简单测试。
![enter description here][5]

## 进行测试
可以通过-e选项进行测试。

![enter description here][6]

## 进行验证
通过wmap发现的任何漏洞都存储在metasploit db中，并且可以通过## vulns命令进行验证。

![enter description here][7]


  


 


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/FBC8EF5D7ACDA78CCD1872EB29D2F8F3.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Screenshot-from-2017-01-02-08-09-52.png 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Screenshot-from-2017-01-02-08-13-21.png 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Screenshot-from-2017-01-02-08-14-17.png 
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Screenshot-from-2017-01-02-08-16-19.png 
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Screenshot-from-2017-01-02-08-17-27.png 