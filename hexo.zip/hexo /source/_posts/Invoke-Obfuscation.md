---
title: Invoke-Obfuscation
date: 2018-09-24 19:10:20
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Invoke-Obfuscation.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

![enter description here][2]

https://github.com/danielbohannon/Invoke-Obfuscation

![enter description here][3]
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;
![enter description here][6]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7CEE01B612EC999D80CA935044556386.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1537787487517.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/650F50FBBD4AD6F9B8CAB7ED40739A52.jpg 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1E6A50AD0E8313871D54FA59E86A3C44.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7F7BEAC1C4C6AC8F3D2DE7A48F090C6B.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7186DD880F1602FB2089AA853C976538.jpg