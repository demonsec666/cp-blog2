---
title: kali2017.1安装vmtools 安装方法
date: 2017-05-07 23:25:59
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
<span style="font-size: 100%;">在虚拟机中安装kali2.0后，会经常遇到安装vmware tools无法成功，或者提示安装成功了但是仍旧无法进行文件拖拽、复制和剪切的问题。本人试用了很多方法，总算摸索出一种简单有效的方法。这种方法只针对kali2.0有效，其他版本kali未测试。</span><span style="font-size: 100%;">注意！注意！注意！不能安装VMware Workstation中自带的VMware tools，否则以下方法不能成功。
</span>
<span style="font-size: 100%;">步骤1、换源。</span>
官方软件源: <pre>deb http://http.kali.org/kali  kali-rolling contrib main non-free</pre>
<span style="font-size: 300%;">          由于kali自己的源很慢，所以我们把它换成国内的。</span>
清华大学软件源：<pre>deb http://mirrors.tuna.tsinghua.edu.cn/kali  kali-rolling contrib main non-free</pre>
<span style="font-size: 100%;">在终端中使用命令：
<pre>leafpad /etc/apt/sources.list</pre>
<span style="font-size: 300%;">打开后把上面的源加进去，然后把kali的源注释掉，即在行首加#。这样在更新时就会非常快。</span>
<span style="font-size: 300%;">2、更新系统和软件</span>
<pre>apt-get update && apt-get upgrade</pre>
3、安装vm-tools
<pre>apt-get install open-vm-tools-desktop fuse</pre>
<span style="font-size: 300%;">所有安装默认设置即可。</span>
<span style="font-size: 300%;">4、重启</span>
<span style="font-size: 300%;">reboot</span>
<span style="font-size: 300%;">重启后稍等一会，ＯＫ就可以进行文件的拖拽了！</span>
![enter description here][2]
&nbsp;

注：转自出处            ----------http://www.kali.org.cn/thread-21836-1-1.html


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/fbfc818b5b9cb9733f995d1facf45cc3.png 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/SEU_%7DRVT@V20VY29DW3%5D7%5B1.png