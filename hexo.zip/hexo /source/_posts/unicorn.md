---
title: unicorn
date: 2018-03-29 22:58:25
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/unicorn.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>



![enter description here][2]

![enter description here][3]

![enter description here][4]

独角兽是使用PowerShell降级攻击并直接将shellcode插入内存的简单工具。基于Matthew Graeber的PowerShell攻击和由David Kennedy（TrustedSec）和Josh Kelly在Defcon 18提供的PowerShell旁路技术。

用法很简单，只需运行Magic Unicorn（确保在使用Metasploit方法并在正确的路径中安装Metasploit），魔术独角兽会自动生成一个PowerShell命令，您只需将PowerShell代码剪切并粘贴到命令行窗口或通过有效载荷传送系统。独角兽支持你自己的shellcode，和Metasploit
 Github: https://github.com/trustedsec/unicorn

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/A1AD5A55650233CB348CED3EDADABB20.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/E082C7CCF73ECE8B70821370D5F20497.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1576F05082484EC46728F8F7A14285A5.jpg 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/FB04BA3559E021548BC7D695AC92E556.jpg 