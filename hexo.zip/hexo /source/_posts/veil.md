---
title: veil
date: 2016-10-24 20:03:03
tags: Metasploit
categories: kali
---
![enter description here][1]
<!--more-->
<h2>                                                 手工测试Veil-Evasion和Dirty COW</h2>
<h2>                                                  前言----（先是一堆废话）</h2>
由于群里有小伙伴问我，测试Dirty COW出现的各种蛋疼的问题，索性我将我当时做的视频发出来，网上也有很多相关的类是资料，我这里就不详细描述了（<strong><span style="color: #ff0000;">文中提及的部分技术可能带有一定攻击性，仅供安全学习和教学用途，禁止非法使用</span>）</strong>

手工测试（视频一）veil Evasion
  <h1 id="一言不合的请猛击一下下列视频"><a href="#测试视频播放" class="headerlink" ></a></h1><hr>

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/veil.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>
 
手工测试Eternal的veil-Evasion，通过veil-Evasion生成免杀木马和Metasploit反弹shell 来结合，能大部分绕过防火墙和360，最后经过NFTS数据流隐藏的特性进行隐藏。

本地搭建实验环境：360（五引擎，已打上各种补丁）

自己的笔记本：win8.1

本地虚拟机：kali linux 2.0
本地虚拟机：xp SP3

在veil-Evasion中11号的模块中，本人测试了一下 ，发现生成了4kb的木马，依然能运行绕过360，但是有可能躲不过360的云查杀机制。




参考资料 ： <a href="http://www.secist.com/archives/1107.html">http://www.secist.com/archives/1107.html</a>      免杀后门之MSF&amp;Veil-Evasion的完美结合。


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-metasploit-for-aspiring-hacker-part-6-gaining-access-tokens.1280x600.jpg