---
title: 国外优秀hacking教程吐血推荐！!
tags: hacking教程
categories: linux
date: 2016-12-12 16:35:40
---

<span style="color: #ff0000;">**国内有国内的圈子，国外有国外的圈子。国外的圈子真的是让我大开眼界啊！！！**</span>
<!--more-->
不多说了看看福利概览吧。以下视频需翻墙：免费翻墙可参考我的好基友 国光   www.sqlsec.com/436.html    xx-net科学上网简明使用教程<span id="more-2718"></span>

<span style="color: #ff0000;">**xxnet 下载链接**：</span>没错！你没有听错在本群可以下载 ！你还在等着什么，拿起你的手机赶快加入吧！！！

&nbsp;

视频当中这位小哥针对 <span style="color: #ff0000;">metaspolitable2</span> 进行了较为全面的渗透实验，（国内大部分都是针对 windows 的 msf 渗透和漏洞利用，但他对 linux 环境下的渗透进行了尝试和实验，包括提权）其中大部分用到的思路，是非常值得我们学习和借鉴的。虽然看视频有的地方不是特别理解，但是小哥对渗透的思路非常清晰，整整几个小时我都没离开过屏幕，我只能说真的非常精彩！感谢这位小哥，给我们带来的精彩渗透过程！！！

&nbsp;

#               ** <span style="color: #ff0000;"> (针对Metasploitable2 进行全面性的渗透测试）</span>**<span style="color: #ff0000;">   Hacking Metasploitable Live!(**第一集**)</span>

**教程视频传送门：<span style="color: #008000;">http://www.youtube.com/watch?v=jDq-mEY_3zY&amp;t=1625s&amp;index=3&amp;list=PL17Q7Iw6SshlCNN1pVIkFR4B4mXBqPRdD    </span>   （总时长2小时58分）**

![89ecf3a3-9733-4708-8df8-f0194a29bfc1](http://www.secist.com/wp-content/uploads/2016/12/89ECF3A3-9733-4708-8DF8-F0194A29BFC1.jpg)

&nbsp;

&nbsp;

# <span style="color: #ff0000;">(针对Metasploitable2 进行全面性的渗透测试） Hacking MetasploitableLive!(第二集)</span>

传送门：<span style="color: #ff0000;">www.youtube.com/watch?v=JoV1aSuy1XU&amp;index=4&amp;list=PL17Q7Iw6SshlCNN1pVIkFR4B4mXBqPRdD(总时长**：3小时41分)**</span>

![1ef68806-6637-4400-86ed-e38d3b6f77b4](http://www.secist.com/wp-content/uploads/2016/12/1EF68806-6637-4400-86ED-E38D3B6F77B4.jpg)

&nbsp;

&nbsp;

# <span style="color: #008000;">(针对Metasploitable2 进行全面性的渗透测试） Hacking Metasploitable Live!(第三集)</span>

传送门：**<span style="color: #ff0000;">www.youtube.com/watch?v=8z12kdEw2v8&amp;list=PL17Q7Iw6SshlCNN1pVIkFR4B4mXBqPRdD&amp;t=33393s&amp;index=1</span> （总时长3小时08分）**

![2038b7e3-e979-4e91-a6cb-668961a798ec](http://www.secist.com/wp-content/uploads/2016/12/2038B7E3-E979-4E91-A6CB-668961A798EC.jpg)

&nbsp;

# <span style="color: #ff0000;"> </span>

# <span style="color: #ff0000;">看到这里，我就说一句：谁敢说我不帅？？？？？？还有谁？</span>

![u33461481831982471518fm23gp0](http://www.secist.com/wp-content/uploads/2016/12/u33461481831982471518fm23gp0.jpg)![u41088629651515976869fm23gp0](http://www.secist.com/wp-content/uploads/2016/12/u41088629651515976869fm23gp0.jpg)

&nbsp;

# <span style="color: #ff0000;">MSF 精华合集</span>

### **<span style="color: #ff0000;">Metasploit</span>  献给那些喜欢msf的朋友们 ——-传送门：<span style="color: #008000;">www.youtube.com/watch?v=8z12kdEw2v8&amp;list=PL17Q7Iw6SshlCNN1pVIkFR4B4mXBqPRdD&amp;index=1&amp;spfreload=10</span>    （由ZANYAR MATRIX  发布的最新合集版  发布在YouTube 今年11月份 总时长13小时02分）**

![2bbf222e-61cc-4b29-af75-9e6f3583497d](http://www.ggsec.cn/wp-content/uploads/2016/12/2BBF222E-61CC-4B29-AF75-9E6F3583497D-1024x569.jpg)