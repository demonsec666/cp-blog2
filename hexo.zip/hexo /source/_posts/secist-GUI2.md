---
title: Secist_GUI2
date: 2017-08-06 22:36:31
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
    github => https://github.com/demonsec666/secist_GUI#secist_gui
继 http://www.ggsec.cn/secsit-GUI.html 之后 我将之前的https://github.com/demonsec666/secist_script  命令行版 改写成ruby版 使用GTK、xterm等 环境开发，进行一些小小的改动和编写。其中在xterm 中 使用鼠标将字体选中 是复制 ，Shift-insert是粘贴
   如果有更好的建议或者代码可优化的话 可以联系我，非常感谢！！！！！
 &nbsp;
![enter description here][2]
## 环境安装
<pre>
1. git clone https://github.com/demonsec666/secist_GUI.git
2. chmod -R 777 .
3. ./setup
4. wine tdm64-gcc-5.1.0-2\ \(1\).exe 
</pre>

![enter description here][3]
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist_GUI2.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/8316A7265788A8F69153846ECABD9C65.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502031157087.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1502031320810.jpg