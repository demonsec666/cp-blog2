---
title: Metasploit系列课程第四课
date: 2017-04-09 00:03:23
tags: [Metasploit,kali]
categories: Metasploit
---
![enter description here][1]
<!--more-->
&nbsp;
&nbsp;
&nbsp;
## 第四课：metasploit之绕过某安全防护(恶作剧三部曲,曲二)
&nbsp;
免杀后门过某安全防护----web_delivery
&nbsp;
由于忙于工作和学习，却断更了这么长时间，也是非常抱歉！！！个人水平有限，讲的不是很到位，望各位多多包涵！！！！！
这次针对web-delivery 这个模块进行了一次全面补充讲解。http://www.ggsec.cn/msf-web-delivery.html
<br>
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=28157586&auto=0&height=66"></iframe>
## 百度云
附上视频+ppt+相关代码——链接: https://pan.baidu.com/s/1eR5BaBC 密码: ppjf
<br>
![enter description here][2]
<br>

https://github.com/demonsec666/secist_script    个人临时写的，对针对某个模块编写，简单的完成自动化脚本。（shell）
<br>
![enter description here][3]
<br>
![enter description here][4]
<br>

## 相关代码本人演示代码地址：

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！！</span></strong>

&nbsp;

<link rel="stylesheet" type="text/css" href="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.css" />

  <asciinema-player src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist_script.json" cols="100" rows="30"></asciinema-player>
  ...
  <script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.js"></script>

&nbsp;


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/Unknown.jpeg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/5E878371-E9A9-4ACE-B474-60193EF4EB03.png 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/D0265964-DCC5-4C80-879B-F4FA2A9038B3.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B91D4717-4FDA-4E42-9459-70797127E558.png