---
title: Fimap_Metasploitable2漏洞攻击
date: 2017-03-19 17:18:54
tags: kali
categories: kali
---
![enter description here][1]
<!--more-->
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=31090440&auto=0&height=66"></iframe>
## 简介
Fimap是一款本地及远程的文件包含漏洞检测工具，并能对检测到的漏洞进行利用，带了一个google的语法搜索功能，这款工具只针对文件包含漏洞的检测及利用.
&nbsp;
&nbsp;
本次使用到的环境：docker_kali      攻击者
                                metasploitable2 靶机环境
&nbsp;
## kali中自带的工具:fimap						
	<p> -H，--harvest
	模式为新URL收集URL。 需要一个根网址（-u）开始在那里爬网。   还需要（-w）为质量模式编写URL列表
	&nbsp;	
	  -d，--depth = CRAWLDEPTH
	  您希望在收获模式（-H）下爬网目标网站的CRAWLDEPTH（递归级别）。默认值为1.
	   &nbsp;
	  -x，--exploit
	  启动一个交互式会话，您可以在其中, 选择一个目标并执行某些操作
	  &nbsp;
	 -C，--enable-color
        --force-run忽略实例检查，只要运行fimap。</p>
	  &nbsp;
例子：
	1. 简单扫描
        ./fimap.py -u 'http://localhost/test.php?file=bang&id=23'
    2. 使用列表进行扫描
        ./fimap.py -m -l '/tmp/urllist.txt'
    3. 使用谷歌语法搜索
        ./fimap.py -g -q 'inurl:include.php'
    4. 收集递归等级为3和的网页的所有链接  将URL写入 /tmp/urllist
        ./fimap.py -H -u 'http://localhost' -d 3 -w /tmp/urllist
		参考资料：http://tools.kali.org/web-applications/fimap
## 视频
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="//cytroncdn.videojj.com/latest/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/fimap_metasploitasble2.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="//cytroncdn.videojj.com/latest/Iva.js"></script>

&nbsp;
&nbsp;
1.本次使用到的是metaspolitable2 靶机环境 ，我们打开浏览器输入该靶机的 ip
&nbsp;
&nbsp;
![enter description here][2]
&nbsp;
&nbsp;
2.使用fimap的例子4 进行尝试检测 ：
<pre>fimap -H -u http://localhost -d 3 -w /tmp/urllist </pre>
			   ![enter description here][3]
 &nbsp;
 &nbsp;
  3.在上图中可以看到，对dvwa/dav/twiki/等进行扫描，图中对Mutillidae扫描的列表比较多。<br>
<pre>mutillidae是一个免费，开源的Web应用程序，提供专门被允许的安全测试和入侵的Web应用程序。它是由Adrian “Irongeek” Crenshaw和Jeremy “webpwnized” Druin.开发的一款自由和开放源码的Web应用程序。其中包含了丰富的渗透测试项目，如SQL注入、跨站脚本、clickjacking、本地文件包含、远程代码执行等.</pre><br>
对检测到的漏洞进行攻击，并忽略实例检查：
 <pre>fimap -x  --force-run</pre>	
 ![enter description here][4]
  &nbsp;
  &nbsp;
 
 4.填写目标序列号1 。进入漏洞url列表，选择漏洞id 如选择1。
![enter description here][5]
 &nbsp;
 &nbsp;
5、执行攻击 选择攻击模式。如选择1
![enter description here][6]
 &nbsp;
 &nbsp;
 使用fimap 反弹shell 得到回话、
 ![enter description here][7]
 &nbsp;
 &nbsp;
![enter description here][8]





  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-linux-basics-for-aspiring-hacker-part-10-manipulating-text.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/88D2C627-A21A-4D32-BA8F-A99B10295CEA.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/ED9EF7FC-9179-4DEC-8518-943F955A63E9.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/E8C58339-2B1A-4DBF-9838-1D184DA11C86.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1A11FB48-777A-4832-83F5-F9030962F822.png
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/5EA09A65-D9CE-465E-9691-11EDBB932620.png
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B7414489-7646-473D-B6C8-FF55C9DBA1AE.png
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/49F45637-F5EF-45F6-A1D5-07A5F624F421.png