---
title: kali 2017|MSF|BypassUAC
date: 2017-06-18 11:39:49
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/2017-BypassUAC.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


Windows UAC保护绕过（通过FodHelper注册表项）

该模块将通过在当前用户配置单元下劫持注册表中的特殊密钥来插入Windows 10 UAC，并插入在启动Windows fodhelper.exe应用程序时调用的自定义命令。它会产生一个关闭UAC标志的第二个shell。此模块修改注册表项，但一旦调用了有效负载，就会清除该密钥。该模块不需要有效载荷的架构来匹配操作系统。如果在单独的进程中启动有效负载后指定EXE :: Custom，您的DLL应该调用ExitProcess（）。

相关连接https://www.rapid7.com/db/modules/exploit/windows/local/bypassuac_fodhelper

已上传youtube https://youtu.be/EJGig3uQcFQ


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/2017-BypassUAC.png 