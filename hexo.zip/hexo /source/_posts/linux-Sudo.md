---
title: linux_Sudo
date: 2018-09-09 12:15:01
tags:
---
![enter description here][1]
<!--more-->
![enter description here][2]
http://touhidshaikh.com/blog/?p=790
https://gtfobins.github.io/

![enter description here][3]

![enter description here][4]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/4A5639C6FA9AEB5050270C566CE106AC.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/653C3272689DB0EC26F89F4EC107B261.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/6E15074C1E61F3CE16782A8DD6F3F521.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DF68B314698D17048E992ADAD2FB5A6E.jpg 