---
title: secsit_GUI
date: 2017-07-20 22:40:58
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->

 本次使用ruby 重新对之前的shell脚本 框架重新编写，使用GTK、xterm等 环境开发
 由于手受伤了 还缝针了，本来计划本月可以写完，但是估计可能需要你们耐心等待到下月了，感谢支持
 先一步看下预览版
 github ：https://github.com/demonsec666/secist_script
 ## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/secistGUI.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7AF7C4BFBF0F184301F3B047CDFC69A5.png 