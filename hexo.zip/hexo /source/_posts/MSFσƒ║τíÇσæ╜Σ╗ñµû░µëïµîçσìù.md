---
title: MSF基础命令新手指南
tags: Metasploit
categories: Metasploit
date: 2016-11-23 20:09:03
---
![enter description here][1]
# <span style="color: #ff0000;">基础命令概览</span>：

&nbsp;

**<span style="color: #ff0000;">back</span> ** （返回）：                  从目前的情况下向后移动
<!--more-->
<span style="color: #ff0000;">**banner** </span>：Display an awesome metasploit banner
cd：                        改变当前的工作目录
color：                    切换颜色
<span style="color: #ff0000;">**connect**</span>（远程连接）：              与主机通信
<span style="color: #ff0000;">**edit** </span>（编辑）：                     编辑与$ VISUAL或$ EDITOR当前模块的
<span style="color: #ff0000;">**exit**</span> （退出命令行）：                     退出控制台
get （获取变量）：                      获取特定上下文变量的值
getg （全局获取变量）：                    获取一个全局变量的值
go_pro ：                 启动Metasploit的网页图形用户界面

grep： grep的另一个命令的输出
<span style="color: #ff0000;">**help**</span>（帮助） ：                      帮助菜单
<span style="color: #ff0000;">**info**</span>（获取模块信息）：                       关于一个或多个模块显示信息
<span style="color: #ff0000;">**irb**</span>：                          进入irb脚本模式
<span style="color: #ff0000;">**jobs**</span>：显示和管理职位
<span style="color: #ff0000;">**kill**</span>（结束进程）：                           结束一个进程
<span style="color: #ff0000;">**load** </span>（加载）：                        加载一个框架插件
loadpath ：                 搜索和负载从一个路径模块
makerc：                     保存自开始进入到一个文件中的命令
popm：                        弹出最新的模块从堆栈中并使其活跃

previous ：                   将以前加载模块作为当前模块
pushm ：                     推主动或模块列表在模块栈
quit （退出控制台）：                           退出控制台
reload_all Reloads ：   从所有定义的模块路径的所有模块
rename_job ：              重命名工作
resource ：                   运行存储命令在文件
<span style="color: #ff0000;">**route** </span>：                       通过会话路由流量
save：                           将数据存储主动
<span style="color: #ff0000;">**search**</span>（搜索exp等模块关键字）：                       搜索模块的名称和说明
<span style="color: #ff0000;">**sessions**</span>（会话功能）：                    转储会话列表和显示有关会话的信息

<span style="color: #ff0000;">**set**</span> （设置参数）：                            设置一个特定的上下文变量的值
<span style="color: #ff0000;">**setg**</span>（全局设置参数）：                          设置一个全局变量的值
<span style="color: #ff0000;">**show** </span>（展示参数模块）：                        给定类型的显示模块或所有模块
sleep ：                        什么都不做对的指定秒数
spool ：                        写控制台输出到一个文件以及屏幕
threads ：                    查看和操作后台线程
<span style="color: #ff0000;">**unload （卸载某个插件）**</span>：                    卸载一个框架插件
<span style="color: #ff0000;">**unset （删除某个设置参数）**：                      取消设置一个或多个特定的上下文变量</span>
<span style="color: #ff0000;"> **unsetg （取消全局某个设置参数）**</span>：                   取消设置一个或多个全局变量的
<span style="color: #ff0000;">**use** </span>（使用某个模块）：                         选择按名称模块
version（查看版本信息）：                    显示的框架和控制台库版本号

&nbsp;

# **<span style="color: #ff0000;">   命令作用详解</span>：**

&nbsp;

# <span style="color: #ff0000;">**back：**</span>

切换上下模块

一旦你已经完成了工作与一个特定的模块,或者如果你无意中选择了错误的模块,你可以“恢复”命令将当前上下文。

![nkwmki_bdtzz0jamq04](http://www.secist.com/wp-content/uploads/2016/11/NKWMKI_BDTZ@Z0JAMQ04.png)

# <span id="check" class="mw-headline" style="color: #ff0000;">check：</span>

检查exp是否有效，检查各项参数是否设置正确

![n5p8um6vc2ttnmuy8](http://www.secist.com/wp-content/uploads/2016/11/N5P8UM6VC2TTNMUY8.png)

&nbsp;

# <span style="color: #ff0000;">**<span id="connect" class="mw-headline">connect：</span>**</span>

通过发行“连接”命令有一个ip地址和端口号,你可以连接到一个远程主机从内部msfconsole一样你会netcat或telnet。

![koofynl2r6mcdsuq](http://www.secist.com/wp-content/uploads/2016/11/KOO@FYNL2R6MCDSUQ.png)

# <span style="color: #ff0000;">**<span id="exit" class="mw-headline">exit：</span>**</span>

退出命令行

![9_epcpib311dbr2hqm](http://www.secist.com/wp-content/uploads/2016/11/9_EPCPIB311DBR2HQM.png)

&nbsp;

# <span style="color: #ff0000;">**help：**</span>

列出命令和帮助信息

![dwn3sm1ycmyk00w6ml](http://www.secist.com/wp-content/uploads/2016/11/@DWN3SM1YCMYK00W6ML.png)

&nbsp;

# <span style="color: #ff0000;">**<span id="info" class="mw-headline">info：</span>**</span>

info命令将提供关于一个特定模块的详细信息包括所有选项,目标,和其他信息。之前一定要总是读模块描述使用一些可能un-desired效果。

![goxcqjd5jx7jiqou1_q](http://www.secist.com/wp-content/uploads/2016/11/GOXCQJD5JX7JIQOU1_Q.png)

&nbsp;

# <span style="color: #ff0000;">jobs：</span>

（查看已后台运行的模块，如会话等。）

工作是在后台运行的模块。工作命令提供了列表和终止这些工作的能力。

![xxulgrjd7c4xmubybxuq](http://www.secist.com/wp-content/uploads/2016/11/XXULGRJD7C4@XMUBYBXUQ.png)

# <span id="kill" class="mw-headline" style="color: #ff0000;">kill：</span>

kill命令将结束任何运行时工作提供的id

msf exploit(ms08_067_netapi) &gt; kill 0
Stopping job: 0…

[*] Server stopped.

&nbsp;

# <span id="load" class="mw-headline" style="color: #ff0000;">load：</span>

从Metasploit load命令加载插件的插件目录。参数是作为关键= val shell传递。

&nbsp;

# <span id="loadpath" class="mw-headline" style="color: #ff0000;">loadpath</span>

loadpath命令将可以跳转到第三方模块加载树的路径你可以点Metasploit 0-day利用、编码器、载荷等。

# 

# <span style="color: #ff0000;">**<span id="unload" class="mw-headline">unload：</span>**</span>

卸载模块插件

&nbsp;

# <span id="route" class="mw-headline" style="color: #ff0000;">route：</span>

Metasploit的“路线”命令允许您通过一个会话路由套接字或“通讯”,提供基本的旋转功能。添加一个路线,你通过目标子网和网络掩码会话(通讯)数量紧随其后。

meterpreter &gt; <span style="color: #ff0000;">route</span>

Network routes
==============

Subnet Netmask Gateway
—— ——- ——-
0.0.0.0 0.0.0.0 172.16.1.254
127.0.0.0 255.0.0.0 127.0.0.1
172.16.1.0 255.255.255.0 172.16.1.100
172.16.1.100 255.255.255.255 127.0.0.1
172.16.255.255 255.255.255.255 172.16.1.100
224.0.0.0 240.0.0.0 172.16.1.100
255.255.255.255 255.255.255.255 172.16.1.100

&nbsp;

# <span style="color: #ff0000;">**<span id="search" class="mw-headline">search：</span>**</span>

msfconsole包括一个广泛的基于正则表达式的搜索功能。如果你有一个总体的想法你正在寻找你可以通过“搜索”搜索。在下面的输出中,搜索是ms08-067。搜索功能将在模块定位这个字符串名称、描述、参考文献等。

![549d8865-7ace-4aa6-b731-b8d097a88c82](http://www.secist.com/wp-content/uploads/2016/11/549D8865-7ACE-4AA6-B731-B8D097A88C82.png)

&nbsp;

# <span style="color: #ff0000;">**<span id="help_2" class="mw-headline">help:</span>**</span>

搜索关键字

![zd9gxx24q6ys9wg7](http://www.secist.com/wp-content/uploads/2016/11/ZD9GXX24Q6YS@9WG7.png)

&nbsp;

# <span style="color: #ff0000;">**<span id="name" class="mw-headline">name：</span>**</span>

&nbsp;

![_yj4ceix1q0z8cw5yg](http://www.secist.com/wp-content/uploads/2016/11/YJ@4CEIX@1Q0Z8CW5YG.png)

# <span id="path" class="mw-headline" style="color: #ff0000;">path：</span>

搜索路径

# <span style="color: #ff0000;">**<span id="type" class="mw-headline">type：</span>**</span>

搜索模块类型

# <span style="color: #ff0000;">**<span id="platform" class="mw-headline">platform：</span>**</span>

您可以使用“platform”来缩小你的搜索范围,影响特定平台的模块。

![8ckrrjecf17691_61h9y](http://www.secist.com/wp-content/uploads/2016/11/8CKRRJECF17691_61H9Y.png)

# <span id="sessions" class="mw-headline" style="color: #ff0000;">sessions</span>

“会话”命令允许您列出,与交互,并杀死了会话。会话可以壳,Meterpreter会话,VNC,等等。

&nbsp;

# <span style="color: #ff0000;">**<span id="set" class="mw-headline">set:</span>**</span>

“设置”命令允许您配置框架选项和参数为当前模块处理。

![boysu_v7rzlg4g_vs](http://www.secist.com/wp-content/uploads/2016/11/BOYSU_V7RZLG4G_VS.png)

# <span id="unset" class="mw-headline" style="color: #ff0000;">unset:</span>

取消设置

&nbsp;

msf exploit(handler) &gt; show options

Module options (exploit/multi/handler):

Name Current Setting Required Description
—- ————— ——– ———–
Payload options (windows/meterpreter/reverse_tcp):

Name Current Setting Required Description
—- ————— ——– ———–
EXITFUNC         process          yes           Exit technique (Accepted: ”, seh, thread, process, none)
LHOST           192.168.1.107   yes The listen address
LPORT           4444                yes The listen port
Exploit target:

Id Name
— —-
0 Wildcard Target
msf exploit(handler) &gt; unset lhost 192.168.1.107
Unsetting lhost…
Unsetting 192.168.1.107…
msf exploit(handler) &gt; show options

Module options (exploit/multi/handler):

Name Current Setting Required Description
—- ————— ——– ———–
Payload options (windows/meterpreter/reverse_tcp):

Name Current Setting Required Description
—- ————— ——– ———–
EXITFUNC      process            yes            Exit technique (Accepted: ”, seh, thread, process, none)
LHOST                                     yes       The listen address
LPORT           4444                   yes            The listen port
Exploit target:

Id Name
— —-
0 Wildcard Target

&nbsp;

# **<span id="setg" class="mw-headline"><span style="color: #ff0000;">setg</span>:</span>**

全局变量设置

&nbsp;

# <span id="auxiliary" class="mw-headline" style="color: #ff0000;">auxiliary</span>

执行“显示辅助”将显示清单Metasploit内所有可用的辅助模块。如前所述,辅助模块包括扫描仪、拒绝服务模块,fuzz等等。

&nbsp;

# <span id="exploits" class="mw-headline" style="color: #ff0000;">exploits</span>

自然,“展示利用”将命令你最感兴趣的运行以来的核心,Metasploit就是剥削。展示利用的运行以获得一个清单中包含的所有功绩的框架。

![qo0tw46zzmxtxo4u6y](http://www.secist.com/wp-content/uploads/2016/11/QO0TW46ZZMXTXO4U6Y.png)

&nbsp;

# **<span id="payloads_2" class="mw-headline"><span style="color: #ff0000;">payloads：</span>展示所有有效的攻击载荷</span>**

正如您可以看到的,有很多可用的有效载荷。幸运的是,当你在一个特定的背景下开发,运行显示有效载荷的只会显示特定的载荷,兼容利用。例如,如果它是一个Windows开发,你将不会显示Linux载荷。

![h3a2fmezdqrjqwnq](http://www.secist.com/wp-content/uploads/2016/11/H3A2FMEZDQRJQWNQ.png)

# <span style="color: #ff0000;">**<span id="options" class="mw-headline">options：</span>**</span>

msf exploit(ms08_067_netapi) &gt; show options

Module options:

Name           Current    Setting       Required     Description
—- ————— ——– ———–
RHOST                                yes The target address
RPORT              445            yes Set the SMB service port
SMBPIPE      BROWSER           yes The pipe name to use (BROWSER, SRVSVC)

Exploit target:

Id Name
— —-
0 Automatic Targeting

&nbsp;

# <span style="color: #ff0000;">**<span id="targets" class="mw-headline">targets：</span>**</span>

<div id="inputMod" class="column fl">
<div class="wrapper"><form id="transForm" action="http://fanyi.youdao.com/" method="post" name="transForm">
<div class="row"></div>
</form></div>
</div>
<div id="outputMod" class="column fr">
<div class="wrapper">
<div id="translated">
<div class="row">
<div id="outputText" class="row">
<div class="translated_result">

如果你不确定一个操作系统很容易受到特定的开发,运行显示目标的命令从一个开发模块的上下文中看到哪些目标是支持。![37c57579-b362-4aa4-a897-f183be9ca2ea](http://www.secist.com/wp-content/uploads/2016/11/37C57579-B362-4AA4-A897-F183BE9CA2EA.png)

# <span id="use" class="mw-headline" style="color: #ff0000;">use:</span>

当你已经决定在一个特定的模块使用,使用的命令以选中它。使用的命令改变你的环境到一个特定的模块,将特定类型的命令。注意在下面的输出任何以前的全局变量设置已经配置

</div>
</div>
</div>
</div>
</div>
</div>
![c1ba23bb-8698-4be5-bf09-cc48d5392177](http://www.secist.com/wp-content/uploads/2016/11/C1BA23BB-8698-4BE5-BF09-CC48D5392177.png)

Demon   2016.11.22

参考资料：https://www.offensive-security.com/metasploit-unleashed/msfconsole-commands/


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-metasploit-for-aspiring-hacker-part-10-finding-deleted-webpages.1280x600.jpg 