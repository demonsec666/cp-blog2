---
title: Pastezort|MSF|Powershell |kali linux 2017
date: 2017-09-13 22:42:09
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->

<pre>今天看到一个国外不错的视频是通过讲msf的payload，生成powershell以及base64代码，嵌入到js当中，js复制
内容到剪贴板，比较隐蔽。那个payload 我之前http://www.ggsec.cn/Metasploit6.html msf第6课有出现
过，但是没有像他那样出现在网页当中，思路也是不错的。
</pre>
GitHub： https://github.com/ZettaHack/PasteZort
youtube：https://www.youtube.com/watch?v=3Q0xqbDP1Cc 

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/PasteZort.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

## 1.下载并运行
<font color="#FF0000"><pre>
git clone https://github.com/ZettaHack/PasteZort.git
</pre></font>
<font color="#FF0000"><pre>
python PasteZ0rt.py 
</pre></font>

![enter description here][2]

## 2.选择平台
选择目标平台，我这里已windows为主，选择1号 windows。
![enter description here][3]

## 3.选择payload
选择msf的payload，我这边选择的还是1，（个人还是比较喜欢以windows/meterpreter/reverse_tcp为主）
![enter description here][4]


## 4.填写IP和端口
![enter description here][5]

![enter description here][6]

## 5.随意填写一些网页信息，并同时开启apache服务

![enter description here][7]

 6.可以看到红色字体区域有个地址
![enter description here][8]

7.打开地址我们可以看到 我们刚刚随意输入的一些内容
![enter description here][9]

8.可以看到 内容隐藏这一些powershell的恶意代码，如果用户不小心点击 或者复制其内容 ，却容易中招
![enter description here][10]

9.开启msf监听 ，选择y
![enter description here][11]

已经自动化帮我们设置完毕
![enter description here][12]


10.将demon secist这些文字内容复制到cmd中运行，得到会话
![enter description here][13]

![enter description here][14]

powershell进程开启，杀软并无反应
![enter description here][15]

得到最终会话
![enter description here][16]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/attack-vulnerable-practice-computer-guide-from-scan-shell.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383015483.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383578206.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383636049.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383836319.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383879631.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383922766.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383939438.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505383984321.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505384146550.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505384364997.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505384574985.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505384314337.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505385071941.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505385328692.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505385603886.jpg 