---
title: 登录暴力破解 | 逆向笔记(一)
date: 2017-09-30 19:53:19
tags: 逆向
categories:  逆向
---
![enter description here][1]
<!--more-->
前阵子ONDragon之前在群中了做了一个公开课，我觉得蛮受用的。决定和各位分享下，自己的过程，同时也是给我自己做个笔记。

## 1.源代码

```markdown
#include <stdio.h>
#include <windows.h>
#include <stdio.h>
#include <iostream>
using namespace std;
string userName("ONDragon"), passWord("666");   \\设定用户名密码
#define  Log(str) {{printf("[Log] => %s\n",str);}}
BOOL check(string name, string pass)
{
	if ( name.empty() || pass.empty() )
	{
		return FALSE;
	}
	if (name == userName && pass ==passWord)   \\判断用户名和密码是否正确，逻辑判断
	{
	 return TRUE;
	} 
	else
	{
		return FALSE;
	}
}
int main()
{
	Log("Begain Main");   
	char name[100];   \\定义用户名和密码是char类型
	char pass[100];
	while (TRUE)
	{
		cout << "Please input your userName :" << endl;     \\输入用户名和密码
		cin >> name;
		cout << "Please input your passWord :" << endl;
		cin >> pass;
		if (check(string(name), string(pass)))    \\关键函数check
  	{
			Log("Login Successful");   \\登录成功
			Sleep(5000);
			return 1;
		}
		else
		{
			Log("Login Failed");    \\否则失败就会循环重复输入用户名密码
		}
	}
	Log("End Main");
	return 0;
}
```
&nbsp;








## 2.编译运行
```markdown
root@demon:~# ls
  FirstClass.cpp
root@demon:~# i586-mingw32msvc-g++  -o secist.exe FirstClass.cpp
FirstClass.cpp:61:2: warning: no newline at end of file
root@demon:~# wine secist
[Log] => Begain Main
Please input your userName :
1123
Please input your passWord :
123
```

![enter description here][2]

因为本机是OSX 懒得用windows下编译，我这里直接用mingw32 编译，用wine运行，结果是输错账户密码，循环让用户输入，直到正确的用户名和密码。
&nbsp;






## 3.载入IDA

将secist.exe 拖入IDA查看下流程图，看下程序是如何运行

![enter description here][3]

这里我们需要将他跳到


这里很明显可以看到，从程序入口点到键入用户名和密码，是如何循环的
1.JNZ : jump if not zero 结果不为零则转移，单标志条件转移，当ZF＝0时转移。
2.我们这里需要将它跳转到不为0，也就是z标志位为1
&nbsp;

![enter description here][4]



## 4.载入Ollydebug
接下来我们将程序载入OD 看看。前面我们已经知道程序的整个流程了，我们需要找到jmp的关键处

![enter description here][5]
&nbsp;
我们在反汇编窗口，右键，使用字符串搜索功能，搜索关键处。

![enter description here][6]
&nbsp;
在搜索处，我们可以看到熟悉的字符串
&nbsp;
![enter description here][7]
&nbsp;
这里我们可以找<font color="##006000">Login successful </font> ,我们这里双击跟进跟踪，我们找到Login successful相关的汇编代码，在往上看我们可以看到，我们之前在IDA看到的 <font color="##006000">jnz </font> 汇编跳转指令。

![enter description here][8]

我们这里可以使用几种方法。
判断后如果不跳，就会到下一个jmp，jmp是无条件跳,既然错误的话，jnz会跳到错误信息,那么我们输入错误后，jz就肯定不跳. (Akkuman师傅教了我也很多)

## 修改Z标志位。

我们来看看 jnz ，也就说jmp not zero（跳转不是0的地方） 现在z标志位为1，需要将其修改为 0.即可实现输入错误信息，就跳转到成功登陆。

1.我们在 jnz 处下个断点。（断点快捷点F2）
&nbsp;
![enter description here][9]
&nbsp;
2.我们将其程序运行，输出错误的用户名和密码，断点处，自动断下。
&nbsp;
![enter description here][10]
&nbsp;
这里我们可以看到Z标注处为1
![enter description here][11]
&nbsp;
我们将其z标志位 双击 修改成1 
&nbsp;
![enter description here][12]
&nbsp;
![enter description here][13]
&nbsp;
 我们将其程序运行，显示登录成功
 &nbsp;
![enter description here][14]

程序停止

![enter description here][15]

## 修改汇编指令
我们重新载入OD ，依旧找到  jnz  位置，双击jnz 处汇编代码，将jnz其修改为je 
![enter description here][16]

JE——若ZF=1，则跳转，jnz 与je 相反
&nbsp;
![enter description here][17]
&nbsp;
修改完后，我们将其运行程序，同样得到成功登录
&nbsp;
![enter description here][18]
&nbsp;
学无止境，有兴趣看OND 老哥的逆向课，可以加入技术群 群号:307283889 ，一起交流技术性探讨。如有文章相关不对的地方，可指出，谢谢！！！

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/reverse-engineering-with-radare2-quick-introduction.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/93FEF6CF-4A88-42B7-B0C8-8101C40FC874.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3C7D5B10-E2AC-4C0B-BE96-E4ABBCDF5668.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/E666E83C-DBAC-4691-BDD3-7DAC94862F37.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506776242908.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506776432739.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/A4B2650B-09C8-4607-AC51-8118BA467431.png
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/A688CA17-21BB-436F-A099-BE97E4E723DB.png
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506778553462.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506778655119.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506779013665.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/CDF92339-9DB7-4E30-9755-8C074FCA19C6.png
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506780080102.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506780093452.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506780105042.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506780236693.jpg 
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/908A788C-B88E-4611-8457-E4B02705BDD1.png
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506780615266.jpg