---
title: Tracker | Dll Injected
date: 2017-12-21 20:03:18
·tags:
---
![enter description here][1]
<!--more-->
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Tracker.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题·
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>
 
## 前天在某推看到 在一年前（subtee）发现了
 ![enter description here][2]
 
 
 ![enter description here][3]
 
 &nbsp;
![enter description here][4]

![enter description here][5]
Tracker.exe用于启动一个进程，并在创建之后将FileTracker.dll注入到该进程中。跟踪目标进程的文件访问，并在进程退出之前写入.tlog文件。

但是，如果多个线程（具有相同的中间目录）并行地（通过Tracker.exe）并行启动同一目标可执行文件的多个实例，则所有这些进程将尝试写入同名的.tlog文件* *当他们退出。如果足够的进程并行运行，这种竞争条件不可避免地导致其中一个无法打开文件进行写入（因为另一个实例已经打开），导致错误FTK1011：

FileTracker：错误FTK1011：无法创建新文件跟踪日志文件：C：\ ... \ tlogs \ ipconfig.read.1.tlog。该文件存在。

我在实际应用中观察到了这一点，并将其简化为一个简单的自包含的测试用例。只需运行它，并等待控制台中出现错误（可能需要两到三次尝试，但通常至少发生一次）。

请注意，Visual Studio设法通过巧合来避免这种竞争条件 - 在构建一个包含许多C ++文件的项目时，构建系统不是同时启动多个cl.exe实例，而是构建系统启动一个实例并将所有C ++文件（然后cl.exe使用多个线程并行编译）。
详细信息


![enter description here][6]


## 正好也是在这个月推主发推了
![enter description here][7]


## 自己也复现了一下 
![enter description here][8]

最后也是感谢两位  Yansu 、 V@1n3R. 给我的帮助，  最终一起能复现出这个bug。

我已打包上传到 GitHub 上了  https://github.com/demonsec666/Tracker

https://connect.microsoft.com/VisualStudio/feedback/details/1655214/msbuild-tracker-exe-race-condition-when-called-in-parallel-for-instances-of-the-same-exe


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513858216225.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513858917056.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/EF953652542BEACE168119915DDAF8E9.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513858991311.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513859183063.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513859321518.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/F5428F36171E976B3621F04D05BB2A89.png
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1513859530284.jpg 