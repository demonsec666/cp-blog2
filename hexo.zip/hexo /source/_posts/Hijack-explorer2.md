---
title: Hijack_explorer2
date: 2018-10-09 22:22:29
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
![enter description here][2]



![enter description here][3]

https://www.bleepingcomputer.com/news/security/windows-10-ransomware-protection-bypassed-using-dll-injection/


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20181009_222614.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/75BB3EF2528A3EE7401A0E0C5CD934D5.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/F4CB9FD5C87E4D86C57233D159888FA4.jpg