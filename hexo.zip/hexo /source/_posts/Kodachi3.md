layout: linux
title: Kodachi3
date: 2017-01-13 20:21:21
tags: linux
categories: linux
---
<h1 class="post-title entry-title">                             <strong><span style="color: #008000;"> Linux Kodachi3：安全，反取证和匿名操作系统</span></strong></h1>
<img class="alignnone size-full wp-image-2998" src="http://www.secist.com/wp-content/uploads/2017/01/1.png" alt="1" width="1920" height="1200" /> 
<!--more-->
<img class="alignnone size-full wp-image-2999" src="http://www.secist.com/wp-content/uploads/2017/01/Vpn-tools.png" alt="vpn-tools" width="428" height="354" />

&nbsp;

<strong><span style="color: #ff0000;">背景介绍：</span></strong>

Linux Kodachi操作系统基于Debian 8.6，它将为您提供一个安全，反取证和匿名操作系统，考虑到一个关心隐私的人需要具有的所有功能，以确保安全。
Kodachi是非常容易使用所有你需要做的是通过U盘设备启动它在您的电脑，那么你应该有一个完全运行的操作系统与建立的<strong><span style="color: #ff0000;">VPN连接+ Tor连接建立+ DNScrypt服务运行</span></strong>。从你身边不需要设置或Linux知识，我们为你做所有。整个操作系统是从您的临时内存RAM的功能，所以一旦你关闭它没有任何痕迹留下所有的活动被清除。
<span style="color: #ff0000;">Kodachi</span>是一个实时操作系统，您可以从几乎任何计算机上启动从DVD，USB或SD卡。它旨在保护您的隐私和匿名。
<ul>
 	<li><span style="color: #ff0000;">匿名使用互联网</span>。</li>
 	<li>所有与Internet的连接都被<span style="color: #ff0000;">强制通过VPN</span>，然后通过DNS加密的Tor网络。</li>
 	<li>在您使用的计算机上<span style="color: #ff0000;">不留痕迹，除非您明确要求</span>。</li>
 	<li>使用<span style="color: #ff0000;">最先进的加密和隐私工具加密您的文件，电子邮件和即时消息</span>。</li>
</ul>
Kodachi基于实体Linux Debian和定制的XFCE，这使得Kodachi<strong>稳定，安全，独特</strong>。

<a href="https://sourceforge.net/projects/linuxkodachi/files/?source=navbar">下载Kodachi</a>

<img class="alignnone size-full wp-image-3001" src="http://www.secist.com/wp-content/uploads/2017/01/FMYR36N6CWQ8GBZXDVC.png" alt="fmyr36n6cwq8gbzxdvc" width="1120" height="406" />

## 安装后：

登录普通用户：
Username:<span class="zelena" style="color: #ff0000;"> kodachi</span>
Password:<span class="zelena" style="color: #ff0000;"> r@@t00</span>
登录root用户：
Username:<span class="zelena" style="color: #ff0000;"> root</span>
Password:<span class="zelena" style="color: #ff0000;"> r@@t00</span>

&nbsp;

其他请查阅相关官方文档：https://www.digi77.com/
<ul>
 	<li class="strelica">我们不建议在任何PC上永久安装这款系统，因为你这违背了作为一个反取证OS的主要目的在硬盘上的所有设置，建议</li>
</ul>
安装一次性或者u盘设备。