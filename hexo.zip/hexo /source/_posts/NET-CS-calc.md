---
title: .NET_CSC_calc
date: 2018-01-09 18:43:09
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
##  视频演示
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Net_CSC_calc.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>



``` stylus
c:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe demon.cs
```
![enter description here][2]

``` stylus
using System;
namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
         System.Diagnostics.Process.Start("calc.exe");  
        }
    }
}
```
![enter description here][3]

![enter description here][4]



https://docs.microsoft.com/zh-cn/dotnet/csharp/language-reference/compiler-options/command-line-building-with-csc-exe


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/74AECD274FD87CA84354DE01CC5BCFB5.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515495219353.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515495242360.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515495313615.jpg 