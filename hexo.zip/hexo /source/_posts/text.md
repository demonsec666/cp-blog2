---
title: text
date: 2017-01-04 23:13:11
tags: text
---
  <link rel="stylesheet" type="text/css" href="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.css" />

  <asciinema-player src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciicast-97862.json" cols="80" rows="24"></asciinema-player>
  ...
  <script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.js"></script>