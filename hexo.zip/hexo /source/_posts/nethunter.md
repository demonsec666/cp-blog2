---
title: 三星Note3 -N9005刷机Kali Nethunter详细教程
date: 2017-01-08 12:28:01
tags: kali
categories: kali
---
![enter description here][1]
<!--more-->
Kali Nethunter 是一款专为渗透测试人员打造的，基于 CyanogenMod 的安卓渗透测试平台。

我看了一下，现在网上大部分教程都是针对 Nexus 和 one plus 手机的教程，没有针对其他手机的刷入教程，在这里我以我的三星手机为例，手机型号为：Note3 -N9005 来给大家演示下，如何在三星机上刷入 Kali Nethunter。
# 友情提示
> 友情提示：黑手仅仅只能做黑客手机用，切勿当做日常生活用，原因做安全的人都懂得的一个道理。以及刷机之前需要对手机重要数据备份，以免一个数据丢失。未对数据备份，数据丢失，本人不负责。在这里十分感谢kali nethunter 群主的耐心讲解，人非常好，有兴趣的朋友们可以加下群：425901382


----------


本文使用到的工具以及录制视频—–链接：

链接: https://pan.baidu.com/s/1c16Wbfy  密码: ae6h  （录制视频可在线观看）

以下是官方对支持机型的说明，以及需要刷入的 ROM：
![enter description here][2]
&nbsp;
![enter description here][3]

—————-需要说明的是，按道理来讲安卓机都是可以刷的。

# 安装准备：

1. 备用线刷工具包一份，救砖急用！
![enter description here][4]

刷机底包之前需要对设备进行解锁，即root权限，以及刷入第三方 rec 才能进行以下步骤！

 

2. 前面刚刚说过了，nethunter 是基于 Cyanogenmod 的安卓第三方 ROM，所以我们需要刷入一款干净的底包，我这边选择的是非官方的底包。cm13 的版本（安卓6.0）以及我这里是三星，note3 或者 s4 等等可以通刷 ，不分运营商版本。即高通 u 可以通刷。—底包针对自己手机型号下载。在这里底包选择5.x~6.x。
![enter description here][5]
![enter description here][6]

 

3. 刷入第三方 rom 包，我们需要对设备解锁，也就是我们日常说的 root 权限，这里我采用三星奥利线刷工具刷入 root 解锁包，使用的是全自动解锁。刷入过程中会多次重启请耐心等待(线刷工具和 root 针对自己手机型号下载）
![enter description here][7]
![enter description here][8]

4. 刷入第三方 rec。—-根据自己手机型号选择第三方 rec 类型。

![enter description here][9]
![enter description here][10]
![enter description here][11]

5. 需要选择需要刷入的 kali nethunter 安装包：arm64 是 64位，armhf32位，找和你 cpu 结构一致的，full 是完整版，minimal 是简版。

链接：build.nethunter.com/nightly/3.15.4-20170101-0951/

 
![enter description here][13]
![enter description here][14]



6. 选择手机相对应的nethunter内核：kernel-nethunter 表示是内核，klte 是型号, touchwiz 是基于三星原厂 rom,marshmallow 是 安卓 6.0,lollipop 是 5.x 这里我这边是 cm 是通刷的。所以内核也是通刷三星的。

刷入完 kali hunter不要重启，直接刷入相关的 nethunter 内核。
![enter description here][15]


7. 重启后对手机的相关配置对 ：（一）nethunter 客户端进行一定的 root 权限授权。（二）也不知道为什么刷入直接还需要下载 800 多 MB 的整体包，后来我只好下载了。也可能是我某方面的操作问题。
![enter description here][16]
 ![enter description here][17]
![enter description here][18]


8. 整体效果预览：
![enter description here][19]
![enter description here][20]

![enter description here][21]

# 参考资料
http://mp.weixin.qq.com/s?__biz=MzI5ODIwOTM1NA==&mid=2247484924&idx=2&sn=a416dc86243786c70f53899ff0c608dd&chksm=eca81cd9dbdf95cf0b2e2a3380d1b780ce274f8a11bd4803dba55764083108f4ebb270e25bfb&mpshare=1&scene=23&srcid=0106tAn2BvoAXKW9p34My4NS#rd———-移动渗透测试平台搭建 – NetHunter 3.0—介绍。。

后续可参考余弦的教程http://mp.weixin.qq.com/s?__biz=MzA3NTEzMTUwNA==&mid=2651081148&idx=1&sn=12a3891f4726266c8fbf211f6edb5a04&mpshare=1&scene=23&srcid=0108oH7JzdNGq9vs9a44tUsU#rd：如何安装无线网卡。


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0619.JPG 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0603.JPG 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0604.JPG 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0621.JPG 
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0606.JPG 
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0605.JPG 
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0607.JPG 
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0608.JPG 
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0609.JPG 
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0610.JPG 
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0611.JPG "
  [12]: http://markdown.xiaoshujiang.com/img/spinner.gif "
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0612.JPG 
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0613.JPG 
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0614.JPG 
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0615.JPG 
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0616.JPG 
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0617.JPG 
  [19]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0619.JPG 
  [20]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0618.JPG 
  [21]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_0620.JPG 