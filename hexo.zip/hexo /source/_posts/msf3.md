---
title: Metasploit系列课程第三课
date: 2017-04-01 16:17:14
tags: Metasploit,kali
categories: Metasploit
---
![enter description here][1]
<!--more-->

&nbsp;
&nbsp;
&nbsp;
## 第三课：metasploit之绕过某安全防护(恶作剧三部曲,曲一)
&nbsp;
免杀后门过某安全防护----zirikatu
&nbsp;
由于忙于工作和学习，却断更了这么长时间，也是非常抱歉！！！同样也是很久没更新歌单了
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=1141860&auto=0&height=66"></iframe>
&nbsp;
以下含视屏链接以及一些ppt （附带了 解决msf数据库的一些问题---pentestbox）
&nbsp;
链接:https://pan.baidu.com/s/1kUTgRMB 密码:hhpk
&nbsp;
亦可在线观看即刻官网在线视频：http://www.secist.com/videos/index.html
&nbsp;
![enter description here][2]

## 效果图
以下是针对两款主流的安全防护进行了简单的扫描以及绕过某安全防护的的效果图：
&nbsp;
&nbsp;
![enter description here][3]


&nbsp;
&nbsp;
&nbsp;

&nbsp;
&nbsp;
## 工具环境安装简单介绍Zirikatu
环境需求 ：metasploit 以及mono（.net语言运行环境）
<span style="color: #008000;">mono （Xamarin公司开发的跨平台。NET运行环境）</span>
<span style="color: #008000;">Mono是一个由Xamarin公司（先前是Novell，最早为Ximian）所主持的自由开放源代码项目。该项目的目标是创建一系列匹配ECMA标准（Ecma-334和Ecma-335）的.NET工具，包括C#编译器和通用语言架构。与微软的.NET Framework（共通语言运行平台）不同，Mono项目不仅可以运行于Windows系统上，还可以运行于Linux，FreeBSD，Unix，OS X和Solaris，甚至一些游戏平台，例如：Playstation 3，Wii或XBox 360。</span>

![enter description here][4]
&nbsp;

&nbsp;
&nbsp;
并针对在线杀毒网进行多项引擎扫描，可以说是效果不错。
&nbsp;
&nbsp;

![enter description here][5]
&nbsp;
&nbsp;
&nbsp;
## 以下是针对以上视频步骤录制
<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！</span></strong>

<strong><span style="color: #ff0000;">代码可直接复制！！！！</span></strong>

<link rel="stylesheet" type="text/css" href="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.css" />

  <asciinema-player src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/zirikatu&msf.json" cols="100" rows="30"></asciinema-player>
  ...
  <script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/asciinema-player.js"></script>

## 感谢关注即刻安全和鄙人博客！！！多谢


参考资料：http://www.thinksaas.cn/topics/0/480/480366.html
               &nbsp;  https://github.com/pasahitz/zirikatu


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-crack-passwords-part-3-using-hashcat.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/%E5%9B%BE%E7%89%87%201.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/4FFF4FC8-5536-40BD-A38D-9597C5F665D5.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/E58F9A73-DE1B-4342-8EDB-F63BA427886E.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/61947AEB-36B0-4153-94DD-B061B06D237A.png 