---
title: windows10/linux--渗透利器(下) 
date: 2017-02-02 09:29:44
tags: kali
categories: kali
---
![enter description here][1]
接着说到上一篇，
1.docker虽说是容器，但是也有部分缺陷，麻烦！！！需要熟知docker命令等，研究docker也是比较耗时间，确实比较头疼的事情。
<!--more-->
2.那么虚拟机呢，太过于占资源，对于配置不好的人来说，用户体验不好。况且我问你几个问题：1.你在虚拟机用到的图形化界面有多少？ 2. 常用的命令工具有多少？3.图形化界面用到的工具有多少？
其实图形化界面用到的不多，我们web常用的工具也就burp和一个浏览器差不多了，但是这些工具反而在windows下可以实现！
&nbsp;
3.pentestbox 呢命令记不住，和kali命令不一样。而且中文不是很支持，况且也有一些部分bug。

能否做到这种两全其美的事情呢？？？？？
我得回答是有的，能达到这种效果。以下是在windows 10 效果图：
![enter description here][2]
&nbsp;
&nbsp;
&nbsp;
&nbsp;
## 你有本事抢男人 怎么没本事开门啊!!

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=27639209&auto=0&height=66"></iframe>

<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/win10_kali.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

##  <span style="color: #ff0000;">背景知识科普：</span>
 正如大家所知道的，大多数 Linux 上的命令行二进制程序现在可以原生地运行在 Windows 10 里面了，这包括 Linux 上著名的  bash shell 以及很多重要的 Linux 程序，如：apt、ssh、 vim、 emacs、tar、 php、  perl、 python、 gcc 等等。
 
要实现这个功能，你首先需要安装 Xming X Server for Windows，然后在 Windows 10 的 Bash 中运行如下命令（你可以将 firefox 替换成你安装在 Bash 中其它图形界面的 Linux 程序）：
　　该开发者说，“显然，这要比原生的 Windows/Linux 应用慢一些，但是肯定比 VNC/X11 转发要快。”
　　社区立刻被这个发现震惊了，另外一些人表示也许可以在 Windows 中运行完整的 Linux 桌面，就如同有人在 Windows 10 中编译运行了 Xfce 一样！！！Xfce —— 这可是很多 Linux 发行版的默认桌面环境！
  &nbsp;
  
&nbsp;
&nbsp;
<span style="color: #008000;">windows10 自定义安装kali_linux 工具集效果图</span>。无虚拟机，无docker，无pentestbox，实现windows和Ubuntu交互。
&nbsp;
&nbsp;
![enter description here][3]
&nbsp;
&nbsp;

![enter description here][4]
如何安装win10 bash：请参考以下资料
http://jingyan.baidu.com/article/5552ef47ef0b87518ffbc935.html
&nbsp;
&nbsp;
&nbsp;
## 使用工具
回归正题，今天我主要推荐的一款工具是
 <span style="color: #ff0000;">Katoolin</span> https://github.com/LionSec/katoolin   是一个Python脚本，它可以实现在Debian/Ubuntu上自动安装Kali Linux中的工具。
 可以在<span style="color: #ff0000;">linux</span>下使用甚至可以在<span style="color: #ff0000;"> windows 10 </span>下使用---开启子系统<span style="color: #ff0000;">Ubuntu</span>
![enter description here][5]
&nbsp;
&nbsp;
&nbsp;

## 可以自定义安装kali工具
![enter description here][6]
![enter description here][7]

## <span style="color: #ff0000;">Katoolin安装步骤：</span>
如果是windows 10 bash：
请先更新以下命令：
<pre>apt-get update</pre>
<pre>apt-get install git</pre>
再执行一下命令，linux用户不需执行以上命令。
<pre>
sudo su
git clone https://github.com/LionSec/katoolin.git && cp katoolin/katoolin.py /usr/bin/katoolin
chmod +x /usr/bin/katoolin
sudo katoolin</pre>
&nbsp;
&nbsp;
## <span style="color: #ff0000;">Katoolinyo用法：</span>
<pre>
键入工具号将安装它
键入0将安装所有Kali Linux工具
返回：回去
gohome：转到主菜单
通过安装armitage，你将安装metasploit</pre>
&nbsp;
&nbsp;
   
使用Katoolin
添加Kali Linux软件仓库并更新：选择1号
![enter description here][8]
![enter description here][9]
![enter description here][10]
选择2 选项 安装kali工具
![enter description here][11]

比如说我要安装一个mitmf
搜索工具包
<pre>apt-cache search  mitm</pre>
![enter description here][12]
![enter description here][13]
![enter description here][14]

![enter description here][15]
&nbsp;
&nbsp;
## 结语：
安装kali工具的时候，切记关闭防火墙等360以及微软自带的防护。否则会拦截.
安装kali工具的时候，切记关闭防火墙等360以及微软自带的防护。否则会拦截。win10 版14316以下没有这个功能的

使用systeminfo查看版本
![enter description here][16]
参考资料：https://fossbytes.com/install-run-bash-ubuntu-windows-10/
http://www.pcpop.com/doc/2/2642/2642208.shtml
http://www.linuxdiyf.com/linux/21679.html


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0.webp_.jpg 
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/72F94A8F-C89E-4873-A7C2-81F0DCCEFBDB.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B06775EF-11F1-493A-8E99-BDDDFC2DEC39.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7E1C51AD-92B1-4BDF-8128-1BB34175070F.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/6AC3C2A1-1E97-4154-A3D7-C61CC71A6CBF.png
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/936ACEB0-9153-461A-9118-B58CE3B998CB.png
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/A5963FAF-02D6-4851-8CFE-CEBB99B85A38.png
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/B434D282-9845-47C3-B375-E5B5C3FD433F.png
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/D2F527B8-9B2D-458C-A748-B0E1B8049C03.png
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3D7D0BD4-2010-4040-B2DB-931120AD94E0.png
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/467372F4-D59B-4F7D-B474-B9042FB51B94.png
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/761C12A6-0AF7-4F02-9CA4-D7714AE9A4AF.png
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/C473B0DA-1796-4E78-8E14-BB60D524E9B0.png
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1E512C4A-845E-4E04-A72A-CF88A7510F4E.png
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/4E9D2970-3036-46A2-9C0C-0AEBCEE94EF0.png
  [16]: http://www.secist.com/wp-content/uploads/2017/02/BAF9C5D9-2CFC-4CA7-80B1-9D4B7E297B6F.png