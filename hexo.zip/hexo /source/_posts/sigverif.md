---
title: sigverif
date: 2018-07-21 10:27:35
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->

## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/sigverif.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


http://www.hexacorn.com/blog/2018/04/27/i-shot-the-sigverif-exe-the-gui-based-lolbin/
![enter description here][2]


![enter description here][3]


![enter description here][4]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180721_102635.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1532140368536.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1532140281350.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1532140336917.jpg