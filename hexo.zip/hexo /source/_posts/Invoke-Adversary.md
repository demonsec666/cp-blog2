---
title: Invoke-Adversary
date: 2018-04-13 20:35:57
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->

Invoke-Adversary是一款PowerShell脚本，可帮助您根据检测高级持续性威胁的能力来评估安全产品和监控解决方案。


![enter description here][2]


![enter description here][3]

![enter description here][4]


![enter description here][5]

link: https://github.com/MotiBa/Invoke-Adversary/tree/master#invoke-adversary

https://blogs.technet.microsoft.com/motiba/2018/04/09/invoke-adversary-simulating-adversary-operations/


![enter description here][6]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180413_204728.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IA11.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IA2.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IA3.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/image210.png
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/EC239B8D525F3FEBE1C6010EEEC990B1.jpg 