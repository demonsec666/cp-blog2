---
title: 登录暴力破解 | 逆向笔记(二)
date: 2017-10-02 19:33:25
tags: 逆向
categories:  逆向
---
![enter description here][1]
<!--more-->
接着上一篇的总结，ONDragon的第二课。


```markdown
#define  _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <stdio.h>
#include "resource.h"
char name[1024] = "ONDragon";  //设置用户名、密码
char pass[1024] = "666";
BOOL check(char  userName[], char  passWord[])  //检测判断用户名和密码是否和设置一样
{
	if (userName == NULL || passWord == NULL)
	{
		return FALSE;
	}
	else
	{
		if (*userName == *name)
		{
			if (*passWord == *pass)
			{
				return TRUE;
			}
			else
			{
				return FALSE;
			}
		}
		else
		{
			return FALSE;
		}
	}
}
BOOL CALLBACK MainDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL bRet = FALSE;
	switch (uMsg)
	{
	case WM_CLOSE:
	{
		EndDialog(hDlg, 0);
		break;
	}
	case WM_INITDIALOG:
	{
		SetWindowPos(hDlg, HWND_NOTOPMOST, 400, 300, 410, 180, SWP_SHOWWINDOW);
		break;
	}
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON_LOGIN:
		{
			char userName[1024];
			char passWord[1024];
			GetDlgItemText(hDlg, IDC_EDIT_USER, userName, 1024);  
			GetDlgItemText(hDlg, IDC_EDIT_PASS, passWord, 1024);
			if (check(userName,passWord))
			{
				MessageBox(hDlg, "Login Successful", "Congratulation", MB_OK); //登录成功
			}
			else
			{
				MessageBox(hDlg, "Login Failed", "Sorry", MB_OK); //登录失败
			}
			return TRUE;
		}

		}
		break;
	}

	return bRet;
}
int APIENTRY WinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine,
	int       nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG_MAIN), NULL, MainDlgProc);
	return 0;
}
```
## 这次依旧是登录小程序
本次编译的是  release版本

![enter description here][2]

未破解的
![enter description here][3]

破解后的
![enter description here][4]




## 载入Ollydebug

这里我们载入OD

![enter description here][5]

和上篇一样，我这里依旧使用的是查找字符串
![enter description here][6]


在这里只能短短的看到 登录失败和登录成功几个字，我们双击其中一个字符串，进行跟踪

![enter description here][7]


![enter description here][8]

我们来简单看下。
![enter description here][9]


## 1. 简单思考与分析

这两条指令 （cmp）将 ss:[ebp-0x404]的值和0x4F做比较，两个值相减为0，（ZF ，零标志，标明结果为0。真置1，假置0。）

反汇编窗口

这里也就是将第一个字节 与4F 做判断是否非为0。第一个cmp指的是用户名的字符串

![enter description here][10]

那么这里我们不能让下条指令跳转到，登录失败。 第二个cmp指的是密码的字符串

![enter description here][11]

这里同样也是将第一个字节 与4F 做判断是否非为0。

![enter description here][12]

寄存器窗口
![enter description here][13]

## 2.修改
我们如何不能让他跳转到登录失败呢
这里我们下个断点，在第一个cmp处。也就是判断用户名是否正确的地方。(按F2设置断点)

![enter description here][14]

并且运行程序
![enter description here][15]

键入用户名和密码后，已断在断点处。
![enter description here][16]

选中第一个cmp处，查看内存地址对应键入用户名的字符串 （右键->数据窗口中跟随->内存地址）

![enter description here][17]

我们在数据窗口中可以看到，我们键入的用户名为demon ，第一个字节d 对应的则为64 十六进制 （在ASCLL码表即可找到相应的，其他依次类推）由于在cmp 设置的为bype 一个字节，后门判断 4F也为一个字节，cmp需将其判断为0，则我们也可以将其cmp处的代码 中的0x4F，改为0x64

![enter description here][18]

![enter description here][19]

或将数据窗口的 64 改成4F即可。

![enter description here][20]

第二处 cmp以此类推。
修改完两处之后，我们运行看看，可以成功得到login successful 的弹窗！

![enter description here][21]

## 3.NOP大法
还有另一种修改方案则是NOP大法。
在cmp处下断点，并将两处cmp 将其NOP掉。
双击CMP 汇编代码 ，将其代码填写为nop

![enter description here][22]
填充nop
![enter description here][23]

nop后
![enter description here][24]

运行后,一样提示得到login successful 的弹窗！

![enter description here][25]
&nbsp;


## 4.修改跳转指令

先上几张跳转指令基础知识图

![enter description here][26]

![enter description here][27]

今天就先看这几个跳转指令，与ZF标志位相关

![enter description here][28]

这里我们依旧还是在cmp处下断点，并运行，执行到断点处

![enter description here][29]

两处jnz 改为 jz 或者je （改成jz 或自动填写je）
![enter description here][30]

以下是debug版本的IDA载入图，破解方法和之前的类似，这里就不再重复多说了，工具和课程视频咋即刻安全网盘即可下载。

![enter description here][31]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/C2DB3778361E459A07A63F2E4AE6F952.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506956269052.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506956476486.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506956434705.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506956756044.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506956995124.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506956890222.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506957521671.jpg
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506957984283.jpg
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506958160790.jpg
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506963545170.jpg
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506960581227.jpg
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506960591504.jpg
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964051036.jpg
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964113386.jpg
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964176532.jpg
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964255750.jpg
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964421167.jpg
  [19]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964776844.jpg
  [20]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506964830092.jpg
  [21]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506998071787.jpg
  [22]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506998307857.jpg
  [23]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506998323149.jpg
  [24]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506999423856.jpg
  [25]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1506999489213.jpg
  [26]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/585205_1rlcvcln6xhqiib.png
  [27]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/585205_wpjlvo9kl61tvyq.png
  [28]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507000225793.jpg
  [29]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507000444071.jpg
  [30]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1507002904856.jpg
  [31]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/87CD7E8A-4ABB-4015-95D2-8094BF6A8C50.png 