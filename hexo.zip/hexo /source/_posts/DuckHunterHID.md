---
title: 黑手第三篇----DuckHunterHID for mac 
date: 2017-04-18 11:51:51
tags:  kali
categories: kali
---
![enter description here][1]
<!--more-->
  继上一篇nethunter 的HID键盘攻击之后，我打算在我的mac上进行HID攻击，（http://www.ggsec.cn/nethuner-HID.html ） 这次使用到的是USB-DuckHunter-HID，下面请看背景知识回顾-----------------》
&nbsp;
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=31209890&auto=0&height=66"></iframe>
0x00
## HID 键盘攻击
在这个视频键盘HID攻击被证明。
它可以在几秒钟内通过USB将目标解锁机器。它通过模拟键盘和鼠标，盲目地键入受控命令，轻击鼠标指针并使鼠标点击武器。
这是什么？
几乎每台包括台式机，笔记本电脑，平板电脑和智能手机的电脑都通过键盘输入人类。这就是为什么有一个称为HID或人机接口设备的无处不在的USB标准的规范。简单地说，声称是Keyboard HID的任何USB设备将被大多数现代操作系统自动检测和接受。无论是Windows，Mac，Linux还是Android设备，键盘都是King。

通过利用这种固有的信任，脚本敲击的速度超过每分钟1000字，传统的对策可以被这个不知疲倦的骑兵绕过 - USB攻击。
&nbsp;
&nbsp;
## DuckHunter HID
DuckHunter HID选项允许您快速方便地将USB Rubber Ducky脚本转换为NetHunter HID攻击格式。您可以从示例预设菜单中选择一个选项，或从Duck Toolkit站点中选择更多选择的预配置脚本。
进攻安全人员再次出现。受欢迎的Pentesting发行版Kali Linux的构建者为Android设备推出了一款名为Kali NetHunter的新工具。该工具是一种移动分销，旨在在Android手机上安装并运行时通过USB危及系统。

该工具可以通过HID风格的攻击伪装成键盘，发出命令以打开其他攻击中的管理外壳，包括BadUSB中间人风格的攻击。该工具的图片目前可用于Nexus设备，但其他Android设备的构建可能正在进行中。
&nbsp;
![enter description here][2]

&nbsp;
&nbsp;
##   0x01
   <span style="color: #ff0000;"> 首先我们来看下，黑手（kali_nethunter）的duck_HID 给我们提供了哪些默认的脚本。
  1. 首先呢 我们可以看到在nethunter客户端上可以看到有（DuckHunter HID ）字样，其实他就是模拟黄鸭，USB Rubber Ducky脚本转换为NetHunter HID攻击格式。</span>
   &nbsp;
&nbsp;
![enter description here][3]
&nbsp;
&nbsp;
在默认的选项我们可以看到他给我们提供了默认的几个选项，其中有两个脚本呢 是针对Mac OSX 的HID攻击，攻击后呢
返回一个shell连接，这里其中有perl和Ruby两个脚本，我们就选择其中一个选择ruby。
![enter description here][4]
&nbsp;
&nbsp;
## 0x02
选择ruby脚本。我们来简单的看下代码的意思
![enter description here][5]
&nbsp;
&nbsp;
0X03
1.COMMAND SPACE-----在mac的快捷键表示为搜索框搜索
![enter description here][6]
&nbsp;
2.STRING terminal  ENTER--------输入字符串terminal 搜索终端，并按下回车
![enter description here][7]
&nbsp;
3.Command+n就是新建的快捷键，功能是新建一个项目，在不同程序有不同的新建项目种类。
![enter description here][8]
&nbsp;
4.在终端下输入字符串使用ruby socket建立服务端
![enter description here][9]
&nbsp;
5.当然了在这段代码也我们提示了 使用netcat（nc ）建立监听 并返回会话，他这里0.0.0.0提示我们更改我们黑手nethunter的ip地址。
如：
查看黑手使用的ip
![enter description here][10]
&nbsp;
&nbsp;
<strong><span style="color: #008000;">更改ip</span>
![enter description here][11]
&nbsp;
&nbsp;
<strong><span style="color: #008000;">保存脚本</span>
![enter description here][12]
&nbsp;
&nbsp;
## 0X04
1.<strong><span style="color: #008000;">并且在终端中使用nc命令建立监听 </span>---------nc -vv -l -p 1337
![enter description here][13]

&nbsp;
&nbsp;
2 .点击三角按钮，<strong><span style="color: #008000;">执行攻击</span>。
![enter description here][14]

&nbsp;
&nbsp;
3.<strong><span style="color: #008000;">返回shell连接</span>
&nbsp;
&nbsp;
![enter description here][15]
&nbsp;
&nbsp;
<span style="color: #008000;">最终结果：</span>
![enter description here][16]
&nbsp;
&nbsp;
更多项目可在github--USBDucky 项目中寻找你需要的PAYLOAD。
https://github.com/hak5darren/USB-Rubber-Ducky/wiki/Payloads
&nbsp;
&nbsp;
![enter description here][17]
## 视频演示
可观看个人演示的视频
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/DuckHunterHID.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>
![enter description here][18]
&nbsp;
&nbsp;
![enter description here][19]
&nbsp;
&nbsp;
![enter description here][20]
&nbsp;
&nbsp;
![enter description here][21]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/maxresdefault.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1zdsvb8.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3B83EDEB-6401-47BD-97AC-F67EBA4912F1.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/9DA2E76E-459B-4295-902B-3EF8FF5F87B2.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1CF817DC-6562-446F-9850-D88922A5E14E.png
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/6A323763-0ACE-4230-8638-42AE41A643C9.png
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/432C200A-9E1E-423E-A928-CC24DC452D75.png
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/82B4B55D-25D0-4B43-91B9-3C587FF2B470.png
  [9]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/4F756B21-2BF7-4F64-929B-D1F2044789F8.png
  [10]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/FF774580-92C6-4BFE-A2C0-3AE59A011A21.png
  [11]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1BB5C440-F798-4F15-B2F3-3830EFD44FA9.png
  [12]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3F33287D-827C-4CC0-BFEE-FFA398CE9FBE.png
  [13]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DD63EB85-CE67-447A-A17E-D7E16EF7BB22.png
  [14]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1833878B-24B2-48BD-8438-0EDD524619D7.png
  [15]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/7DD01722-EC8C-43AD-94F9-3D7BF4A7398D.png
  [16]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/9E207E32-F824-4000-BC11-7207FDA27AC1.png
  [17]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1492519263301.jpg
  [18]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/625CE7389F506CD27830E0AC9450F043.jpg 
  [19]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/926EC2F4CAA40850C68695B568ED7C5E.jpg 
  [20]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/958E71B5A3E801BBD876231B610B9B67.jpg 
  [21]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/0C3A8A27E4B981F504D4EA54E2BE8BFC.jpg 