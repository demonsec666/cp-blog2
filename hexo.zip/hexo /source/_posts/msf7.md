---
title: Metasploit系列课程第七课
date: 2017-05-25 07:04:06
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->

时过多个月也终于迎来了我的第七课，说真的 不是我更新慢，而是因工作上的许许多多事情忙不过，真心对不住了各位。
&nbsp;
# Metasploit系列课程第七课
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=26421042&auto=0&height=66"></iframe>
预览版 : http://www.ggsec.cn/avoidz.html
&nbsp;
同时放上个人的secist_script   v1.5 ----------github 项目地址 ：https://github.com/demonsec666/secist_script
&nbsp;
脚本还在改进优化，各位有什么建议可以私聊我
&nbsp;
Metasploit系列课程第七课 百度云地址：链接: https://pan.baidu.com/s/1hsBVp44 密码: zsqw
![enter description here][2]
&nbsp;
![enter description here][3]
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-ultimate-list-hacking-scripts-for-metasploits-meterpreter.1280x600.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/W1Y6UHPY%294%60%7D9FGZ5UOTF%60F.png "W1Y6UHPY&#41;4`}9FGZ5UOTF`F.png"
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1495667609743.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1495667568240.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1495667649894.jpg