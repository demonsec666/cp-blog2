---
title: 黑手之kali_Nethuner---HID攻击
date: 2017-02-05 23:45:51
tags: kali
categories: kali
---
##  &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;<span style="color: #ff0000;">接着走着黑手——kali_nethuner的坑</span>
![enter description here][1]
<!--more-->
继<a  herf=http://www.ggsec.cn/2017/01/27/msf-web-delivery/>Metasploit后门免杀模块之绕过360</a>我想到了一个思路
在Nethuner上 可以执行HID 攻击。
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=18155583&auto=0&height=66"></iframe>en
##  <span style="color: #ff0000;">HID攻击介绍</span>
 
HID是Human Interface Device的缩写，由其名称可以了解HID设备是直接与人交互的设备，例如键盘、鼠标与游戏杆等。不过HID设备并不一定要有人机接口，只要符合HID类别规范的设备都是HID设备。一般来讲针对HID的攻击主要集中在键盘鼠标上，因为只要控制了用户键盘，基本上就等于控制了用户的电脑。攻击者会把攻击隐藏在一个正常的鼠标键盘中，当用户将含有攻击向量的鼠标或键盘，插入电脑时，恶意代码会被加载并执行。
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/HID_Attacks.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

&nbsp;
&nbsp;
&nbsp;
&nbsp;

## HID Attacks-----nethuner

<span style="color: #ff0000;">nethuner 自带的一个HID 攻击 模拟键盘的功能，通过usb数据线插上pc端，即可绕过安全防护等。</span>
![enter description here][2]
&nbsp;
&nbsp;
将代码辅助到此处 执行cmd 命令，以及选择相应的绕过UAC的系统，可执行代码，反弹最终shell，得到meterpreter会话。
&nbsp;
&nbsp;
![enter description here][3]
&nbsp;
&nbsp;
![enter description here][4]
&nbsp;
&nbsp;
![enter description here][5]
&nbsp;
&nbsp;

得到meterpreter会话。
![enter description here][6]
&nbsp;
&nbsp;
## 结语：最好的结语是没有结语。截稿已经是凌晨44分了，太困了







  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/u=2300716969,694719089&fm=23&gp=0.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/9BC31A4F-47C1-46E7-9409-C0F2EE1704BE.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/ADD0806E-B337-4DC8-BE45-12E53F3EF77E.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/ED374E63-8387-4636-8F49-8158E778FC50.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/16A3D110-067F-40CF-9FDD-4B7DA652648E.png
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/63920EA7-0CA7-4D48-AD41-C0CDB053ACF7.png 