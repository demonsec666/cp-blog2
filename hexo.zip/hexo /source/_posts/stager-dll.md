---
title: stager_dll
date: 2018-10-01 02:33:18
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/stager_dll.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


感谢群友WBGlIl的帮助

![enter description here][2]

![enter description here][3]

``` bat
@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\Common7\Tools\VsDevCmd.bat"
cl /LD /MT /EHa stager.cpp aes.cpp
```


https://github.com/phackt/stager.dll

![enter description here][4]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20181001_021846.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DC814A0D08E615E520600828011FAA23.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1538332573224.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1538332708687.jpg 