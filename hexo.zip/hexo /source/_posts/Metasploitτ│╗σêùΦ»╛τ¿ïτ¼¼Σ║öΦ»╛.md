---
title: Metasploit系列课程第五课
date: 2017-04-17 13:10:53
tags: Metasploit,kali
categories: Metasploit
---
![enter description here][1]
<!--more-->
## Metasploit系列课程第五课
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=27808359&auto=0&height=66"></iframe>
1.msfvenom 模块实例讲解
&nbsp;
2.编写上次未完成的脚本，参考我的编写思路
&nbsp;
3.bypass_server绕过某安全防护，并建立坚挺返回回话。
&nbsp;
由于忙于工作/加班和学习，断更了这么长时间，也是非常抱歉！！！个人水平有限，讲的不是很到位，望各位多多包涵！！！！！
链接: https://pan.baidu.com/s/1nvRsd1v 密码: ebpy ------------------------------ppt+编写的脚本+视频
![enter description here][2]
&nbsp;
&nbsp;
&nbsp;
## 彩蛋：个人编写完善该脚本！
https://github.com/demonsec666/secist_script.git

secist_script
v1.3
增加了 web_delivery 整个模块自动化填写ip和端口
增加主菜单，二级菜单，多个banner
增加自动检测msf等程序是否存在
增加循环菜单（主菜单、二级菜单）
菜单进行排版
增加将msf木马payload 注入正常文件
新增bypass_server（powershell）模块过免杀

更改代码请注明原作者
![enter description here][3]
&nbsp;
&nbsp;
![enter description here][4]
&nbsp;
&nbsp;
![enter description here][5]
&nbsp;
&nbsp;

## 我们团队----墨 根据我的一些框架 做的一些功能 v2.0
https://github.com/Szrzvdny/secist_script/
![enter description here][6]
&nbsp;
&nbsp;
## bypas_sserver 模块演示视频
&nbsp;
继web_delivery之后的绕过某安全防护的模块
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://7xjfim.com2.z0.glb.qiniucdn.com/Iva.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/bypass_server.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="//cytroncdn.videojj.com/latest/Iva.js"></script>


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/hack-like-pro-antivirus-software-works-evade-pt-2-dissecting-clamav.1280x600-1.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/msf5.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/v.1.32.png
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/v1.31.png
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/v1.33.png 
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/v2.0.png