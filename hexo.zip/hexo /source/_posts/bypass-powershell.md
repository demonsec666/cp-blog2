---
title: 绕powershell限制
date: 2018-04-07 08:34:00
tags: windows
categories: windows
---
![enter description here][1]
<!--more-->
``` stylus
set PSExecutionPolicyPreference=unrestricted
```
![enter description here][2]
http://www.hexacorn.com/blog/2018/04/06/a-quick-note-about-psexecutionpolicypreference/


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/F42A816D2596AB46342A4C295A911DED.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/5078C8C4581672DE05F79A238B0285F2.jpg 