---
title: Ghost_tunnel
date: 2018-09-04 19:51:17
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->


<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=2009803&auto=1&height=66"></iframe>





## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/ghostunnel.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

https://github.com/360PegasusTeam/GhostTunnel

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180904_195606.jpg 