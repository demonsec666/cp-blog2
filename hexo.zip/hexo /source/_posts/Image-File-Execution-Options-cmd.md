---
title: Image_File_Execution_Options_cmd
date: 2018-01-18 20:42:35
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->
##  视频演示
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Image_File_Execution_Options_cmd.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>


https://neonprimetime.blogspot.com/2018/01/java-adwind-rat-uses-image-file.html?utm_campaign=crowdfire&utm_content=crowdfire&utm_medium=social&utm_source=twitter%232362224631-tw%231515608604431
&nbsp;
![enter description here][2]
&nbsp;

恶意代码中，批量的程序，  启动时 启动 svchost.exe
![enter description here][3]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/20BCA22A407A95A1EB5A086651EEA1FA.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516280301173.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516280341723.jpg 