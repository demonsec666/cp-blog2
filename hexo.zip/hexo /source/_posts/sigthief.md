---
title: 数字签名Sigthief |  MSF
date: 2018-01-02 21:29:00
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/sigthief.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

## Github 
https://github.com/secretsquirrel/SigThief


Sigthief是劫持合法的数字签名并绕过Windows的哈希验证机制可以被红队用于将恶意二进制文件和PowerShell脚本与本机操作系统文件混合，以逃避检测并绕过设备防护。
 
##   1.首先是Github上的实例 ：
  从一个二进制签名，并将其添加到另一个二进制文件
  
  python sigthief.py -i  c:\Windows\System32\consent.exe -t mimikatz.exe -o mimi.exe
  

![enter description here][2]
&nbsp;

## 2.借用MSF的payload

![enter description here][3]
&nbsp;
![enter description here][4]
&nbsp;
![enter description here][5]
&nbsp;

## 3.签名
![enter description here][6]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/DCFB5158BC5825B8D1A647230F20737C.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514901579265.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514903647678.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514903672985.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514903726663.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1514903890073.jpg