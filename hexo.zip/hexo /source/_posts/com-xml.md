---
title: com_xml
date: 2018-09-04 21:14:02
tags: Windows
categories: Windows
---
![enter description here][1]
<!--more-->

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=16483445&auto=1&height=66"></iframe>


## 视频演示：
<div style="width:640px;height:480px;margin:0 auto;" id="ivaLive"></div>
<script type="text/javascript" src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/cytron.core.js"></script>
<script>
    var ivaInstance = new Iva('ivaLive', {
        appkey: 'By9WGzBIx', //应用标示
        video: 'http://demonsec666.oss-cn-qingdao.aliyuncs.com/COM%E5%8A%AB%E6%8C%81.mp4', //视频
        title: 'test', //视频标题，后台视频管理中的标题
        cover: '' //视频封面，只有在autoplay:false才可生效
    });
</script>
<script src="http://demonsec666.oss-cn-qingdao.aliyuncs.com/lva.js"></script>





https://github.com/3gstudent/COM-Object-hijacking

不知不觉这条安全道路走快两年了，这博客记录我的学习记录，加油！

payload 加密


``` stylus
PS C:\Users\demon> powershell -ExecutionPolicy Bypass -File "C:\Users\demon\Desktop\COM Object hijacking persistence.ps1
"
[*] Searching Folder...
[+] Create Folder:  C:\Users\demon\AppData\Roaming\Microsoft\Installer\
[+] Create Folder:  C:\Users\demon\AppData\Roaming\Microsoft\Installer\{BCDE0395-E52F-467C-8E3D-C4579291692E}
[*] Detecting operating system...
[+] OS: x64
[*] Releasing file...
[+] Done.
[*] Modifying registry...
[*] 64-bit:
[*] 32-bit:
[+] Done.
PS C:\Users\demon>
```

![enter description here][2]

``` stylus
PS C:\Users\demon> $fileContent = [System.IO.File]::ReadAllBytes('C:\Users\demon\Desktop\calcmutex.dll')
PS C:\Users\demon> $fileContentEncoded = [System.Convert]::ToBase64String($fileContent)| set-content ("123.txt")
```
http://www.4hou.com/technology/4958.html
https://github.com/3gstudent/test/blob/master/calcmutex.dll


![enter description here][3]


2.xml_mimikatz
https://gist.github.com/caseysmithrc/b1190e023cd29c1910c01a164675a22e
![enter description here][4]




  [1]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/IMG_20180904_211723.jpg
  [2]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1536071005118.jpg 
  [3]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/1536070047935.jpg
  [4]: http://demonsec666.oss-cn-qingdao.aliyuncs.com/089FAE2C918CD0DCAAAD0FA5F201269E.jpg